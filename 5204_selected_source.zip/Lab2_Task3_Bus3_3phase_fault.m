clear; clc;

%% ELEC5204 Lab 2 Task 3
% Three-phase fault at BUS_3 using Zbus / impedance matrix method

%% 1. System base
Sbase = 100e6;        % VA, three-phase
Vbase_230 = 230e3;    % V line-to-line for BUS_2 to BUS_6
Zbase_230 = Vbase_230^2 / Sbase;

fprintf('Zbase at 230 kV zone = %.4f ohm\n\n', Zbase_230);

%% 2. Bus order
% 1 = BUS_1
% 2 = BUS_2
% 3 = BUS_3
% 4 = BUS_4
% 5 = BUS_5
% 6 = BUS_6
% 7 = BUS_7
nbus = 7;

%% 3. Prefault voltages from your Load Flow result
Vmag = zeros(nbus,1);
Vang = zeros(nbus,1);

Vmag(1) = 1.0000;   Vang(1) = 0.0000;
Vmag(2) = 0.9018;   Vang(2) = 24.5757;
Vmag(3) = 0.8935;   Vang(3) = 24.3892;
Vmag(4) = 0.8902;   Vang(4) = 25.0234;
Vmag(5) = 0.8921;   Vang(5) = 26.0236;
Vmag(6) = 0.8991;   Vang(6) = 26.9617;
Vmag(7) = 0.9469;   Vang(7) = 4.2425;

Vpre = Vmag .* exp(1j * deg2rad(Vang));

%% 4. Convert PQ loads to constant admittances
% Each load is 50 MW + j30 Mvar on 100 MVA base
Sload_pu = 0.5 + 1j*0.3;

Yload = zeros(nbus,1);

for k = 2:6
    Yload(k) = conj(Sload_pu) / (abs(Vpre(k))^2);
end

fprintf('Equivalent load admittances in pu:\n');
for k = 2:6
    fprintf('BUS_%d: Yload = %.4f %+.4fj pu\n', k, real(Yload(k)), imag(Yload(k)));
end
fprintf('\n');

%% 5. Positive-sequence network data in pu

% Generator subtransient reactances on system base
Xg1 = 0.12;    % G1, already on 100 MVA base
Xg2 = 0.06;    % G2: 0.12 * 100/200

% Transformer leakage reactances on system base
Xt1 = 0.10;    % T1: 100 MVA, unchanged
Xt2 = 0.05;    % T2: 0.1 * 100/200

% Line data
z1_per_km_ohm = 0.08 + 1j*0.5;
y1_per_km_S   = 1j*3.3e-6;

line_data = [
    2 3 15;   % Line1 BUS_2 - BUS_3
    3 4 25;   % Line2 BUS_3 - BUS_4
    4 5 40;   % Line3 BUS_4 - BUS_5
    5 6 15;   % Line4 BUS_5 - BUS_6
    4 6 50;   % Line5 BUS_4 - BUS_6
];

%% 6. Build positive-sequence Ybus
Ybus = zeros(nbus, nbus);

% Function to add a series branch
add_branch = @(Y, i, k, z) addSeriesBranch(Y, i, k, z);

% G1 shunt to ground at BUS_1
Ybus(1,1) = Ybus(1,1) + 1/(1j*Xg1);

% G2 shunt to ground at BUS_7
Ybus(7,7) = Ybus(7,7) + 1/(1j*Xg2);

% Transformer T1 between BUS_1 and BUS_2
Ybus = addSeriesBranch(Ybus, 1, 2, 1j*Xt1);

% Transformer T2 between BUS_6 and BUS_7
Ybus = addSeriesBranch(Ybus, 6, 7, 1j*Xt2);

% Transmission lines with shunt charging
for n = 1:size(line_data,1)
    i = line_data(n,1);
    k = line_data(n,2);
    L_km = line_data(n,3);

    z_pu = z1_per_km_ohm * L_km / Zbase_230;
    y_shunt_pu_total = y1_per_km_S * L_km * Zbase_230;

    Ybus = addSeriesBranch(Ybus, i, k, z_pu);

    % PI model: half shunt at each end
    Ybus(i,i) = Ybus(i,i) + y_shunt_pu_total/2;
    Ybus(k,k) = Ybus(k,k) + y_shunt_pu_total/2;
end

% Add load admittances as shunts
for k = 2:6
    Ybus(k,k) = Ybus(k,k) + Yload(k);
end

fprintf('Positive-sequence Ybus:\n');
disp(Ybus);

%% 7. Zbus and Thevenin equivalent seen from BUS_3
Zbus = inv(Ybus);

fault_bus = 3;
Zth = Zbus(fault_bus, fault_bus);
Vth = Vpre(fault_bus);

Ifault = Vth / Zth;

fprintf('\nTask 3 three-phase fault at BUS_3:\n');
fprintf('Vth = %.4f angle %.4f deg pu\n', abs(Vth), rad2deg(angle(Vth)));
fprintf('Zth = %.6f %+.6fj pu\n', real(Zth), imag(Zth));
fprintf('Ifault = %.4f angle %.4f deg pu\n', abs(Ifault), rad2deg(angle(Ifault)));

% Convert fault current pu to actual current at 230 kV base
Ibase_230 = Sbase / (sqrt(3)*Vbase_230);
Ifault_A = abs(Ifault) * Ibase_230;

fprintf('Ibase at 230 kV = %.2f A\n', Ibase_230);
fprintf('Fault current magnitude = %.2f A = %.4f kA\n\n', Ifault_A, Ifault_A/1000);

%% 8. Fault bus voltages using superposition
% Delta V = - Zbus(:,fault_bus) * Ifault
DeltaV = -Zbus(:,fault_bus) * Ifault;
Vfault = Vpre + DeltaV;

fprintf('Bus voltages during BUS_3 three-phase fault:\n');
for k = 1:nbus
    fprintf('BUS_%d: |V| = %.4f pu, angle = %.4f deg\n', ...
        k, abs(Vfault(k)), rad2deg(angle(Vfault(k))));
end

%% 9. Branch currents during fault
fprintf('\nBranch current magnitudes during fault:\n');

% Lines and transformers
branches = [
    1 2;   % T1
    2 3;   % Line1
    3 4;   % Line2
    4 5;   % Line3
    5 6;   % Line4
    4 6;   % Line5
    6 7;   % T2
];

branch_names = ["T1 BUS1-BUS2";
                "Line1 BUS2-BUS3";
                "Line2 BUS3-BUS4";
                "Line3 BUS4-BUS5";
                "Line4 BUS5-BUS6";
                "Line5 BUS4-BUS6";
                "T2 BUS6-BUS7"];

for n = 1:size(branches,1)
    i = branches(n,1);
    k = branches(n,2);

    if i == 1 && k == 2
        z = 1j*Xt1;
    elseif i == 6 && k == 7
        z = 1j*Xt2;
    else
        % find line length
        idx = find((line_data(:,1)==i & line_data(:,2)==k) | ...
                   (line_data(:,1)==k & line_data(:,2)==i));
        L_km = line_data(idx,3);
        z = z1_per_km_ohm * L_km / Zbase_230;
    end

    Ibranch = (Vfault(i) - Vfault(k)) / z;
    fprintf('%s: |I| = %.4f pu, angle = %.4f deg\n', ...
        branch_names(n), abs(Ibranch), rad2deg(angle(Ibranch)));
end

%% Helper function
function Y = addSeriesBranch(Y, i, k, z)
    y = 1/z;
    Y(i,i) = Y(i,i) + y;
    Y(k,k) = Y(k,k) + y;
    Y(i,k) = Y(i,k) - y;
    Y(k,i) = Y(k,i) - y;
end