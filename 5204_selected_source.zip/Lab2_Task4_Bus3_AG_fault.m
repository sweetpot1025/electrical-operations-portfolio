clear; clc;

%% ELEC5204 Lab 2 Task 4
% A-phase-to-ground fault at BUS_3 using sequence Zbus method

%% 1. System base
Sbase = 100e6;
Vbase_230 = 230e3;
Zbase_230 = Vbase_230^2 / Sbase;
Ibase_230 = Sbase / (sqrt(3)*Vbase_230);

fprintf('Zbase at 230 kV zone = %.4f ohm\n', Zbase_230);
fprintf('Ibase at 230 kV zone = %.4f A\n\n', Ibase_230);

%% 2. Bus order
% 1 = BUS_1
% 2 = BUS_2
% 3 = BUS_3
% 4 = BUS_4
% 5 = BUS_5
% 6 = BUS_6
% 7 = BUS_7
nbus = 7;
fault_bus = 3;

%% 3. Prefault voltages from your load flow result
Vmag = zeros(nbus,1);
Vang = zeros(nbus,1);

Vmag(1) = 1.0000;   Vang(1) = 0.0000;
Vmag(2) = 0.9018;   Vang(2) = 24.5757;
Vmag(3) = 0.8935;   Vang(3) = 24.3892;
Vmag(4) = 0.8902;   Vang(4) = 25.0234;
Vmag(5) = 0.8921;   Vang(5) = 26.0236;
Vmag(6) = 0.8991;   Vang(6) = 26.9617;
Vmag(7) = 0.9469;   Vang(7) = 4.2425;

Vpre = Vmag .* exp(1j*deg2rad(Vang));

%% 4. Convert loads to constant admittances
% Each load = 50 MW + j30 Mvar on 100 MVA base
Sload_pu = 0.5 + 1j*0.3;

Yload = zeros(nbus,1);

for k = 2:6
    Yload(k) = conj(Sload_pu) / abs(Vpre(k))^2;
end

fprintf('Equivalent load admittances:\n');
for k = 2:6
    fprintf('BUS_%d: Yload = %.4f %+.4fj pu\n', ...
        k, real(Yload(k)), imag(Yload(k)));
end
fprintf('\n');

%% 5. Component sequence data on system base

% Generator sequence reactances
Xg1_1 = 0.12;
Xg1_2 = 0.14;
Xg1_0 = 0.05;

Xg2_1 = 0.12 * 100/200;   % = 0.06
Xg2_2 = 0.14 * 100/200;   % = 0.07
Xg2_0 = 0.05 * 100/200;   % = 0.025

% Transformer reactances on system base
Xt1 = 0.10;
Xt2 = 0.10 * 100/200;     % = 0.05

% Line data
z1_per_km_ohm = 0.08 + 1j*0.5;
z2_per_km_ohm = z1_per_km_ohm;

z0_per_km_ohm = 0.2 + 1j*1.5;

y1_per_km_S = 1j*3.3e-6;
y2_per_km_S = y1_per_km_S;
y0_per_km_S = y1_per_km_S;   % zero-sequence capacitance assumed same as positive

line_data = [
    2 3 15;   % Line1 BUS_2 - BUS_3
    3 4 25;   % Line2 BUS_3 - BUS_4
    4 5 40;   % Line3 BUS_4 - BUS_5
    5 6 15;   % Line4 BUS_5 - BUS_6
    4 6 50;   % Line5 BUS_4 - BUS_6
];

%% 6. Build positive-sequence Ybus
Y1 = zeros(nbus, nbus);

% Generator positive-sequence shunts
Y1(1,1) = Y1(1,1) + 1/(1j*Xg1_1);
Y1(7,7) = Y1(7,7) + 1/(1j*Xg2_1);

% Transformers positive-sequence branches
Y1 = addSeriesBranch(Y1, 1, 2, 1j*Xt1);
Y1 = addSeriesBranch(Y1, 6, 7, 1j*Xt2);

% Lines positive-sequence
for n = 1:size(line_data,1)
    i = line_data(n,1);
    k = line_data(n,2);
    L_km = line_data(n,3);

    z_pu = z1_per_km_ohm * L_km / Zbase_230;
    y_total_pu = y1_per_km_S * L_km * Zbase_230;

    Y1 = addSeriesBranch(Y1, i, k, z_pu);
    Y1(i,i) = Y1(i,i) + y_total_pu/2;
    Y1(k,k) = Y1(k,k) + y_total_pu/2;
end

% Load admittances
for k = 2:6
    Y1(k,k) = Y1(k,k) + Yload(k);
end

Z1 = inv(Y1);

%% 7. Build negative-sequence Ybus
Y2 = zeros(nbus, nbus);

% Generator negative-sequence shunts
Y2(1,1) = Y2(1,1) + 1/(1j*Xg1_2);
Y2(7,7) = Y2(7,7) + 1/(1j*Xg2_2);

% Transformers negative-sequence branches
Y2 = addSeriesBranch(Y2, 1, 2, 1j*Xt1);
Y2 = addSeriesBranch(Y2, 6, 7, 1j*Xt2);

% Lines negative-sequence
for n = 1:size(line_data,1)
    i = line_data(n,1);
    k = line_data(n,2);
    L_km = line_data(n,3);

    z_pu = z2_per_km_ohm * L_km / Zbase_230;
    y_total_pu = y2_per_km_S * L_km * Zbase_230;

    Y2 = addSeriesBranch(Y2, i, k, z_pu);
    Y2(i,i) = Y2(i,i) + y_total_pu/2;
    Y2(k,k) = Y2(k,k) + y_total_pu/2;
end

% Load admittances
for k = 2:6
    Y2(k,k) = Y2(k,k) + Yload(k);
end

Z2 = inv(Y2);

%% 8. Build zero-sequence Ybus
% Because T1 and T2 are Delta/Yg transformers, zero-sequence current
% from the 230 kV network can flow to ground through the grounded Y side,
% but it cannot pass through to the generator-side delta terminals.
% Therefore, the zero-sequence network is built for BUS_2 to BUS_6 only.

zero_buses = [2 3 4 5 6];
n0 = length(zero_buses);
Y0 = zeros(n0, n0);

% helper mapping from actual bus number to zero-sequence matrix index
idx0 = @(busnum) find(zero_buses == busnum);

% Zero-sequence lines
for n = 1:size(line_data,1)
    i_bus = line_data(n,1);
    k_bus = line_data(n,2);
    L_km = line_data(n,3);

    i = idx0(i_bus);
    k = idx0(k_bus);

    z_pu = z0_per_km_ohm * L_km / Zbase_230;
    y_total_pu = y0_per_km_S * L_km * Zbase_230;

    Y0 = addSeriesBranch(Y0, i, k, z_pu);
    Y0(i,i) = Y0(i,i) + y_total_pu/2;
    Y0(k,k) = Y0(k,k) + y_total_pu/2;
end

% Zero-sequence path through grounded-Y sides of transformers
% T1 gives shunt path at BUS_2
Y0(idx0(2), idx0(2)) = Y0(idx0(2), idx0(2)) + 1/(1j*Xt1);

% T2 gives shunt path at BUS_6
Y0(idx0(6), idx0(6)) = Y0(idx0(6), idx0(6)) + 1/(1j*Xt2);

% Load admittances on BUS_2 to BUS_6
for busnum = 2:6
    i = idx0(busnum);
    Y0(i,i) = Y0(i,i) + Yload(busnum);
end

Z0 = inv(Y0);

%% 9. Thevenin sequence impedances seen from BUS_3
Z1th = Z1(fault_bus, fault_bus);
Z2th = Z2(fault_bus, fault_bus);
Z0th = Z0(idx0(fault_bus), idx0(fault_bus));

Vf = Vpre(fault_bus);

fprintf('Thevenin sequence impedances seen from BUS_3:\n');
fprintf('Z1th = %.6f %+.6fj pu\n', real(Z1th), imag(Z1th));
fprintf('Z2th = %.6f %+.6fj pu\n', real(Z2th), imag(Z2th));
fprintf('Z0th = %.6f %+.6fj pu\n\n', real(Z0th), imag(Z0th));

%% 10. A-phase-to-ground fault at BUS_3
% For bolted A-G fault:
% I0 = I1 = I2 = Vf / (Z1th + Z2th + Z0th)
% Ia = I0 + I1 + I2 = 3I1
% Ib = 0, Ic = 0

I1 = Vf / (Z1th + Z2th + Z0th);
I2 = I1;
I0 = I1;

a = exp(1j*2*pi/3);

Ia = I0 + I1 + I2;
Ib = I0 + a^2*I1 + a*I2;
Ic = I0 + a*I1 + a^2*I2;

fprintf('Sequence fault currents at BUS_3:\n');
fprintf('I1 = %.4f angle %.4f deg pu\n', abs(I1), rad2deg(angle(I1)));
fprintf('I2 = %.4f angle %.4f deg pu\n', abs(I2), rad2deg(angle(I2)));
fprintf('I0 = %.4f angle %.4f deg pu\n\n', abs(I0), rad2deg(angle(I0)));

fprintf('Phase fault currents at BUS_3:\n');
fprintf('Ia = %.4f angle %.4f deg pu\n', abs(Ia), rad2deg(angle(Ia)));
fprintf('Ib = %.4e pu\n', abs(Ib));
fprintf('Ic = %.4e pu\n', abs(Ic));

Ia_A = abs(Ia) * Ibase_230;
fprintf('Ia actual magnitude = %.2f A = %.4f kA\n\n', Ia_A, Ia_A/1000);

%% 11. Sequence voltages during fault
% Positive-sequence voltage = prefault positive voltage + fault-network change
V1_fault = Vpre - Z1(:, fault_bus) * I1;

% Negative-sequence voltage has no prefault source
V2_fault = -Z2(:, fault_bus) * I2;

% Zero-sequence voltage only exists in BUS_2 to BUS_6 zero-sequence network
V0_fault = zeros(nbus,1);
V0_reduced = -Z0(:, idx0(fault_bus)) * I0;

for m = 1:n0
    busnum = zero_buses(m);
    V0_fault(busnum) = V0_reduced(m);
end

%% 12. Transform sequence voltages back to phase voltages
Va = V0_fault + V1_fault + V2_fault;
Vb = V0_fault + a^2*V1_fault + a*V2_fault;
Vc = V0_fault + a*V1_fault + a^2*V2_fault;

fprintf('Phase voltages during A-G fault at BUS_3:\n');
for k = 1:nbus
    fprintf('BUS_%d:\n', k);
    fprintf('  |Va| = %.4f pu, angle = %.4f deg\n', abs(Va(k)), rad2deg(angle(Va(k))));
    fprintf('  |Vb| = %.4f pu, angle = %.4f deg\n', abs(Vb(k)), rad2deg(angle(Vb(k))));
    fprintf('  |Vc| = %.4f pu, angle = %.4f deg\n', abs(Vc(k)), rad2deg(angle(Vc(k))));
end

fprintf('\nKey values for report:\n');
fprintf('BUS_3 Va should be close to zero for A-G fault.\n');
fprintf('BUS_3: |Va|=%.4f, |Vb|=%.4f, |Vc|=%.4f pu\n', ...
    abs(Va(3)), abs(Vb(3)), abs(Vc(3)));
fprintf('BUS_1: |Va|=%.4f, |Vb|=%.4f, |Vc|=%.4f pu\n', ...
    abs(Va(1)), abs(Vb(1)), abs(Vc(1)));

%% Helper function
function Y = addSeriesBranch(Y, i, k, z)
    y = 1/z;
    Y(i,i) = Y(i,i) + y;
    Y(k,k) = Y(k,k) + y;
    Y(i,k) = Y(i,k) - y;
    Y(k,i) = Y(k,i) - y;
end
