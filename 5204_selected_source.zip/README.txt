ELEC5204 - Power System Modelling and Short-Circuit Analysis

Contents: base network, three-phase fault and phase-A-to-ground Simulink models, plus analytical MATLAB scripts.
Environment: MATLAB, Simulink and Simscape Electrical Specialized Power Systems.
Analytical calculation bases: 100 MVA and 230 kV.
Use the base network for load-flow analysis, and the fault models for the corresponding Bus 3 cases.
