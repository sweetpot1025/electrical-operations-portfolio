ELEC5204 三相系统建模与短路故障分析

Lab1/：纯电阻、并联 RL 与非理想电源模型
Lab2/：七节点网络、三相短路与 A 相接地模型和解析计算脚本
reports/：两次实验报告

使用 MATLAB、Simulink 和 Simscape Electrical Specialized Power Systems。
