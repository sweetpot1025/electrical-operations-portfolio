ELEC5204 course-group source selection
Part of Haotian Guo's electrical-engineering portfolio. These are group coursework artifacts, not a claim of sole authorship.
Selected from the user-provided April 2026 files. Repeated filenames were byte-identical. The doubled Task 4 .m extension has been normalized in this package; content is unchanged.
Includes the base and fault Simulink models plus the three-phase and phase-A-to-ground analytical scripts.
Requires a compatible MATLAB/Simulink installation and Simscape Electrical Specialized Power Systems. Saved results were reviewed; models were not rerun during portfolio preparation.
Keep the model's units, source parameters, transformer connections and measurement definitions when interpreting results. Source figures and a calculated current must use the same measurement definition before numerical comparison.
