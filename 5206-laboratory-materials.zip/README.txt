ELEC5206 可持续能源系统实验

reports/：Lab 1 仪器测量、Lab 2 光伏特性、Lab 3 光伏建模、Lab 4 MPPT、Lab 5 风机特性报告
data/：MPPT 两种位置的完整记录、风机 27 个工况数据
figures/：实验与仿真成果图，包括风机-PMSG 联调波形
