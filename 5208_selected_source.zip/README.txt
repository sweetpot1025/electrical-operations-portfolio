ELEC5208 配电网建模 HEMS 与动态运行区间

Task1/：三相四线网络、负荷曲线构建、年度仿真与最弱节点分析
Task2/：规则式 HEMS、24 小时和全年场景、结果图和汇总
Task3/：LP HEMS、SOCP DOE、OpenDSS 场景验证
reports/：三个阶段的技术报告

使用 Julia、OpenDSS、JuMP、HiGHS 与 Clarabel。按各脚本中的数据目录设置准备课程 SolarAnalytics 输入数据，先构建 LoadShape，再执行年度场景脚本。
