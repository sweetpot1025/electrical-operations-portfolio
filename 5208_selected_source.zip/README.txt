ELEC5208 - Active Distribution Systems

Contents: rule-based HEMS, optimisation-based HEMS, SOCP dynamic operating envelopes, DOE application and annual simulation scripts.
Environment: Julia; packages depend on the script and include OpenDSSDirect, JuMP, HiGHS, Clarabel, CSV, DataFrames, Dates, Statistics and Plots.
Inputs: configure feeder model paths, household demand/PV profiles and generated LoadShapes before running the full pipeline.
The aggregate-data calculation tool verify_results.py is available at repository root.
