ELEC5208 Task II/III selected course-group source
Portfolio selection only; not a complete standalone reproduction package.
The course report credits Haotian Guo for code modification/improvement and shared result recording. Initial implementation and other project work were shared with group members. The original report declares ChatGPT assistance.
Selected from the user-provided Task3(1).zip. Code contents are unchanged. Some scripts require Julia packages such as OpenDSSDirect, JuMP, HiGHS, Clarabel, CSV, DataFrames, Dates, Statistics and Plots, depending on the file.
Household-level measurements, generated load profiles, feeder inputs and the original dataset are not distributed in this public selection. Data access and path configuration are therefore required before using the original pipeline. The aggregate-data script verify_results.py at repository root runs without these inputs.
The SOCP model solves phases independently and extends a representative week. Read the project page for the limitations and distinction between reported Task III outcomes and directly checked Task II aggregates.
