using CSV
using DataFrames
using Dates
using TimeZones
using Plots

const SYD = tz"Australia/Sydney"
const TS_FMT = dateformat"yyyy-mm-dd HH:MM:SSzzzz"

function parse_zdt(s::AbstractString)
    s2 = strip(s)
    tz = TimeZone(s2[end-5:end])
    return ZonedDateTime(DateTime(s2, TS_FMT), tz)
end

function load_one_profile(csv_file::AbstractString)
    df = CSV.read(csv_file, DataFrame)

    df.utc_timestamp = parse_zdt.(String.(df.utc_timestamp))
    df.localtime     = parse_zdt.(String.(df.localtime))
    df.site_id       = string.(df.site_id)

    # 参考老师给的处理思路：5分钟数据转成小时等效功率量级
    df.pv_generation = 12 .* Float64.(df.pv_generation)
    df.total_load    = 12 .* Float64.(df.total_load)

    sort!(df, [:site_id, :utc_timestamp])

    df.ts_syd = astimezone.(df.utc_timestamp, Ref(SYD))

    # 清洗
    df.pv_clean   = max.(df.pv_generation, 0.0)
    df.load_clean = max.(df.total_load, 0.0)

    return df
end

function main()
    allocation_file = joinpath(@__DIR__, "..", "data", "load_allocation.csv")
    data_dir        = joinpath(@__DIR__, "..", "data")
    out_dir         = joinpath(@__DIR__, "..", "results", "profiles")

    println("Reading allocation table:")
    println(allocation_file)

    alloc = CSV.read(allocation_file, DataFrame)

    println("\nAllocation table size:")
    println(size(alloc))

    println("\nFirst 5 rows of allocation table:")
    println(first(alloc, 5))

    # 读取所有会用到的 profile 文件，但每个文件只读一次
    profile_cache = Dict{String,DataFrame}()

    for fname in unique(alloc.profile_file)
        fpath = joinpath(data_dir, fname)
        println("\nLoading profile file: ", fpath)
        profile_cache[fname] = load_one_profile(fpath)
    end

    # 汇总表
    summary = DataFrame(
        load_id = String[],
        bus = String[],
        phase = Int[],
        profile_file = String[],
        scale = Float64[],
        peak_kw = Float64[],
        annual_energy_kwh = Float64[]
    )

    # 为每个负荷生成一条全年曲线
    for row in eachrow(alloc)
        load_id = String(row.load_id)
        bus     = String(row.bus)
        phase   = Int(row.phase)
        fname   = String(row.profile_file)
        scale   = Float64(row.scale)

        df_prof = profile_cache[fname]

        # 这里先只生成“需求负荷”曲线
        p_kw = scale .* (df_prof.load_clean ./ 1000.0)

        df_out = DataFrame(
            ts_syd = df_prof.ts_syd,
            p_kw   = p_kw
        )

        out_file = joinpath(out_dir, "$(load_id)_profile.csv")
        CSV.write(out_file, df_out)

        # 年峰值功率
        peak_kw = maximum(p_kw)

        # 5分钟一个点，所以全年能量 = sum(kW)*5/60 = sum(kW)/12
        annual_energy_kwh = sum(p_kw) / 12

        push!(summary, (
            load_id,
            bus,
            phase,
            fname,
            scale,
            peak_kw,
            annual_energy_kwh
        ))
    end

    # 保存汇总表
    summary_file = joinpath(@__DIR__, "..", "results", "load_profile_summary.csv")
    CSV.write(summary_file, summary)

    println("\nSaved summary to:")
    println(summary_file)

    println("\nFirst 10 rows of summary:")
    println(first(summary, 10))

    # 画 3 条示例曲线（取前 2 天）
    day_points = 288
    sample_points = 2 * day_points

    l1 = CSV.read(joinpath(out_dir, "L1_profile.csv"), DataFrame)
    l2 = CSV.read(joinpath(out_dir, "L2_profile.csv"), DataFrame)
    l3 = CSV.read(joinpath(out_dir, "L3_profile.csv"), DataFrame)

    p = plot(
        l1.ts_syd[1:sample_points], l1.p_kw[1:sample_points],
        label = "L1",
        xlabel = "Sydney local time",
        ylabel = "Load power [kW]",
        title = "Example generated load profiles (first 2 days)"
    )
    plot!(p, l2.ts_syd[1:sample_points], l2.p_kw[1:sample_points], label = "L2")
    plot!(p, l3.ts_syd[1:sample_points], l3.p_kw[1:sample_points], label = "L3")

    plot_file = joinpath(@__DIR__, "..", "results", "example_generated_profiles.png")
    savefig(p, plot_file)

    println("\nSaved example plot to:")
    println(plot_file)
end

main()