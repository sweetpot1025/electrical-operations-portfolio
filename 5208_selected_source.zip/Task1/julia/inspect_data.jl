using CSV
using DataFrames
using Plots

function main()
    csv_file = joinpath(@__DIR__, "..", "data", "5min_368133844.csv")

    println("Reading file:")
    println(csv_file)

    df = CSV.read(csv_file, DataFrame)

    println("\nColumn names:")
    println(names(df))

    println("\nFirst 5 rows:")
    println(first(df, 5))

    println("\nNumber of rows and columns:")
    println(size(df))
end

main()