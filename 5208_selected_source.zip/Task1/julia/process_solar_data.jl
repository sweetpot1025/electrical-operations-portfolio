using CSV
using DataFrames
using Dates
using TimeZones
using Plots

const SYD = tz"Australia/Sydney"
const TS_FMT = dateformat"yyyy-mm-dd HH:MM:SSzzzz"

# 解析带时区偏移的时间字符串，例如：
# 2018-12-31 13:00:00+00:00
function parse_zdt(s::AbstractString)
    s2 = strip(s)
    tz = TimeZone(s2[end-5:end])   # 取最后 6 个字符，比如 +00:00
    return ZonedDateTime(DateTime(s2, TS_FMT), tz)
end

# 找到某个日期所在周的周一
function monday_start(d::Date)
    return d - Day(dayofweek(d) - 1)
end

function main()
    # ========= 1. 文件路径 =========
    filename = "5min_368133844.csv"
    csv_file = joinpath(@__DIR__, "..", "data", filename)

    println("Reading file:")
    println(csv_file)

    # ========= 2. 读取 CSV =========
    df = CSV.read(csv_file, DataFrame)

    println("\nOriginal column names:")
    println(names(df))

    # 3. 解析时间 
    df.utc_timestamp = parse_zdt.(String.(df.utc_timestamp))
    df.localtime     = parse_zdt.(String.(df.localtime))

    # ========= 4. 清理数据类型 =========
    df.site_id = string.(df.site_id)

   
    # 原始 5 分钟数据乘以 12，转成小时等效功率量级
    df.pv_generation = 12 .* Float64.(df.pv_generation) ./ 1000.0
df.total_load    = 12 .* Float64.(df.total_load) ./ 1000.0
    # ========= 5. 排序 =========
    sort!(df, [:site_id, :utc_timestamp])

    # ========= 6. 增加 Sydney 本地时间列 =========
    df.ts_syd = astimezone.(df.utc_timestamp, Ref(SYD))

    # ========= 7. 简单清洗 =========
    # 负的 PV 不合理，截成 0
    df.pv_clean = max.(df.pv_generation, 0.0)

    println("\nFirst 5 rows after cleaning:")
    println(first(df, 5))

    println("\nData size:")
    println(size(df))

    println("\nUnique site IDs:")
    println(unique(df.site_id))

    # ========= 8. 选取一周数据 =========
    # 这里选包含 2019-01-01 的那一周
    ref_date = Date(2019, 1, 1)
    week_start_date = monday_start(ref_date)

    week_start = ZonedDateTime(DateTime(week_start_date), SYD)
    week_end   = week_start + Week(1)

    df_week = filter(row -> (row.ts_syd >= week_start) && (row.ts_syd < week_end), df)

    println("\nWeek start (Sydney): ", week_start)
    println("Week end   (Sydney): ", week_end)
    println("Rows in selected week: ", nrow(df_week))

    # ========= 9. 画图 =========
    p = plot(
        df_week.ts_syd,
        df_week.total_load,
        label = "Total load",
        xlabel = "Sydney local time",
        ylabel = "Power",
        title = "One calendar week: load and PV"
    )

    plot!(
        p,
        df_week.ts_syd,
        df_week.pv_clean,
        label = "PV generation (clipped)"
    )

    # ========= 10. 保存图片 =========
    out_file = joinpath(@__DIR__, "..", "results", "week_profile_368133844.png")
    savefig(p, out_file)

    println("\nPlot saved to:")
    println(out_file)

    # ========= 11. 打印统计量 =========
    println("\nStatistics for selected week:")
    println("Load minimum = ", minimum(df_week.total_load))
    println("Load maximum = ", maximum(df_week.total_load))
    println("PV minimum   = ", minimum(df_week.pv_clean))
    println("PV maximum   = ", maximum(df_week.pv_clean))

    # ========= 12. 保存清洗后的一周数据（方便后面继续用） =========
    out_csv = joinpath(@__DIR__, "..", "results", "week_profile_368133844.csv")
    CSV.write(out_csv, df_week)

    println("\nWeek data saved to:")
    println(out_csv)
end

main()