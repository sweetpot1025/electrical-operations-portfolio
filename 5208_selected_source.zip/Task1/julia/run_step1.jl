using OpenDSSDirect
const dss = OpenDSSDirect

function main()
    dss_file = joinpath(@__DIR__, "..", "dss", "network_step1.dss")

    println("Compiling DSS file:")
    println(dss_file)

    dss.Text.Command("compile $dss_file")
    dss.Text.Command("solve")

    println("Task 1 step 1 solved.")
    println("Bus names:")
    println(dss.Circuit.AllBusNames())

    println("Total power seen by the circuit (kW, kvar):")
    println(dss.Circuit.TotalPower())

    println("\nBus voltage magnitudes in per-unit:")

    bus_names = dss.Circuit.AllBusNames()

    min_v = 999.0
    max_v = 0.0
    min_bus = ""
    max_bus = ""

    for bus in bus_names
        dss.Circuit.SetActiveBus(bus)
        vpu = dss.Bus.puVmagAngle()

        mags = vpu[1:2:end]
        phase_mags = mags[1:min(3, length(mags))]

        println("Bus $bus => ", phase_mags)

        for v in phase_mags
            if v > 0.0
                if v < min_v
                    min_v = v
                    min_bus = bus
                end
                if v > max_v
                    max_v = v
                    max_bus = bus
                end
            end
        end
    end

    println("\nSummary:")
    println("Minimum phase voltage = $min_v p.u. at bus $min_bus")
    println("Maximum phase voltage = $max_v p.u. at bus $max_bus")

    if min_v >= 0.9 && max_v <= 1.1
        println("Voltage check PASSED: all phase voltages are within 0.9–1.1 p.u.")
    else
        println("Voltage check FAILED: there are phase voltages outside 0.9–1.1 p.u.")
    end
end

main()