using OpenDSSDirect
using CSV
using DataFrames
using Plots

const dss = OpenDSSDirect

function main()
    dss_file = joinpath(@__DIR__, "..", "dss", "network_step2_timeseries.dss")

    # 读一个 profile 文件拿时间戳参考
    ref_profile_file = joinpath(@__DIR__, "..", "results", "profiles", "L1_profile.csv")

    out_csv      = joinpath(@__DIR__, "..", "results", "year_timeseries_results.csv")
    out_summary  = joinpath(@__DIR__, "..", "results", "year_summary.csv")
    out_fig_v    = joinpath(@__DIR__, "..", "results", "year_voltage_profile.png")
    out_fig_p    = joinpath(@__DIR__, "..", "results", "year_total_power.png")

    println("Compiling DSS file:")
    println(dss_file)

    dss.Text.Command("compile $dss_file")

    bus_names = dss.Circuit.AllBusNames()

    # 参考时间轴
    ref_df = CSV.read(ref_profile_file, DataFrame)

    nsteps = nrow(ref_df)   # 应该是 105120
    println("\nNumber of yearly steps:")
    println(nsteps)

    results = DataFrame(
        step = Int[],
        ts_syd = String[],
        hour_from_year = Float64[],
        min_v = Float64[],
        max_v = Float64[],
        min_bus = String[],
        max_bus = String[],
        total_p_kw = Float64[],
        total_q_kvar = Float64[],
        converged = Bool[]
    )

    for k in 1:nsteps
        total_seconds = (k - 1) * 300
        hour_val = total_seconds ÷ 3600
        sec_val  = total_seconds % 3600

        dss.Text.Command("set mode=yearly")
        dss.Text.Command("set stepsize=5m")
        dss.Text.Command("set number=1")
        dss.Text.Command("set hour=$(hour_val)")
        dss.Text.Command("set sec=$(sec_val)")
        dss.Text.Command("solve")

        conv = dss.Solution.Converged()

        min_v = 999.0
        max_v = 0.0
        min_bus = ""
        max_bus = ""

        for bus in bus_names
            dss.Circuit.SetActiveBus(bus)
            vpu = dss.Bus.puVmagAngle()

            mags = vpu[1:2:end]
            phase_mags = mags[1:min(3, length(mags))]

            for v in phase_mags
                if v > 0.0
                    if v < min_v
                        min_v = v
                        min_bus = bus
                    end
                    if v > max_v
                        max_v = v
                        max_bus = bus
                    end
                end
            end
        end

        s_total = dss.Circuit.TotalPower()
        total_p_kw = -real(s_total)
        total_q_kvar = -imag(s_total)

        push!(results, (
            k,
            string(ref_df.ts_syd[k]),
            (k - 1) * 5 / 60,
            min_v,
            max_v,
            min_bus,
            max_bus,
            total_p_kw,
            total_q_kvar,
            conv
        ))

        # 每 5000 步打印一次进度
        if k % 5000 == 0 || k == nsteps
            println("Completed step $k / $nsteps")
        end
    end

    CSV.write(out_csv, results)

    println("\nSaved yearly results to:")
    println(out_csv)

    # ===== 全年汇总 =====
    idx_min_v = argmin(results.min_v)
    idx_max_v = argmax(results.max_v)
    idx_max_p = argmax(results.total_p_kw)
    idx_min_p = argmin(results.total_p_kw)

    all_conv = all(results.converged)
    voltage_pass = minimum(results.min_v) >= 0.9 && maximum(results.max_v) <= 1.1

    summary = DataFrame(
        metric = String[],
        value = String[]
    )

    push!(summary, ("nsteps", string(nsteps)))
    push!(summary, ("all_steps_converged", string(all_conv)))
    push!(summary, ("voltage_pass_0.9_to_1.1", string(voltage_pass)))

    push!(summary, ("minimum_voltage_pu", string(results.min_v[idx_min_v])))
    push!(summary, ("minimum_voltage_time", results.ts_syd[idx_min_v]))
    push!(summary, ("minimum_voltage_bus", results.min_bus[idx_min_v]))

    push!(summary, ("maximum_voltage_pu", string(results.max_v[idx_max_v])))
    push!(summary, ("maximum_voltage_time", results.ts_syd[idx_max_v]))
    push!(summary, ("maximum_voltage_bus", results.max_bus[idx_max_v]))

    push!(summary, ("minimum_total_P_kw", string(results.total_p_kw[idx_min_p])))
    push!(summary, ("minimum_total_P_time", results.ts_syd[idx_min_p]))

    push!(summary, ("maximum_total_P_kw", string(results.total_p_kw[idx_max_p])))
    push!(summary, ("maximum_total_P_time", results.ts_syd[idx_max_p]))

    CSV.write(out_summary, summary)

    println("\nSaved yearly summary to:")
    println(out_summary)

    println("\nKey summary:")
    println("Minimum voltage over year = ", results.min_v[idx_min_v], " p.u. at bus ", results.min_bus[idx_min_v], " at ", results.ts_syd[idx_min_v])
    println("Maximum voltage over year = ", results.max_v[idx_max_v], " p.u. at bus ", results.max_bus[idx_max_v], " at ", results.ts_syd[idx_max_v])
    println("Maximum total P over year = ", results.total_p_kw[idx_max_p], " kW at ", results.ts_syd[idx_max_p])

    if all_conv
        println("All yearly time steps converged.")
    else
        println("Warning: some yearly time steps did not converge.")
    end

    if voltage_pass
        println("Voltage check PASSED over the full year.")
    else
        println("Voltage check FAILED over the full year.")
    end

    # ===== 全年图 =====
    p1 = plot(
        results.hour_from_year,
        results.min_v,
        label = "Minimum phase voltage",
        xlabel = "Hour from start of year",
        ylabel = "Voltage [p.u.]",
        title = "Full-year voltage range"
    )
    plot!(p1, results.hour_from_year, results.max_v, label = "Maximum phase voltage")
    savefig(p1, out_fig_v)

    println("\nSaved yearly voltage plot to:")
    println(out_fig_v)

    p2 = plot(
        results.hour_from_year,
        results.total_p_kw,
        label = "Total active power",
        xlabel = "Hour from start of year",
        ylabel = "Power [kW]",
        title = "Full-year total feeder power"
    )
    savefig(p2, out_fig_p)

    println("\nSaved yearly power plot to:")
    println(out_fig_p)
end

main()