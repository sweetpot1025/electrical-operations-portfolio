using CSV
using DataFrames

function main()
    profiles_dir   = joinpath(@__DIR__, "..", "results", "profiles")
    shapes_dir     = joinpath(@__DIR__, "..", "results", "shapes")
    summary_file   = joinpath(@__DIR__, "..", "results", "load_profile_summary.csv")
    step1_file     = joinpath(@__DIR__, "..", "dss", "network_step1.dss")
    loads_dss_file = joinpath(@__DIR__, "..", "dss", "timeseries_loads.dss")
    step2_file     = joinpath(@__DIR__, "..", "dss", "network_step2_timeseries.dss")

    mkpath(shapes_dir)

    println("Reading summary file:")
    println(summary_file)

    summary = CSV.read(summary_file, DataFrame)

    println("\nSummary size:")
    println(size(summary))

   
    # 1) Build normalized shape CSVs + timeseries_loads.dss

 # Build normalized shape CSVs   
    open(loads_dss_file, "w") do io
        println(io, "! Auto-generated time-series load definitions")
        println(io, "! One LoadShape + one Load for each single-phase customer")
        println(io, "")

        # First write LoadShape definitions
        for row in eachrow(summary)
            load_id = String(row.load_id)
            peak_kw = Float64(row.peak_kw)

            prof_file = joinpath(profiles_dir, "$(load_id)_profile.csv")
            df = CSV.read(prof_file, DataFrame)

            mult = df.p_kw ./ peak_kw
            shape_df = DataFrame(mult = mult)

            shape_csv = joinpath(shapes_dir, "$(load_id)_shape.csv")
            CSV.write(shape_csv, shape_df)

            npts = nrow(shape_df)

            # The path is written relative to the .dss folder
            rel_shape = "..\\results\\shapes\\$(load_id)_shape.csv"

            println(io,
                "New LoadShape.LS_$(load_id) npts=$(npts) interval=0.083333 mult=(file=$(rel_shape), col=1, header=yes)"
            )
        end

        println(io, "")
        println(io, "! Load objects linked to yearly LoadShapes")
        println(io, "")

        # Then write Load objects
        for row in eachrow(summary)
            load_id = String(row.load_id)
            bus     = String(row.bus)
            phase   = Int(row.phase)
            peak_kw = Float64(row.peak_kw)

            println(io,
                "New Load.$(load_id) bus1=$(bus).$(phase).4 phases=1 conn=wye kV=0.23 kW=$(round(peak_kw, digits=4)) pf=0.98 yearly=LS_$(load_id)"
            )
        end
    end

    println("\nSaved:")
    println(loads_dss_file)

    
    # 2) Build network_step2_timeseries.dss
    #    Start from step1, remove fixed loads and Solve line,
    #    then append Redirect timeseries_loads.dss
   
    lines = readlines(step1_file)

    filtered = String[]
    for line in lines
        s = strip(line)

        # Remove the originally fixed 36 loads
        if startswith(s, "New Load.")
            continue
        end

        # Remove the last Solve
        if lowercase(s) == "solve"
            continue
        end

        push!(filtered, line)
    end

    open(step2_file, "w") do io
        println(io, "! Auto-generated time-series network file")
        for line in filtered
            println(io, line)
        end
        println(io, "")
        println(io, "! Add time-series loads")
        println(io, "Redirect timeseries_loads.dss")
    end

    println("\nSaved:")
    println(step2_file)

    println("\nDone.")
end

main()