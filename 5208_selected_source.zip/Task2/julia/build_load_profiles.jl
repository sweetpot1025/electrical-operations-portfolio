using CSV
using DataFrames
using Dates
using TimeZones
using Plots

const SYD = tz"Australia/Sydney"
const TS_FMT = dateformat"yyyy-mm-dd HH:MM:SSzzzz"
const TARGET_NPTS = 105120

function parse_zdt(s::AbstractString)
    s2 = strip(s)
    tz = TimeZone(s2[end-5:end])
    return ZonedDateTime(DateTime(s2, TS_FMT), tz)
end

function load_one_profile(csv_file::AbstractString)
    df = CSV.read(csv_file, DataFrame)

    df.utc_timestamp = parse_zdt.(String.(df.utc_timestamp))
    df.localtime     = parse_zdt.(String.(df.localtime))
    df.site_id       = string.(df.site_id)

    # Convert the 5-minute data to the hourly equivalent power level
    df.pv_generation = 12 .* Float64.(df.pv_generation)
    df.total_load    = 12 .* Float64.(df.total_load)

    sort!(df, [:site_id, :utc_timestamp])

    df.ts_syd = astimezone.(df.utc_timestamp, Ref(SYD))

    # Clean
    df.pv_clean   = max.(df.pv_generation, 0.0)
    df.load_clean = max.(df.total_load, 0.0)

    return df
end

function main()
    allocation_file = joinpath(@__DIR__, "..", "data", "load_allocation.csv")
    data_dir        = joinpath(@__DIR__, "..", "data")
    out_dir         = joinpath(@__DIR__, "..", "results", "profiles")

    # Automatically create the output directory
    mkpath(out_dir)

    println("Reading allocation table:")
    println(allocation_file)

    alloc = CSV.read(allocation_file, DataFrame)

    println("\nAllocation table size:")
    println(size(alloc))

    println("\nFirst 5 rows of allocation table:")
    println(first(alloc, 5))

    # Read all the profile files that will be used, but only read each file once
    profile_cache = Dict{String,DataFrame}()

    for fname in unique(alloc.profile_file)
        fpath = joinpath(data_dir, fname)
        println("\nLoading profile file: ", fpath)
        profile_cache[fname] = load_one_profile(fpath)
    end

    # Summary sheet
    summary = DataFrame(
        load_id = String[],
        bus = String[],
        phase = Int[],
        profile_file = String[],
        scale = Float64[],
        peak_kw = Float64[],
        annual_energy_kwh = Float64[]
    )

    # Generate an annual curve for each load
    for row in eachrow(alloc)
        load_id = String(row.load_id)
        bus     = String(row.bus)
        phase   = Int(row.phase)
        fname   = String(row.profile_file)
        scale   = Float64(row.scale)

        df_prof = profile_cache[fname]

        # Only generate the "demand load" curve here
        p_kw_raw = scale .* (df_prof.load_clean ./ 1000.0)

        # The mandatory unified annual length is 105,120 points
        if length(p_kw_raw) >= TARGET_NPTS
            p_kw   = p_kw_raw[1:TARGET_NPTS]
            ts_use = df_prof.ts_syd[1:TARGET_NPTS]
        else
            missing_n = TARGET_NPTS - length(p_kw_raw)

            # Fill in the last value to the full year length
            p_kw   = vcat(p_kw_raw, fill(p_kw_raw[end], missing_n))
            ts_use = vcat(df_prof.ts_syd, fill(df_prof.ts_syd[end], missing_n))
        end

        df_out = DataFrame(
            ts_syd = ts_use,
            p_kw   = p_kw
        )

        out_file = joinpath(out_dir, "$(load_id)_profile.csv")
        CSV.write(out_file, df_out)

        # Annual peak power
        peak_kw = maximum(p_kw)

        # The energy for the whole year = sum(kW)*5/60 = sum(kW)/12
        annual_energy_kwh = sum(p_kw) / 12

        push!(summary, (
            load_id,
            bus,
            phase,
            fname,
            scale,
            peak_kw,
            annual_energy_kwh
        ))
    end

    # Save the summary sheet
    summary_file = joinpath(@__DIR__, "..", "results", "load_profile_summary.csv")
    CSV.write(summary_file, summary)

    println("\nSaved summary to:")
    println(summary_file)

    println("\nFirst 10 rows of summary:")
    println(first(summary, 10))

    # Draw three sample curves (take the first two days)
    day_points = 288
    sample_points = 2 * day_points

    l1 = CSV.read(joinpath(out_dir, "L1_profile.csv"), DataFrame)
    l2 = CSV.read(joinpath(out_dir, "L2_profile.csv"), DataFrame)
    l3 = CSV.read(joinpath(out_dir, "L3_profile.csv"), DataFrame)

    # Convert to hour coordinates (0 to 48 hours)
    t_hours = (0:sample_points-1) .* (5 / 60)

    p = plot(
        t_hours,
        l1.p_kw[1:sample_points],
        label = "L1",
        xlabel = "Hour of day",
        ylabel = "Load power [kW]",
        title = "Example generated load profiles (first 2 days)",
        grid = true
    )

    plot!(p, t_hours, l2.p_kw[1:sample_points], label = "L2")
    plot!(p, t_hours, l3.p_kw[1:sample_points], label = "L3")

    xticks!(p, 0:6:48)

    plot_file = joinpath(@__DIR__, "..", "results", "example_generated_profiles.png")
    savefig(p, plot_file)

    println("\nSaved example plot to:")
    println(plot_file)

    println("\nAll generated profiles were forced to length = ", TARGET_NPTS)
end

main()