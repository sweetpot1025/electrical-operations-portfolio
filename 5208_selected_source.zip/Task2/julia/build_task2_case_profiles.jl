using CSV
using DataFrames
using Statistics

include("hems_rule_based.jl")

const PV_LOADS = ["L4", "L7", "L10", "L13", "L16", "L17", "L18", "L22", "L23", "L24", "L25", "L26", "L27", "L34", "L35"]
const HEMS_LOADS = ["L10", "L13", "L16", "L17", "L22", "L23", "L24", "L25", "L26", "L27"]
function find_col(df::DataFrame, candidates::Vector{String})
    for c in candidates
        if c in names(df)
            return Symbol(c)
        end
    end
    error("Cannot find any of these columns: $(join(candidates, ", "))")
end

function write_task2_node_selection(task_root::AbstractString)
    alloc_file = joinpath(task_root, "data", "load_allocation.csv")
    alloc = CSV.read(alloc_file, DataFrame)

    load_col = find_col(alloc, ["load_id", "Load", "load", "id"])
    bus_col = find_col(alloc, ["bus", "Bus", "bus_id", "bus_name"])
    phase_col = find_col(alloc, ["phase", "Phase", "ph"])

    pv_set = Set(String.(PV_LOADS))
    hems_set = Set(String.(HEMS_LOADS))

    out = DataFrame(
        load_id = String[],
        bus = String[],
        phase = Int[],
        has_pv = Bool[],
        has_battery_hems = Bool[]
    )

    for row in eachrow(alloc)
        load_id = String(row[load_col])

        if load_id in pv_set
            push!(out, (
                load_id,
                String(row[bus_col]),
                Int(row[phase_col]),
                true,
                load_id in hems_set
            ))
        end
    end

    sort!(out, :load_id)

    out_file = joinpath(task_root, "results", "task2_selected_nodes.csv")
    CSV.write(out_file, out)

    println("Saved Task 2 selected node table to:")
    println(out_file)

    println("\nTask 2 node selection summary:")
    println("PV loads selected = ", nrow(out))
    println("HEMS battery loads selected = ", count(out.has_battery_hems))
end
function read_task1_demand_profile(task_root, load_id)
    file = joinpath(task_root, "results", "profiles", "$(load_id)_profile.csv")
    df = CSV.read(file, DataFrame)
    return DataFrame(ts_syd=df.ts_syd, demand_kw=Float64.(df.p_kw))
end

function build_case_profile(task_root::AbstractString, load_id::String; case_symbol::Symbol, battery_capacity_kwh::Float64=10.0, sso::Bool=false)
    demand_df = read_task1_demand_profile(task_root, load_id)
    raw_df = read_allocated_profile(task_root, load_id)
    pv_kw = Float64.(raw_df.pv_kw)
    demand_kw = Float64.(demand_df.demand_kw)

    if case_symbol == :case2_pv_only
        # PV-only household: net grid exchange = native demand - available PV.
        net_kw = demand_kw .- pv_kw
        return DataFrame(ts_syd=demand_df.ts_syd, grid_net_kw=net_kw, demand_kw=demand_kw, pv_kw=pv_kw)

    elseif case_symbol == :case3_hems
        hems = simulate_hems_rule_based(
            demand_kw,
            pv_kw;
            ts=raw_df.ts_syd,
            dt_hours=5/60,
            battery_capacity_kwh=battery_capacity_kwh,
            battery_power_kw=5.0,
            eta=0.90,
            initial_soc_kwh=0.5*battery_capacity_kwh,
            min_soc_kwh=0.0,
            sso=sso,
            allow_grid_charging_sso=true
        )
        return DataFrame(ts_syd=demand_df.ts_syd, grid_net_kw=Float64.(hems.grid_net_kw), demand_kw=demand_kw, pv_kw=pv_kw,
                         battery_charge_kw=hems.battery_charge_kw, battery_discharge_kw=hems.battery_discharge_kw,
                         soc_end_kwh=hems.soc_end_kwh, grid_import_kw=hems.grid_import_kw, grid_export_kw=hems.grid_export_kw)
    else
        error("Unknown case_symbol=$case_symbol")
    end
end

function write_dss_for_case(task_root::AbstractString, case_name::String, case_profiles::Dict{String,DataFrame})
    alloc = CSV.read(joinpath(task_root, "data", "load_allocation.csv"), DataFrame)
    out_case_dir = joinpath(task_root, "results", "task2_cases", case_name)
    profiles_dir = joinpath(out_case_dir, "profiles")
    shapes_dir = joinpath(out_case_dir, "shapes")
    mkpath(profiles_dir); mkpath(shapes_dir)

    summary = DataFrame(load_id=String[], bus=String[], phase=Int[], base_kw=Float64[], annual_import_kwh=Float64[], annual_export_kwh=Float64[])

    for row in eachrow(alloc)
        load_id = String(row.load_id)
        bus = String(row.bus)
        phase = Int(row.phase)

        if haskey(case_profiles, load_id)
            prof = case_profiles[load_id]
        else
            base_prof = read_task1_demand_profile(task_root, load_id)
            prof = DataFrame(ts_syd=base_prof.ts_syd, grid_net_kw=base_prof.demand_kw, demand_kw=base_prof.demand_kw, pv_kw=zeros(nrow(base_prof)))
        end

        prof_file = joinpath(profiles_dir, "$(load_id)_profile.csv")
        CSV.write(prof_file, prof)

        net = Float64.(prof.grid_net_kw)
        base_kw = maximum(abs.(net))
        if base_kw < 1e-6
            base_kw = 1.0
        end
        mult = net ./ base_kw
        CSV.write(joinpath(shapes_dir, "$(load_id)_shape.csv"), DataFrame(mult=mult))

        import_kwh = sum(max.(net, 0.0)) / 12.0
        export_kwh = sum(max.(-net, 0.0)) / 12.0
        push!(summary, (load_id, bus, phase, base_kw, import_kwh, export_kwh))
    end

    CSV.write(joinpath(out_case_dir, "case_load_summary.csv"), summary)

    loads_dss = joinpath(task_root, "dss", "timeseries_loads_$(case_name).dss")
    open(loads_dss, "w") do io
        println(io, "! Auto-generated Task 2 load definitions for $(case_name)")
        println(io, "! Signed LoadShape multipliers are used: positive = import/load, negative = export/injection.")
        println(io, "")
        for row in eachrow(summary)
            load_id = String(row.load_id)
            rel_shape = "..\\results\\task2_cases\\$(case_name)\\shapes\\$(load_id)_shape.csv"
            println(io, "New LoadShape.LS_$(load_id) npts=105120 interval=0.083333 mult=(file=$(rel_shape), col=1, header=yes)")
        end
        println(io, "")
        for row in eachrow(summary)
            load_id = String(row.load_id)
            bus = String(row.bus)
            phase = Int(row.phase)
            base_kw = Float64(row.base_kw)
            println(io, "New Load.$(load_id) bus1=$(bus).$(phase).4 phases=1 conn=wye kV=0.23 kW=$(round(base_kw, digits=4)) pf=0.98 yearly=LS_$(load_id)")
        end
    end

    step1_file = joinpath(task_root, "dss", "network_step1.dss")
    case_dss = joinpath(task_root, "dss", "network_$(case_name).dss")
    lines = readlines(step1_file)
    filtered = String[]
    for line in lines
        s = strip(line)
        startswith(s, "New Load.") && continue
        lowercase(s) == "solve" && continue
        push!(filtered, line)
    end
    open(case_dss, "w") do io
        println(io, "! Auto-generated Task 2 network file: $(case_name)")
        for line in filtered
            println(io, line)
        end
        println(io, "")
        println(io, "Redirect timeseries_loads_$(case_name).dss")
    end

    println("Built case $(case_name):")
    println("  ", loads_dss)
    println("  ", case_dss)
end

function build_all_cases(task_root::AbstractString)
    # Case 2: 15 PV customers, no batteries. SSO does not physically change PV-only profiles under this rule set.
    c2 = Dict{String,DataFrame}()
    for load_id in PV_LOADS
        c2[load_id] = build_case_profile(task_root, load_id; case_symbol=:case2_pv_only)
    end
    write_dss_for_case(task_root, "case2_pv_only", c2)
    write_dss_for_case(task_root, "case2_pv_only_SSO", c2)

    # Case 3: 15 PV customers, of which 10 have batteries/HEMS.
    for (case_name, cap, sso) in [("case3_pv_batt_10kWh", 10.0, false), ("case3_pv_batt_20kWh", 20.0, false), ("case3_pv_batt_10kWh_SSO", 10.0, true), ("case3_pv_batt_20kWh_SSO", 20.0, true)]
        c3 = Dict{String,DataFrame}()
        for load_id in PV_LOADS
            if load_id in HEMS_LOADS
                c3[load_id] = build_case_profile(task_root, load_id; case_symbol=:case3_hems, battery_capacity_kwh=cap, sso=sso)
            else
                c3[load_id] = build_case_profile(task_root, load_id; case_symbol=:case2_pv_only)
            end
        end
        write_dss_for_case(task_root, case_name, c3)
    end
end

function main()
    task_root = normpath(joinpath(@__DIR__, ".."))

    write_task2_node_selection(task_root)
    build_all_cases(task_root)
end

main()
