using CSV
using DataFrames
using Dates
using TimeZones
using Plots
using Statistics

const SYD = tz"Australia/Sydney"

function parse_zdt(s::AbstractString)
    return ZonedDateTime(strip(s))
end

function main()
    base_dir = joinpath(@__DIR__, "..")
    results_dir = joinpath(base_dir, "results")
    out_dir = joinpath(results_dir, "report_figures")
    mkpath(out_dir)

    year_df = CSV.read(joinpath(results_dir, "year_timeseries_results.csv"), DataFrame)
    unb_df  = CSV.read(joinpath(results_dir, "year_unbalance_timeseries.csv"), DataFrame)
    bus_df  = CSV.read(joinpath(results_dir, "worst_case_bus_voltages.csv"), DataFrame)

    year_df.ts_syd = parse_zdt.(String.(year_df.ts_syd))
    unb_df.ts_syd  = parse_zdt.(String.(unb_df.ts_syd))

    # ========= Annual downsampling =========
    step = 12
    yh = year_df[1:step:end, :]
    uh = unb_df[1:step:end, :]

    # Voltage year
    p1 = plot(
        yh.hour_from_year, yh.min_v,
        label="Min voltage",
        xlabel="Time (hour)",
        ylabel="Voltage (p.u.)",
        title="Annual Voltage Range",
        lw=2,
        legend=:bottomright
    )
    plot!(p1, yh.hour_from_year, yh.max_v, label="Max voltage", lw=2)
    savefig(p1, joinpath(out_dir, "fig_year_voltage.png"))

    # Power year
    p2 = plot(
        yh.hour_from_year, yh.total_p_kw,
        label="Total active power",
        xlabel="Time (hour)",
        ylabel="Power (kW)",
        title="Annual Feeder Active Power",
        lw=2,
        legend = :top,
        legendcolumns = 1
    )
    savefig(p2, joinpath(out_dir, "fig_year_power.png"))

    # PVUR
    p3 = plot(
        yh.hour_from_year, uh.max_pvur_pct,
        label="PVUR",
        xlabel="Time (hour)",
        ylabel="PVUR (%)",
        title="Annual Maximum PVUR",
        lw=2,
        legend=:topright
    )
    savefig(p3, joinpath(out_dir, "fig_year_pvur.png"))

    # VUF
    p4 = plot(
        yh.hour_from_year, uh.max_vuf_pct,
        label="VUF",
        xlabel="Time (hour)",
        ylabel="VUF (%)",
        title="Annual Maximum VUF",
        lw=2,
        legend=:topright
    )
    savefig(p4, joinpath(out_dir, "fig_year_vuf.png"))

    # ========= worst-case =========
    idx = argmin(year_df.min_v)

    window = 288
    s = max(1, idx-window)
    e = min(nrow(year_df), idx+window)

    yz = year_df[s:e, :]
    uz = unb_df[s:e, :]

    t = ((s:e) .- idx) .* (5/60)

    # Voltage zoom
    p5 = plot(
        t, yz.min_v,
        label="Min voltage",
        xlabel="Time relative to worst-case (hour)",
        ylabel="Voltage (p.u.)",
        title="Voltage Around Worst-Case Event",
        lw=2,
        legend=:bottomright
    )
    plot!(p5, t, yz.max_v, label="Max voltage", lw=2)
    vline!(p5, [0.0], label="Worst-case instant", ls=:dash)
    savefig(p5, joinpath(out_dir, "fig_worst_voltage.png"))

    # Power zoom
    p6 = plot(
        t, yz.total_p_kw,
        label="Total active power",
        xlabel="Time relative to worst-case (hour)",
        ylabel="Power (kW)",
        title="Feeder Power Around Worst-Case Event",
        lw=2,
        legend=:topright
    )
    vline!(p6, [0.0], label="Worst-case instant", ls=:dash)
    savefig(p6, joinpath(out_dir, "fig_worst_power.png"))

    # PVUR zoom
    p7 = plot(
        t, uz.max_pvur_pct,
        label="PVUR",
        xlabel="Time relative to worst-case (hour)",
        ylabel="PVUR (%)",
        title="PVUR Around Worst-Case Event",
        lw=2,
        legend=:topright
    )
    vline!(p7, [0.0], label="Worst-case instant", ls=:dash)
    savefig(p7, joinpath(out_dir, "fig_worst_pvur.png"))

    # VUF zoom
    p8 = plot(
        t, uz.max_vuf_pct,
        label="VUF",
        xlabel="Time relative to worst-case (hour)",
        ylabel="VUF (%)",
        title="VUF Around Worst-Case Event",
        lw=2,
        legend=:topright
    )
    vline!(p8, [0.0], label="Worst-case instant", ls=:dash)
    savefig(p8, joinpath(out_dir, "fig_worst_vuf.png"))

    # ========= Three-phase voltage =========
    focus = ["b4","b4a","b5","b6","b6a"]
    df = filter(r -> String(r.bus) in focus, bus_df)

    order = Dict(b=>i for (i,b) in enumerate(focus))
    df.o = [order[String(b)] for b in df.bus]
    sort!(df, :o)

    x = 1:nrow(df)

    p9 = plot(
        x, df.Va_pu,
        label="Phase A",
        xlabel="Bus",
        ylabel="Voltage (p.u.)",
        title="Worst-Case Bus Voltages",
        lw=2,
        marker=:circle,
        xticks=(x, df.bus),
        legend = (0.75, 0.5)
    )
    plot!(p9, x, df.Vb_pu, label="Phase B", lw=2, marker=:square)
    plot!(p9, x, df.Vc_pu, label="Phase C", lw=2, marker=:diamond)
    savefig(p9, joinpath(out_dir, "fig_bus_voltage.png"))

    println("\nReport-quality figures generated.")
end

main()