using CSV
using DataFrames
using Dates
using TimeZones
using Plots

const SYD = tz"Australia/Sydney"
const TS_FMT = dateformat"yyyy-mm-dd HH:MM:SSzzzz"

# Parse time strings with time zone offsets, for example:
# 2018-12-31 13:00:00+00:00
function parse_zdt(s::AbstractString)
    s2 = strip(s)
    tz = TimeZone(s2[end-5:end])   # Take the last six characters, for example +00:00
    return ZonedDateTime(DateTime(s2, TS_FMT), tz)
end

# Find the Monday of the week in which a certain date falls
function monday_start(d::Date)
    return d - Day(dayofweek(d) - 1)
end

function main()
    # ========= 1. File path =========
    filename = "5min_368133844.csv"
    csv_file = joinpath(@__DIR__, "..", "data", filename)

    println("Reading file:")
    println(csv_file)

    # ========= 2. Read CSV =========
    df = CSV.read(csv_file, DataFrame)

    println("\nOriginal column names:")
    println(names(df))

    # ========= 3. Parse time =========
    df.utc_timestamp = parse_zdt.(String.(df.utc_timestamp))
    df.localtime     = parse_zdt.(String.(df.localtime))

    # ========= 4. Clean data types =========
    df.site_id = string.(df.site_id)

   
    # Multiply the original 5-minute data by 12 and convert it to the hourly equivalent power order
    df.pv_generation = 12 .* Float64.(df.pv_generation) ./ 1000.0
df.total_load    = 12 .* Float64.(df.total_load) ./ 1000.0
    # ========= 5. Sort =========
    sort!(df, [:site_id, :utc_timestamp])

    # ========= 6. Add a local time column for Sydney =========
    df.ts_syd = astimezone.(df.utc_timestamp, Ref(SYD))

    # ========= 7. Simple cleaning =========
    # A negative PV is unreasonable and should be truncated to 0
    df.pv_clean = max.(df.pv_generation, 0.0)

    println("\nFirst 5 rows after cleaning:")
    println(first(df, 5))

    println("\nData size:")
    println(size(df))

    println("\nUnique site IDs:")
    println(unique(df.site_id))

    # ========= 8. Select the data of one week =========
    # Here we select the week that includes January 1, 2019
    ref_date = Date(2019, 1, 1)
    week_start_date = monday_start(ref_date)

    week_start = ZonedDateTime(DateTime(week_start_date), SYD)
    week_end   = week_start + Week(1)

    df_week = filter(row -> (row.ts_syd >= week_start) && (row.ts_syd < week_end), df)

    println("\nWeek start (Sydney): ", week_start)
    println("Week end   (Sydney): ", week_end)
    println("Rows in selected week: ", nrow(df_week))

    # ========= 9. Draw =========
    p = plot(
        df_week.ts_syd,
        df_week.total_load,
        label = "Total load",
        xlabel = "Sydney local time",
        ylabel = "Power",
        title = "One calendar week: load and PV"
    )

    plot!(
        p,
        df_week.ts_syd,
        df_week.pv_clean,
        label = "PV generation (clipped)"
    )

    # ========= 10. Save the image =========
    out_file = joinpath(@__DIR__, "..", "results", "week_profile_368133844.png")
    savefig(p, out_file)

    println("\nPlot saved to:")
    println(out_file)

    # ========= 11. Print statistics =========
    println("\nStatistics for selected week:")
    println("Load minimum = ", minimum(df_week.total_load))
    println("Load maximum = ", maximum(df_week.total_load))
    println("PV minimum   = ", minimum(df_week.pv_clean))
    println("PV maximum   = ", maximum(df_week.pv_clean))

    # ========= 12. Save the data of one week after cleaning (for continued use later) =========
    out_csv = joinpath(@__DIR__, "..", "results", "week_profile_368133844.csv")
    CSV.write(out_csv, df_week)

    println("\nWeek data saved to:")
    println(out_csv)
end

main()