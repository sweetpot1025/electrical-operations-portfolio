using OpenDSSDirect
using CSV
using DataFrames
using Plots

const dss = OpenDSSDirect

function main()
    dss_file = joinpath(@__DIR__, "..", "dss", "network_step2_timeseries.dss")
    out_csv  = joinpath(@__DIR__, "..", "results", "week1_timeseries_results.csv")
    out_fig1 = joinpath(@__DIR__, "..", "results", "week1_voltage_profile.png")
    out_fig2 = joinpath(@__DIR__, "..", "results", "week1_total_power.png")

    println("Compiling DSS file:")
    println(dss_file)

    dss.Text.Command("compile $dss_file")

    bus_names = dss.Circuit.AllBusNames()

    results = DataFrame(
        step = Int[],
        hour = Float64[],
        min_v = Float64[],
        max_v = Float64[],
        min_bus = String[],
        max_bus = String[],
        total_p_kw = Float64[],
        total_q_kvar = Float64[],
        converged = Bool[]
    )

    # 1 week = 7 days = 7*24*12 = 2016 points
    nsteps = 2016

    for k in 1:nsteps
        total_seconds = (k - 1) * 300
        hour_val = total_seconds ÷ 3600
        sec_val  = total_seconds % 3600

        dss.Text.Command("set mode=yearly")
        dss.Text.Command("set stepsize=5m")
        dss.Text.Command("set number=1")
        dss.Text.Command("set hour=$(hour_val)")
        dss.Text.Command("set sec=$(sec_val)")
        dss.Text.Command("solve")

        conv = dss.Solution.Converged()

        min_v = 999.0
        max_v = 0.0
        min_bus = ""
        max_bus = ""

        for bus in bus_names
            dss.Circuit.SetActiveBus(bus)
            vpu = dss.Bus.puVmagAngle()

            mags = vpu[1:2:end]
            phase_mags = mags[1:min(3, length(mags))]

            for v in phase_mags
                if v > 0.0
                    if v < min_v
                        min_v = v
                        min_bus = bus
                    end
                    if v > max_v
                        max_v = v
                        max_bus = bus
                    end
                end
            end
        end

        s_total = dss.Circuit.TotalPower()
        total_p_kw = -real(s_total)
        total_q_kvar = -imag(s_total)

        push!(results, (
            k,
            (k - 1) * 5 / 60,
            min_v,
            max_v,
            min_bus,
            max_bus,
            total_p_kw,
            total_q_kvar,
            conv
        ))
    end

    CSV.write(out_csv, results)

    println("\nSaved results to:")
    println(out_csv)

    println("\nFirst 10 rows:")
    println(first(results, 10))

    println("\nSummary:")
    println("Minimum voltage over week = ", minimum(results.min_v))
    println("Maximum voltage over week = ", maximum(results.max_v))
    println("Minimum total P over week = ", minimum(results.total_p_kw))
    println("Maximum total P over week = ", maximum(results.total_p_kw))

    if all(results.converged)
        println("All 2016 time steps converged.")
    else
        println("Warning: some time steps did not converge.")
    end

    # 图 1：Minimum/maximum voltage
    p1 = plot(
        results.hour, results.min_v,
        label = "Minimum phase voltage",
        xlabel = "Hour from start of week",
        ylabel = "Voltage [p.u.]",
        title = "Week 1 voltage range"
    )
    plot!(p1, results.hour, results.max_v, label = "Maximum phase voltage")
    savefig(p1, out_fig1)

    println("\nSaved voltage plot to:")
    println(out_fig1)

    # 图 2：Total active power
    p2 = plot(
        results.hour, results.total_p_kw,
        label = "Total active power",
        xlabel = "Hour from start of week",
        ylabel = "Power [kW]",
        title = "Week 1 total feeder power"
    )
    savefig(p2, out_fig2)

    println("\nSaved power plot to:")
    println(out_fig2)
end

main()