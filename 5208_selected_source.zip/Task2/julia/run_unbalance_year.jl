using OpenDSSDirect
using CSV
using DataFrames
using Plots
using Statistics

const dss = OpenDSSDirect

# The symmetric component constant a = e^(j120°)
const a = cis(2π/3)

function phase_phasors_pu()
    nodes = dss.Bus.Nodes()
    vma = dss.Bus.puVmagAngle()

    ph = Dict{Int,ComplexF64}()

    for i in 1:length(nodes)
        node = Int(nodes[i])
        mag = Float64(vma[2i - 1])
        ang_deg = Float64(vma[2i])

        if node in (1, 2, 3) && mag > 0.0
            ph[node] = mag * cis(deg2rad(ang_deg))
        end
    end

    return ph
end

function compute_pvur_vuf(Va::ComplexF64, Vb::ComplexF64, Vc::ComplexF64)
    mags = [abs(Va), abs(Vb), abs(Vc)]
    Vavg = mean(mags)

    # PVUR [%]
    pvur = maximum(abs.(mags .- Vavg)) / Vavg * 100

    # VUF [%]
    V1 = (Va + a * Vb + a^2 * Vc) / 3   # positive sequence
    V2 = (Va + a^2 * Vb + a * Vc) / 3   # negative sequence
    vuf = abs(V2) / abs(V1) * 100

    return pvur, vuf
end

function main()
    dss_file = joinpath(@__DIR__, "..", "dss", "network_step2_timeseries.dss")
    ref_profile_file = joinpath(@__DIR__, "..", "results", "profiles", "L1_profile.csv")

    out_time_csv   = joinpath(@__DIR__, "..", "results", "year_unbalance_timeseries.csv")
    out_bus_csv    = joinpath(@__DIR__, "..", "results", "year_unbalance_bus_summary.csv")
    out_fig_pvur   = joinpath(@__DIR__, "..", "results", "year_max_pvur.png")
    out_fig_vuf    = joinpath(@__DIR__, "..", "results", "year_max_vuf.png")

    println("Compiling DSS file:")
    println(dss_file)

    dss.Text.Command("compile $dss_file")

    ref_df = CSV.read(ref_profile_file, DataFrame)
    nsteps = nrow(ref_df)

    println("\nNumber of yearly steps:")
    println(nsteps)

    bus_names = dss.Circuit.AllBusNames()

    # At each moment, what is the largest PVUR/VUF in the network and on which bus does it occur
    ts_table = DataFrame(
        step = Int[],
        ts_syd = String[],
        max_pvur_pct = Float64[],
        max_pvur_bus = String[],
        max_vuf_pct = Float64[],
        max_vuf_bus = String[],
        converged = Bool[]
    )

    # The worst value of each bus throughout the year
    bus_peak_pvur = Dict{String,Float64}()
    bus_peak_vuf  = Dict{String,Float64}()
    bus_time_pvur = Dict{String,String}()
    bus_time_vuf  = Dict{String,String}()

    for bus in bus_names
        bus_peak_pvur[bus] = -1.0
        bus_peak_vuf[bus]  = -1.0
        bus_time_pvur[bus] = ""
        bus_time_vuf[bus]  = ""
    end

    for k in 1:nsteps
        total_seconds = (k - 1) * 300
        hour_val = total_seconds ÷ 3600
        sec_val  = total_seconds % 3600

        dss.Text.Command("set mode=yearly")
        dss.Text.Command("set stepsize=5m")
        dss.Text.Command("set number=1")
        dss.Text.Command("set hour=$(hour_val)")
        dss.Text.Command("set sec=$(sec_val)")
        dss.Text.Command("solve")

        conv = dss.Solution.Converged()

        max_pvur = -1.0
        max_pvur_bus = ""
        max_vuf = -1.0
        max_vuf_bus = ""

        for bus in bus_names
            dss.Circuit.SetActiveBus(bus)
            ph = phase_phasors_pu()

            # Only calculate for buses with three-phase voltages
            if all(haskey(ph, p) for p in (1, 2, 3))
                Va = ph[1]
                Vb = ph[2]
                Vc = ph[3]

                pvur, vuf = compute_pvur_vuf(Va, Vb, Vc)

                if pvur > max_pvur
                    max_pvur = pvur
                    max_pvur_bus = bus
                end

                if vuf > max_vuf
                    max_vuf = vuf
                    max_vuf_bus = bus
                end

                if pvur > bus_peak_pvur[bus]
                    bus_peak_pvur[bus] = pvur
                    bus_time_pvur[bus] = string(ref_df.ts_syd[k])
                end

                if vuf > bus_peak_vuf[bus]
                    bus_peak_vuf[bus] = vuf
                    bus_time_vuf[bus] = string(ref_df.ts_syd[k])
                end
            end
        end

        push!(ts_table, (
            k,
            string(ref_df.ts_syd[k]),
            max_pvur,
            max_pvur_bus,
            max_vuf,
            max_vuf_bus,
            conv
        ))

        if k % 5000 == 0 || k == nsteps
            println("Completed step $k / $nsteps")
        end
    end

    CSV.write(out_time_csv, ts_table)

    bus_table = DataFrame(
        bus = String[],
        worst_pvur_pct = Float64[],
        worst_pvur_time = String[],
        worst_vuf_pct = Float64[],
        worst_vuf_time = String[]
    )

    for bus in bus_names
        if bus_peak_pvur[bus] >= 0.0
            push!(bus_table, (
                bus,
                bus_peak_pvur[bus],
                bus_time_pvur[bus],
                bus_peak_vuf[bus],
                bus_time_vuf[bus]
            ))
        end
    end

    sort!(bus_table, :worst_pvur_pct, rev=true)
    CSV.write(out_bus_csv, bus_table)

    println("\nSaved yearly unbalance time-series to:")
    println(out_time_csv)

    println("\nSaved yearly bus-summary to:")
    println(out_bus_csv)

    # The worst PVUR/VUF on the entire network
    idx_pvur = argmax(ts_table.max_pvur_pct)
    idx_vuf  = argmax(ts_table.max_vuf_pct)

    println("\nKey unbalance summary:")
    println("Worst PVUR over year = ", ts_table.max_pvur_pct[idx_pvur], " % at bus ",
            ts_table.max_pvur_bus[idx_pvur], " at ", ts_table.ts_syd[idx_pvur])

    println("Worst VUF over year = ", ts_table.max_vuf_pct[idx_vuf], " % at bus ",
            ts_table.max_vuf_bus[idx_vuf], " at ", ts_table.ts_syd[idx_vuf])

    if all(ts_table.converged)
        println("All yearly time steps converged during unbalance scan.")
    else
        println("Warning: some yearly time steps did not converge during unbalance scan.")
    end

    # 图 1：The maximum PVUR across the entire network at every moment
    p1 = plot(
        0:(nsteps-1),
        ts_table.max_pvur_pct,
        label = "Network max PVUR",
        xlabel = "5-minute step from start of year",
        ylabel = "PVUR [%]",
        title = "Full-year maximum PVUR"
    )
    savefig(p1, out_fig_pvur)

    println("\nSaved PVUR plot to:")
    println(out_fig_pvur)

    # 图 2：The maximun VUF across the entire network at every moment
    p2 = plot(
        0:(nsteps-1),
        ts_table.max_vuf_pct,
        label = "Network max VUF",
        xlabel = "5-minute step from start of year",
        ylabel = "VUF [%]",
        title = "Full-year maximum VUF"
    )
    savefig(p2, out_fig_vuf)

    println("\nSaved VUF plot to:")
    println(out_fig_vuf)
end

main()