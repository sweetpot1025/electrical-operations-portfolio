using OpenDSSDirect
using CSV
using DataFrames

const dss = OpenDSSDirect

function main()
    dss_file = joinpath(@__DIR__, "..", "dss", "network_step2_timeseries.dss")
    year_file = joinpath(@__DIR__, "..", "results", "year_timeseries_results.csv")
    out_csv = joinpath(@__DIR__, "..", "results", "worst_case_bus_voltages.csv")

    println("Reading yearly results:")
    println(year_file)

    year_df = CSV.read(year_file, DataFrame)

    # Look for the worst moment of the year
    idx = argmin(year_df.min_v)

    worst_step = year_df.step[idx]
    worst_time = year_df.ts_syd[idx]
    worst_hour_from_year = year_df.hour_from_year[idx]
    worst_min_v = year_df.min_v[idx]
    worst_min_bus = year_df.min_bus[idx]

    println("\nWorst-case found:")
    println("Step = ", worst_step)
    println("Time = ", worst_time)
    println("Minimum voltage = ", worst_min_v)
    println("Minimum-voltage bus from yearly scan = ", worst_min_bus)

    # Restore hour/sec from hour_from_year
    hour_val = floor(Int, worst_hour_from_year)
    sec_val = round(Int, (worst_hour_from_year - hour_val) * 3600)

    println("\nRe-solving worst-case snapshot:")
    println("hour = ", hour_val)
    println("sec  = ", sec_val)

    dss.Text.Command("compile $dss_file")
    dss.Text.Command("set mode=yearly")
    dss.Text.Command("set stepsize=5m")
    dss.Text.Command("set number=1")
    dss.Text.Command("set hour=$(hour_val)")
    dss.Text.Command("set sec=$(sec_val)")
    dss.Text.Command("solve")

    println("Converged = ", dss.Solution.Converged())

    bus_names = dss.Circuit.AllBusNames()

    bus_table = DataFrame(
        bus = String[],
        Va_pu = Float64[],
        Vb_pu = Float64[],
        Vc_pu = Float64[],
        min_phase_v = Float64[]
    )

    for bus in bus_names
        dss.Circuit.SetActiveBus(bus)
        vpu = dss.Bus.puVmagAngle()

        mags = vpu[1:2:end]
        phase_mags = mags[1:min(3, length(mags))]

        Va = length(phase_mags) >= 1 ? phase_mags[1] : NaN
        Vb = length(phase_mags) >= 2 ? phase_mags[2] : NaN
        Vc = length(phase_mags) >= 3 ? phase_mags[3] : NaN

        vals = [x for x in [Va, Vb, Vc] if !isnan(x) && x > 0.0]
        min_phase = minimum(vals)

        push!(bus_table, (bus, Va, Vb, Vc, min_phase))
    end

    sort!(bus_table, :min_phase_v)

    CSV.write(out_csv, bus_table)

    println("\nSaved bus-voltage table to:")
    println(out_csv)

    println("\n10 weakest buses at worst-case time:")
    println(first(bus_table, 10))

    # Casually take a look at a few key buses
    focus_buses = ["b4", "b4a", "b5", "b6", "b6a"]
    println("\nFocused buses:")
    println(filter(row -> row.bus in focus_buses, bus_table))
end

main()