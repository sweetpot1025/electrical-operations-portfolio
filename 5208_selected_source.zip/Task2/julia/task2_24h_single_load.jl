using CSV
using DataFrames
using Plots
using Statistics

include("hems_rule_based.jl")

function plot_dispatch(df::DataFrame, out_png::AbstractString; title::AbstractString="24-hour HEMS dispatch")
    t = 0:(nrow(df)-1)

    p = plot(
        t,
        df.demand_kw,
        label="Native demand",
        xlabel="Hour",
        ylabel="Power [kW]",
        title=title,
        grid=true,
        lw=2,
        legend=:outertopright
    )

    plot!(p, t, df.pv_available_kw,
        label="Rooftop PV",
        lw=2
    )

    plot!(p, t, df.battery_discharge_kw,
    label="Battery discharge",
    lw=2
)

plot!(p, t, -df.battery_charge_kw,
    label="Battery charge",
    lw=2
)

plot!(p, t, df.grid_import_kw,
    label="Grid import",
    lw=2
)

plot!(p, t, -df.grid_export_kw,
    label="Grid export",
    lw=2
)

    hline!(p, [0.0], label="", lw=1)

    savefig(p, out_png)
end

function run_case(task_root::AbstractString; load_id="L26", start_hour_index=1, battery_capacity_kwh=10.0, sso=false, case_name="case")
    out_dir = joinpath(task_root, "results", "task2_24h")
    mkpath(out_dir)

    df5 = read_allocated_profile(task_root, load_id)
    dfh = aggregate_hourly(df5)

    start_hour_index + 23 <= nrow(dfh) || error("start_hour_index is too close to the end of the profile")
    day = dfh[start_hour_index:start_hour_index+23, :]

    result = simulate_hems_rule_based(
        Float64.(day.load_kw),
        Float64.(day.pv_kw);
        ts=day.ts_syd,
        dt_hours=1.0,
        battery_capacity_kwh=battery_capacity_kwh,
        battery_power_kw=5.0,
        eta=0.90,
        initial_soc_kwh=0.5*battery_capacity_kwh,
        min_soc_kwh=0.0,
        sso=sso,
        allow_grid_charging_sso=true
    )

    csv_file = joinpath(out_dir, "$(case_name)_dispatch.csv")
    png_file = joinpath(out_dir, "$(case_name)_dispatch.png")
    CSV.write(csv_file, result)
    plot_dispatch(result, png_file; title="$(case_name): load $(load_id), battery $(battery_capacity_kwh) kWh")

    daily_cost = result.total_cost[1]
    import_energy = sum(result.grid_import_kw)
    export_energy = sum(result.grid_export_kw)
    peak_demand = maximum(result.demand_kw)
    daily_load_energy = sum(result.demand_kw)

    battery_charge_energy = sum(result.battery_charge_kw)
    battery_discharge_energy = sum(result.battery_discharge_kw)
    soc_trace = vcat(result.soc_start_kwh[1], result.soc_end_kwh)
    final_soc = result.soc_end_kwh[end]
    min_soc = minimum(soc_trace)
    max_soc = maximum(soc_trace)
    pv_energy = sum(result.pv_available_kw)
    curtailed_energy = sum(result.pv_curtailed_kw)

    summary = DataFrame(
        metric = [
            "load_id",
            "battery_capacity_kwh",
            "sso",
            "daily_cost_AUD",
            "grid_import_kWh",
            "grid_export_kWh",
            "battery_charge_kWh",
            "battery_discharge_kWh",
            "initial_soc_kWh",
            "final_soc_kWh",
            "min_soc_kWh",
            "max_soc_kWh",
            "pv_energy_kWh",
            "curtailed_pv_kWh",
            "peak_native_demand_kW",
            "daily_native_energy_kWh"
        ],
        value = string.([
            load_id,
            battery_capacity_kwh,
            sso,
            daily_cost,
            import_energy,
            export_energy,
            battery_charge_energy,
            battery_discharge_energy,
            0.5*battery_capacity_kwh,
            final_soc,
            min_soc,
            max_soc,
            pv_energy,
            curtailed_energy,
            peak_demand,
            daily_load_energy
        ])
    )
    CSV.write(joinpath(out_dir, "$(case_name)_summary.csv"), summary)

    println("Saved $(case_name) results:")
    println("  ", csv_file)
    println("  ", png_file)
    println("  daily cost = AUD ", round(daily_cost, digits=4))
end

function main()
    task_root = normpath(joinpath(@__DIR__, ".."))

    # Choose one Task 1 load and one 24-hour window. L26 is at b6a phase A, useful because b6a was the weakest bus in Task 1.
    load_id = "L26"
    start_hour_index = 1       # Change this to select another day/window.

    run_case(task_root; load_id=load_id, start_hour_index=start_hour_index, battery_capacity_kwh=10.0, sso=false, case_name="single_10kWh_normal")
    run_case(task_root; load_id=load_id, start_hour_index=start_hour_index, battery_capacity_kwh=20.0, sso=false, case_name="single_20kWh_normal")
    run_case(task_root; load_id=load_id, start_hour_index=start_hour_index, battery_capacity_kwh=10.0, sso=true, case_name="single_10kWh_SSO")
    run_case(task_root; load_id=load_id, start_hour_index=start_hour_index, battery_capacity_kwh=20.0, sso=true, case_name="single_20kWh_SSO")
end

main()
