using CSV
using DataFrames
using Dates
using Statistics

include("hems_optimisation.jl")
include("hems_rule_based.jl")   # reused for read_allocated_profile()

const PV_LOADS   = ["L4", "L7", "L10", "L13", "L16", "L17", "L18",
                    "L22", "L23", "L24", "L25", "L26", "L27", "L34", "L35"]
const HEMS_LOADS = ["L10", "L13", "L16", "L17",
                    "L22", "L23", "L24", "L25", "L26", "L27"]

function read_task1_demand_profile(task_root, load_id)
    file = joinpath(task_root, "results", "profiles", "$(load_id)_profile.csv")
    df   = CSV.read(file, DataFrame)
    return DataFrame(ts_syd = df.ts_syd, demand_kw = Float64.(df.p_kw))
end

# ─────────────────────────────────────────────────────────────────────────────
# Full-year optimisation, one day at a time.
# FIX 1: Removed dead `terminal` variable.
# FIX 2: SOC is carried forward across days (not hard-reset to 50% every day).
#         This lets the battery shift energy across midnight when economical.
#         The final day of the year is constrained to return to initial SOC so
#         the annual simulation is energetically balanced.
# ─────────────────────────────────────────────────────────────────────────────
function optimise_full_year_by_day(
        task_root::AbstractString,
        load_id::String;
        battery_capacity_kwh::Float64 = 10.0,
        sso::Bool = false)

    demand_df = read_task1_demand_profile(task_root, load_id)
    raw_df    = read_allocated_profile(task_root, load_id)
    n         = min(nrow(demand_df), nrow(raw_df), TARGET_NPTS_5MIN)

    demand_kw = Float64.(demand_df.demand_kw[1:n])
    pv_kw     = Float64.(raw_df.pv_kw[1:n])
    ts        = raw_df.ts_syd[1:n]

    out_parts = DataFrame[]
    soc0      = 0.5 * battery_capacity_kwh   # initial SOC = 50 %
    day_n     = 288                           # 5-min steps per day
    k         = 1

    total_days = ceil(Int, n / day_n)
    day_idx    = 0

    while k <= n
        day_idx += 1
        j = min(k + day_n - 1, n)

        # Only enforce terminal-SOC constraint on the very last slice so the
        # battery returns to its starting level at year-end.
        is_last_day = (day_idx == total_days)

        res = solve_hems_optimisation(
            demand_kw[k:j],
            pv_kw[k:j];
            ts                      = ts[k:j],
            dt_hours                = 5 / 60,
            battery_capacity_kwh    = battery_capacity_kwh,
            battery_power_kw        = 5.0,
            eta                     = 0.90,
            initial_soc_kwh         = soc0,
            min_soc_kwh             = 0.0,
            terminal_soc_equal_initial = is_last_day,
            feed_in_tariff          = 0.08,
            sso                     = sso
        )

        # Carry the actual end-of-day SOC into the next day.
        soc0 = res.soc_end_kwh[end]

        push!(out_parts, res)
        k = j + 1
    end

    prof       = vcat(out_parts...)
    prof.step  = 1:nrow(prof)

    return DataFrame(
        ts_syd              = demand_df.ts_syd[1:nrow(prof)],
        grid_net_kw         = Float64.(prof.grid_net_kw),
        demand_kw           = demand_kw[1:nrow(prof)],
        pv_kw               = pv_kw[1:nrow(prof)],
        battery_charge_kw   = Float64.(prof.battery_charge_kw),
        battery_discharge_kw= Float64.(prof.battery_discharge_kw),
        soc_end_kwh         = Float64.(prof.soc_end_kwh),
        grid_import_kw      = Float64.(prof.grid_import_kw),
        grid_export_kw      = Float64.(prof.grid_export_kw),
        pv_curtailed_kw     = Float64.(prof.pv_curtailed_kw)
    )
end

function build_case_profile(
        task_root::AbstractString,
        load_id::String;
        case_symbol::Symbol,
        battery_capacity_kwh::Float64 = 10.0,
        sso::Bool = false)

    demand_df  = read_task1_demand_profile(task_root, load_id)
    raw_df     = read_allocated_profile(task_root, load_id)
    n          = min(nrow(demand_df), nrow(raw_df), TARGET_NPTS_5MIN)
    demand_kw  = Float64.(demand_df.demand_kw[1:n])
    pv_kw      = Float64.(raw_df.pv_kw[1:n])

    if case_symbol == :case2_pv_only
        net_kw = demand_kw .- pv_kw
        return DataFrame(ts_syd     = demand_df.ts_syd[1:n],
                         grid_net_kw = net_kw,
                         demand_kw   = demand_kw,
                         pv_kw       = pv_kw)

    elseif case_symbol == :case3_optimised_hems
        return optimise_full_year_by_day(task_root, load_id;
                                         battery_capacity_kwh = battery_capacity_kwh,
                                         sso = sso)
    else
        error("Unknown case_symbol=$case_symbol")
    end
end

function write_dss_for_case(
        task_root::AbstractString,
        case_name::String,
        case_profiles::Dict{String,DataFrame})

    alloc       = CSV.read(joinpath(task_root, "data", "load_allocation.csv"), DataFrame)
    out_case_dir= joinpath(task_root, "results", "task3_cases", case_name)
    profiles_dir= joinpath(out_case_dir, "profiles")
    shapes_dir  = joinpath(out_case_dir, "shapes")
    mkpath(profiles_dir)
    mkpath(shapes_dir)

    summary = DataFrame(load_id       = String[],
                         bus           = String[],
                         phase         = Int[],
                         base_kw       = Float64[],
                         annual_import_kwh = Float64[],
                         annual_export_kwh = Float64[])

    for row in eachrow(alloc)
        load_id = String(row.load_id)
        bus     = String(row.bus)
        phase   = Int(row.phase)

        if haskey(case_profiles, load_id)
            prof = case_profiles[load_id]
        else
            base_prof = read_task1_demand_profile(task_root, load_id)
            prof = DataFrame(ts_syd      = base_prof.ts_syd,
                             grid_net_kw = base_prof.demand_kw,
                             demand_kw   = base_prof.demand_kw,
                             pv_kw       = zeros(nrow(base_prof)))
        end

        CSV.write(joinpath(profiles_dir, "$(load_id)_profile.csv"), prof)

        net      = Float64.(prof.grid_net_kw)
        base_kw  = maximum(abs.(net))
        base_kw < 1e-6 && (base_kw = 1.0)

        CSV.write(joinpath(shapes_dir, "$(load_id)_shape.csv"),
                  DataFrame(mult = net ./ base_kw))

        import_kwh = sum(max.(net,  0.0)) / 12.0
        export_kwh = sum(max.(-net, 0.0)) / 12.0
        push!(summary, (load_id, bus, phase, base_kw, import_kwh, export_kwh))
    end

    CSV.write(joinpath(out_case_dir, "case_load_summary.csv"), summary)

    # ── Write timeseries_loads_task3_<case_name>.dss ──
    loads_dss = joinpath(task_root, "dss", "timeseries_loads_task3_$(case_name).dss")
    open(loads_dss, "w") do io
        println(io, "! Auto-generated Task 3 optimised load definitions for $(case_name)")
        println(io, "! Signed multipliers: positive = import/load, negative = export/injection.")
        println(io, "")
        for row in eachrow(summary)
            lid       = String(row.load_id)
            rel_shape = "..\\results\\task3_cases\\$(case_name)\\shapes\\$(lid)_shape.csv"
            println(io, "New LoadShape.LS_$(lid) npts=$(TARGET_NPTS_5MIN) interval=0.083333 mult=(file=$(rel_shape), col=1, header=yes)")
        end
        println(io, "")
        for row in eachrow(summary)
            lid = String(row.load_id)
            println(io, "New Load.$(lid) bus1=$(row.bus).$(Int(row.phase)).4 phases=1 conn=wye kV=0.23 kW=$(round(Float64(row.base_kw), digits=4)) pf=0.98 yearly=LS_$(lid)")
        end
    end

    # ── Write network_task3_<case_name>.dss (copy of step1 without static loads) ──
    step1_file = joinpath(task_root, "dss", "network_step1.dss")
    case_dss   = joinpath(task_root, "dss", "network_task3_$(case_name).dss")
    lines      = readlines(step1_file)
    filtered   = String[]
    for line in lines
        s = strip(line)
        startswith(s, "New Load.") && continue
        lowercase(s) == "solve"    && continue
        push!(filtered, line)
    end
    open(case_dss, "w") do io
        println(io, "! Auto-generated Task 3 network file: $(case_name)")
        for line in filtered
            println(io, line)
        end
        println(io, "")
        println(io, "Redirect timeseries_loads_task3_$(case_name).dss")
    end

    println("Built Task 3 case $(case_name):")
    println("  ", loads_dss)
    println("  ", case_dss)
end

function build_all_task3_cases(task_root::AbstractString)
    # ── Case 2: PV only (no battery) ──────────────────────────────────────────
    c2 = Dict{String,DataFrame}()
    for load_id in PV_LOADS
        c2[load_id] = build_case_profile(task_root, load_id; case_symbol = :case2_pv_only)
    end
    write_dss_for_case(task_root, "case2_pv_only", c2)

    # For Case 2 with SSO: no battery exists, so SSO does not change the physical
    # net-load profile (there is nothing to charge during free-electricity hours).
    # The shape files are therefore identical to non-SSO Case 2.  We write the
    # same profiles to a dedicated directory so the DSS redirect path is correct.
    write_dss_for_case(task_root, "case2_pv_only_SSO", c2)

    # ── Case 3: HEMS with battery (optimisation-based) ────────────────────────
    for (case_name, cap, sso) in [
            ("case3_pv_batt_10kWh_opt",     10.0, false),
            ("case3_pv_batt_20kWh_opt",     20.0, false),
            ("case3_pv_batt_10kWh_SSO_opt", 10.0, true),
            ("case3_pv_batt_20kWh_SSO_opt", 20.0, true)]

        c3 = Dict{String,DataFrame}()
        for load_id in PV_LOADS
            if load_id in HEMS_LOADS
                c3[load_id] = build_case_profile(task_root, load_id;
                                                  case_symbol          = :case3_optimised_hems,
                                                  battery_capacity_kwh = cap,
                                                  sso                  = sso)
            else
                # PV-only node (no battery): use Case 2 profile regardless of SSO
                c3[load_id] = build_case_profile(task_root, load_id; case_symbol = :case2_pv_only)
            end
        end
        write_dss_for_case(task_root, case_name, c3)
    end
end

function main()
    task_root = normpath(joinpath(@__DIR__, ".."))
    build_all_task3_cases(task_root)
end

main()
