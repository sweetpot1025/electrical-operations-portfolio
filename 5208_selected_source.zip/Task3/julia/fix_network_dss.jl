"""
fix_network_dss.jl
────────────────────────────────────────────────────────────────────────────
Patches all network_*.dss files so that LineSpacing and LineGeometry use
    nconds=4 nphases=3      (correct: 3 phase conductors + 1 neutral)
instead of the incorrect
    nconds=4 nphases=4

Run once from the scripts/ directory:
    julia fix_network_dss.jl
"""

dss_dir = normpath(joinpath(@__DIR__, "..", "dss"))

targets = filter(f -> startswith(f, "network_") && endswith(f, ".dss"),
                 readdir(dss_dir))

patched = 0
for fname in targets
    fpath = joinpath(dss_dir, fname)
    original = read(fpath, String)

    fixed = replace(original,
        "nconds=4 nphases=4 x=" => "nconds=4 nphases=3 x=",   # LineSpacing line
        "nconds=4 nphases=4 spacing=" => "nconds=4 nphases=3 spacing="  # LineGeometry line
    )

    if fixed != original
        write(fpath, fixed)
        println("Patched: $fname")
        patched += 1
    else
        println("No change needed: $fname")
    end
end

println("\nDone. $patched file(s) patched.")
