using CSV
using DataFrames
using Plots
using Statistics

include("hems_optimisation.jl")

function plot_24h(df::DataFrame, out_png::AbstractString; title="Task 3 HEMS optimisation")
    t = 0:(nrow(df)-1)

    p = plot(
        t,
        df.demand_kw,
        label = "Native demand",
        xlabel = "Hour",
        ylabel = "Power [kW]",
        title = title,
        lw = 2,
        grid = true,
        legend = :outerright,
        size = (1300, 750),
        left_margin = 12Plots.mm,
        right_margin = 25Plots.mm,
        top_margin = 10Plots.mm,
        bottom_margin = 10Plots.mm
    )

    plot!(p, t, df.pv_available_kw, label = "Rooftop PV", lw = 2)
    plot!(p, t, df.battery_charge_kw, label = "Battery charge", lw = 2)
    plot!(p, t, df.battery_discharge_kw, label = "Battery discharge", lw = 2)
    plot!(p, t, df.grid_import_kw, label = "Grid import", lw = 2)
    plot!(p, t, df.grid_export_kw, label = "Grid export", lw = 2)

    savefig(p, out_png)
end

function run_24h_case(
    task_root::AbstractString;
    load_id::String="L26",
    start_hour_index::Int=1,
    battery_capacity_kwh::Float64=10.0,
    sso::Bool=false,
    case_name::String="case"
)
    out_dir = joinpath(task_root, "results", "task3_24h")
    mkpath(out_dir)

    df5 = read_allocated_profile(task_root, load_id)
    dfh = aggregate_hourly(df5)

    start_hour_index + 23 <= nrow(dfh) || error("start_hour_index is too close to the end of the profile")

    day = dfh[start_hour_index:start_hour_index+23, :]

    res = solve_hems_optimisation(
        Float64.(day.load_kw),
        Float64.(day.pv_kw);
        ts = day.ts_syd,
        dt_hours = 1.0,
        battery_capacity_kwh = battery_capacity_kwh,
        battery_power_kw = 5.0,
        eta = 0.90,
        initial_soc_kwh = 0.5 * battery_capacity_kwh,
        min_soc_kwh = 0.0,
        feed_in_tariff = 0.08,
        sso = sso,
        terminal_soc_equal_initial = true,
        cycling_penalty = 0.0001
    )

    csv_file = joinpath(out_dir, "$(case_name)_dispatch.csv")
    png_file = joinpath(out_dir, "$(case_name)_dispatch.png")
    summary_file = joinpath(out_dir, "$(case_name)_summary.csv")

    CSV.write(csv_file, res)

    title_text = replace(case_name, "_" => " ")
    plot_24h(
        res,
        png_file;
        title = "Task 3 HEMS Optimisation - $(title_text), load $(load_id), battery $(battery_capacity_kwh) kWh"
    )

    objective = res.objective_value[1]
    import_energy = sum(res.grid_import_kw)
    export_energy = sum(res.grid_export_kw)
    charge_energy = sum(res.battery_charge_kw)
    discharge_energy = sum(res.battery_discharge_kw)
    pv_energy = sum(res.pv_available_kw)
    curtailed_energy = sum(res.pv_curtailed_kw)
    daily_demand_energy = sum(res.demand_kw)

    soc_trace = vcat(res.soc_start_kwh[1], res.soc_end_kwh)
    min_soc = minimum(soc_trace)
    max_soc = maximum(soc_trace)
    final_soc = res.soc_end_kwh[end]

    summary = DataFrame(
        metric = [
            "load_id",
            "battery_capacity_kwh",
            "sso",
            "objective_value_AUD",
            "grid_import_kWh",
            "grid_export_kWh",
            "battery_charge_kWh",
            "battery_discharge_kWh",
            "pv_available_kWh",
            "pv_curtailed_kWh",
            "daily_native_demand_kWh",
            "initial_soc_kWh",
            "final_soc_kWh",
            "min_soc_kWh",
            "max_soc_kWh"
        ],
        value = string.([
            load_id,
            battery_capacity_kwh,
            sso,
            objective,
            import_energy,
            export_energy,
            charge_energy,
            discharge_energy,
            pv_energy,
            curtailed_energy,
            daily_demand_energy,
            0.5 * battery_capacity_kwh,
            final_soc,
            min_soc,
            max_soc
        ])
    )

    CSV.write(summary_file, summary)

    println("Saved $(case_name):")
    println("  ", csv_file)
    println("  ", png_file)
    println("  ", summary_file)
    println("objective = AUD ", objective)
end

function main()
    task_root = normpath(joinpath(@__DIR__, ".."))

    load_id = "L26"
    start_hour_index = 1

    run_24h_case(
        task_root;
        load_id = load_id,
        start_hour_index = start_hour_index,
        battery_capacity_kwh = 10.0,
        sso = false,
        case_name = "opt_single_10kWh_normal"
    )

    run_24h_case(
        task_root;
        load_id = load_id,
        start_hour_index = start_hour_index,
        battery_capacity_kwh = 20.0,
        sso = false,
        case_name = "opt_single_20kWh_normal"
    )

    run_24h_case(
        task_root;
        load_id = load_id,
        start_hour_index = start_hour_index,
        battery_capacity_kwh = 10.0,
        sso = true,
        case_name = "opt_single_10kWh_SSO"
    )

    run_24h_case(
        task_root;
        load_id = load_id,
        start_hour_index = start_hour_index,
        battery_capacity_kwh = 20.0,
        sso = true,
        case_name = "opt_single_20kWh_SSO"
    )
end

main()