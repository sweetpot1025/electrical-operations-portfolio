"""
apply_task3_case4_doe.jl
═══════════════════════════════════════════════════════════════════════════════
Applies the per-node, per-hour Dynamic Operating Envelopes computed by
solve_task3_case4_socp_doe.jl to the full-year HEMS profiles.

Inputs
──────
  results/task3_case4_doe/case4_socp_doe_table.csv
      168 rows × (1 + 10 HEMS loads) columns.
      Row h gives the maximum export limit (kW) for each HEMS load during
      hour h of the representative 7-day window.

  results/task3_cases/case3_pv_batt_20kWh_opt/profiles/{load_id}_profile.csv
      Full-year 5-minute profiles from Case 3 (20 kWh battery) used as the
      starting point.  Only HEMS-load profiles are modified; non-HEMS profiles
      are copied unchanged.

Outputs
───────
  results/task3_cases/case4_doe/profiles/{load_id}_profile.csv
  results/task3_cases/case4_doe/shapes/{load_id}_shape.csv
  dss/timeseries_loads_task3_case4_doe.dss
  dss/network_task3_case4_doe.dss
  results/task3_cases/case4_doe/case_load_summary.csv

DOE mapping
───────────
The 7-day DOE pattern is repeated across the full year:
  step in year (0-indexed) → hour_in_week = (step ÷ 12) mod 168
  DOE limit for that (hour_in_week, load_id) is taken from the table.
"""

using CSV
using DataFrames

const TARGET_NPTS = 105120
const DOE_WEEK_H  = 168          # hours in the 7-day DOE period
const DOE_WEEK_5  = DOE_WEEK_H * 12  # 5-min steps in the DOE period

const HEMS_LOADS = ["L10","L13","L16","L17","L22","L23","L24","L25","L26","L27"]

function main()
    task_root = normpath(joinpath(@__DIR__, ".."))

    # ── Load SOCP DOE table ──────────────────────────────────────────────────
    doe_file = joinpath(task_root, "results", "task3_case4_doe",
                        "case4_socp_doe_table.csv")
    if !isfile(doe_file)
        error("""
        DOE table not found:
          $doe_file
        Run solve_task3_case4_socp_doe.jl first.
        """)
    end
    doe_df = CSV.read(doe_file, DataFrame)

    # Build a per-load lookup: doe_kw[load_id][hour_in_week] (1-indexed)
    doe_kw = Dict{String, Vector{Float64}}()
    for lid in HEMS_LOADS
        if lid in names(doe_df)
            doe_kw[lid] = Float64.(doe_df[!, lid])
        else
            @warn "Load $lid not found in DOE table — setting DOE = 50 kW."
            doe_kw[lid] = fill(50.0, DOE_WEEK_H)
        end
    end

    # ── Source profiles: Case 3 20-kWh optimised ────────────────────────────
    base_case_dir = joinpath(task_root, "results", "task3_cases",
                             "case3_pv_batt_20kWh_opt")

    # ── Destination directories ──────────────────────────────────────────────
    out_case_dir = joinpath(task_root, "results", "task3_cases", "case4_doe")
    profiles_dir = joinpath(out_case_dir, "profiles")
    shapes_dir   = joinpath(out_case_dir, "shapes")
    mkpath(profiles_dir)
    mkpath(shapes_dir)

    alloc = CSV.read(joinpath(task_root, "data", "load_allocation.csv"), DataFrame)

    summary = DataFrame(
        load_id           = String[],
        bus               = String[],
        phase             = Int[],
        base_kw           = Float64[],
        annual_import_kwh = Float64[],
        annual_export_kwh = Float64[],
        curtailed_export_kwh = Float64[]
    )

    for row in eachrow(alloc)
        lid   = String(row.load_id)
        bus   = String(row.bus)
        phase = Int(row.phase)

        # Read source profile
        src_file = joinpath(base_case_dir, "profiles", "$(lid)_profile.csv")
        prof     = CSV.read(src_file, DataFrame)
        net      = Float64.(prof.grid_net_kw)

        curtailed = zeros(length(net))

        if lid in HEMS_LOADS
            limits = doe_kw[lid]          # 168-element vector

            for k in eachindex(net)
                # Map 5-min step to hour-in-week (cycling the 7-day pattern)
                step0           = k - 1           # 0-indexed
                hour_in_week    = (step0 ÷ 12) % DOE_WEEK_H  # 0-indexed
                doe_limit       = limits[hour_in_week + 1]    # 1-indexed table

                export_kw       = max(-net[k], 0.0)

                if export_kw > doe_limit
                    curtailed[k] = export_kw - doe_limit
                    net[k]       = -doe_limit
                end
            end
        end

        # Update profile with clipped net load
        prof_out = copy(prof)
        prof_out.grid_net_kw = net
        if !hasproperty(prof_out, :doe_curtailed_export_kw)
            prof_out[!, :doe_curtailed_export_kw] = curtailed
        else
            prof_out.doe_curtailed_export_kw = curtailed
        end

        CSV.write(joinpath(profiles_dir, "$(lid)_profile.csv"), prof_out)

        # Normalised LoadShape multiplier
        base_kw = maximum(abs.(net))
        base_kw < 1e-6 && (base_kw = 1.0)
        CSV.write(joinpath(shapes_dir, "$(lid)_shape.csv"),
                  DataFrame(mult = net ./ base_kw))

        annual_import_kwh    = sum(max.( net, 0.0)) / 12.0
        annual_export_kwh    = sum(max.(-net, 0.0)) / 12.0
        curtailed_export_kwh = sum(curtailed)        / 12.0

        push!(summary, (lid, bus, phase, base_kw,
                         annual_import_kwh, annual_export_kwh, curtailed_export_kwh))
    end

    CSV.write(joinpath(out_case_dir, "case_load_summary.csv"), summary)

    # ── Write timeseries_loads_task3_case4_doe.dss ───────────────────────────
    loads_dss = joinpath(task_root, "dss", "timeseries_loads_task3_case4_doe.dss")
    open(loads_dss, "w") do io
        println(io, "! Auto-generated Task 3 Case 4 DOE load definitions")
        println(io, "! Signed LoadShape multipliers: positive = import/load, negative = export/injection.")
        println(io, "! DOE limits from solve_task3_case4_socp_doe.jl (SOCP-OPF, 7-day table, cycled annually).")
        println(io, "")
        for row in eachrow(summary)
            lid       = String(row.load_id)
            rel_shape = "..\\results\\task3_cases\\case4_doe\\shapes\\$(lid)_shape.csv"
            println(io, "New LoadShape.LS_$(lid) npts=$(TARGET_NPTS) interval=0.083333 mult=(file=$(rel_shape), col=1, header=yes)")
        end
        println(io, "")
        for row in eachrow(summary)
            lid   = String(row.load_id)
            bus   = String(row.bus)
            ph    = Int(row.phase)
            bkw   = Float64(row.base_kw)
            println(io, "New Load.$(lid) bus1=$(bus).$(ph).4 phases=1 conn=wye kV=0.23 kW=$(round(bkw, digits=4)) pf=0.98 yearly=LS_$(lid)")
        end
    end

    # ── Write network_task3_case4_doe.dss ────────────────────────────────────
    step1_file = joinpath(task_root, "dss", "network_step1.dss")
    case_dss   = joinpath(task_root, "dss", "network_task3_case4_doe.dss")
    lines      = readlines(step1_file)
    filtered   = String[]
    for line in lines
        s = strip(line)
        startswith(s, "New Load.") && continue
        lowercase(s) == "solve"    && continue
        push!(filtered, line)
    end
    open(case_dss, "w") do io
        println(io, "! Auto-generated Task 3 Case 4 DOE network file")
        for line in filtered
            println(io, line)
        end
        println(io, "")
        println(io, "Redirect timeseries_loads_task3_case4_doe.dss")
    end

    # ── Summary print ─────────────────────────────────────────────────────────
    println("Built Task 3 Case 4 DOE:")
    println("  ", loads_dss)
    println("  ", case_dss)
    println("  profiles/shapes: ", out_case_dir)

    println("\nAnnual energy summary for HEMS loads:")
    println(rpad("Load", 8),
            rpad("Import kWh", 14),
            rpad("Export kWh", 14),
            rpad("Curtailed kWh", 16))
    for row in eachrow(filter(r -> String(r.load_id) in HEMS_LOADS, summary))
        println(rpad(row.load_id, 8),
                rpad(round(row.annual_import_kwh,    digits=1), 14),
                rpad(round(row.annual_export_kwh,    digits=1), 14),
                rpad(round(row.curtailed_export_kwh, digits=1), 16))
    end
end

main()
