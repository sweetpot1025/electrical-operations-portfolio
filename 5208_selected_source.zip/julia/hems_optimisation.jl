using JuMP
using HiGHS
using CSV
using DataFrames
using Dates
using Statistics

const TARGET_NPTS_5MIN = 105120

function parse_local_datetime(s::AbstractString)
    s2 = strip(s)
    if length(s2) >= 6 && (s2[end-5] == '+' || s2[end-5] == '-')
        s2 = s2[1:end-6]
    end
    return DateTime(s2, dateformat"yyyy-mm-dd HH:MM:SS")
end

function import_price(hour::Int; sso::Bool=false)
    if sso && 11 <= hour <= 13
        return 0.0
    elseif 7 <= hour <= 13
        return 0.25
    elseif 14 <= hour <= 19
        return 0.35
    elseif 20 <= hour <= 21
        return 0.25
    else
        return 0.15
    end
end

function make_price_vector(ts; sso::Bool=false)
    return [import_price(Dates.hour(t); sso=sso) for t in ts]
end

function load_raw_solaranalytics(csv_file::AbstractString; scale::Float64=1.0)
    df = CSV.read(csv_file, DataFrame)

    df.localtime = parse_local_datetime.(String.(df.localtime))
    df.ts_syd = df.localtime

    pv_w = 12.0 .* Float64.(df.pv_generation)
    load_w = 12.0 .* Float64.(df.total_load)

    df.pv_kw = scale .* max.(pv_w, 0.0) ./ 1000.0
    df.load_kw = scale .* max.(load_w, 0.0) ./ 1000.0

    sort!(df, :ts_syd)
    return df[:, [:ts_syd, :load_kw, :pv_kw]]
end

function force_year_length(df::DataFrame)
    n = nrow(df)

    if n >= TARGET_NPTS_5MIN
        return df[1:TARGET_NPTS_5MIN, :]
    else
        missing_n = TARGET_NPTS_5MIN - n

        last_ts = df.ts_syd[end]
        last_load = df.load_kw[end]
        last_pv = df.pv_kw[end]

        pad = DataFrame(
            ts_syd = [last_ts + Minute(5*i) for i in 1:missing_n],
            load_kw = fill(last_load, missing_n),
            pv_kw = fill(last_pv, missing_n)
        )

        return vcat(df, pad)
    end
end

function read_allocated_profile(task_root::AbstractString, load_id::AbstractString)
    alloc_file = joinpath(task_root, "data", "load_allocation.csv")
    alloc = CSV.read(alloc_file, DataFrame)

    rowidx = findfirst(==(load_id), String.(alloc.load_id))
    rowidx === nothing && error("Cannot find load_id=$load_id in load_allocation.csv")

    row = alloc[rowidx, :]
    raw_file = joinpath(task_root, "data", String(row.profile_file))
    scale = Float64(row.scale)

    df = load_raw_solaranalytics(raw_file; scale=scale)
    return force_year_length(df)
end

function aggregate_hourly(df5::DataFrame)
    df = copy(df5)

    df.hour_ts = DateTime.(
        Dates.year.(df.ts_syd),
        Dates.month.(df.ts_syd),
        Dates.day.(df.ts_syd),
        Dates.hour.(df.ts_syd)
    )

    gdf = groupby(df, :hour_ts)

    out = combine(gdf,
        :load_kw => mean => :load_kw,
        :pv_kw => mean => :pv_kw
    )

    rename!(out, :hour_ts => :ts_syd)
    return out
end

function solve_hems_optimisation(
    demand_kw::Vector{Float64},
    pv_available_kw::Vector{Float64};
    ts=nothing,
    dt_hours::Float64=1.0,
    battery_capacity_kwh::Float64=10.0,
    battery_power_kw::Float64=5.0,
    eta::Float64=0.90,
    initial_soc_kwh::Float64=0.5*battery_capacity_kwh,
    min_soc_kwh::Float64=0.0,
    feed_in_tariff::Float64=0.08,
    sso::Bool=false,
    terminal_soc_equal_initial::Bool=true,
    cycling_penalty::Float64=0.0001
)
    n = length(demand_kw)
    length(pv_available_kw) == n || error("demand_kw and pv_available_kw must have same length")

    T = 1:n

    if ts === nothing
        import_prices = [import_price(mod(t-1, 24); sso=sso) for t in T]
        ts_out = string.(T)
    else
        import_prices = make_price_vector(ts; sso=sso)
        ts_out = string.(ts)
    end

    model = Model(HiGHS.Optimizer)
    set_silent(model)

    @variable(model, pg_import[T] >= 0)
    @variable(model, pg_export[T] >= 0)
    @variable(model, ppv[T] >= 0)
    @variable(model, pcurt[T] >= 0)

    @variable(model, pb_charge[T] >= 0)
    @variable(model, pb_discharge[T] >= 0)

    @variable(model, min_soc_kwh <= soc[1:n+1] <= battery_capacity_kwh)

    @constraint(model, soc[1] == clamp(initial_soc_kwh, min_soc_kwh, battery_capacity_kwh))

    for t in T
        @constraint(model, ppv[t] + pcurt[t] == pv_available_kw[t])
        @constraint(model, ppv[t] <= pv_available_kw[t])

        @constraint(model,
            pg_import[t] + ppv[t] + pb_discharge[t]
            ==
            demand_kw[t] + pb_charge[t] + pg_export[t]
        )

        @constraint(model, pb_charge[t] <= battery_power_kw)
        @constraint(model, pb_discharge[t] <= battery_power_kw)

        @constraint(model,
            soc[t+1] == soc[t] + eta * pb_charge[t] * dt_hours - (pb_discharge[t] / eta) * dt_hours
        )

        # Prevent unrealistic unlimited grid import during zero-price periods.
        @constraint(model, pg_import[t] <= demand_kw[t] + battery_power_kw)

        # Export is limited to PV-related surplus only.
        # The battery is used for local demand shifting, not for grid-export arbitrage.
        @constraint(model, pg_export[t] <= ppv[t])
    end

    if terminal_soc_equal_initial
        @constraint(model, soc[n+1] == soc[1])
    end

    @objective(model, Min,
        sum(
            (
                import_prices[t] * pg_import[t]
                - feed_in_tariff * pg_export[t]
                + cycling_penalty * (pb_charge[t] + pb_discharge[t])
            ) * dt_hours
            for t in T
        )
    )

    optimize!(model)

    term_status = termination_status(model)
    if term_status != MOI.OPTIMAL
        error("HEMS optimisation did not solve to optimality. Status = $term_status")
    end

    pg_import_v = [value(pg_import[t]) for t in T]
    pg_export_v = [value(pg_export[t]) for t in T]
    ppv_v = [value(ppv[t]) for t in T]
    pcurt_v = [value(pcurt[t]) for t in T]
    pb_charge_v = [value(pb_charge[t]) for t in T]
    pb_discharge_v = [value(pb_discharge[t]) for t in T]
    soc_v = [value(soc[t]) for t in 1:n+1]

    grid_net_kw = pg_import_v .- pg_export_v
    battery_net_kw = pb_discharge_v .- pb_charge_v

    return DataFrame(
        step = collect(T),
        ts_syd = ts_out,
        demand_kw = demand_kw,
        pv_available_kw = pv_available_kw,
        pv_used_kw = ppv_v,
        pv_curtailed_kw = pcurt_v,
        battery_charge_kw = pb_charge_v,
        battery_discharge_kw = pb_discharge_v,
        battery_net_kw = battery_net_kw,
        grid_import_kw = pg_import_v,
        grid_export_kw = pg_export_v,
        grid_net_kw = grid_net_kw,
        soc_start_kwh = soc_v[1:n],
        soc_end_kwh = soc_v[2:n+1],
        import_price = import_prices,
        export_tariff = fill(feed_in_tariff, n),
        objective_value = fill(objective_value(model), n)
    )
end