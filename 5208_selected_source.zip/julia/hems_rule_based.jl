using CSV
using DataFrames
using Dates
#using TimeZones
using Statistics

#const SYD = tz"Australia/Sydney"
#const TS_FMT = dateformat"yyyy-mm-dd HH:MM:SSzzzz"
const TARGET_NPTS_5MIN = 105120

"Parse timestamps like 2018-12-31 16:05:00+00:00."
function parse_zdt(s::AbstractString)
    s2 = strip(s)

    # The SolarAnalytics localtime string usually ends with a timezone offset,
    # e.g. "2019-04-07 02:00:00+10:00".
    # For this assignment we only need chronological ordering and hour-of-day,
    # so we parse the local clock time as a plain DateTime to avoid daylight-saving ambiguity.
    if length(s2) >= 6 && (s2[end-5] == '+' || s2[end-5] == '-')
        s2 = s2[1:end-6]
    end

    return DateTime(s2, dateformat"yyyy-mm-dd HH:MM:SS")
end

"Import price in AUD/kWh for an hour of day. SSO sets 11:00-13:59 to zero."
function import_price(hour::Int; sso::Bool=false)
    if sso && 11 <= hour <= 13
        return 0.0
    elseif 7 <= hour <= 13
        return 0.25
    elseif 14 <= hour <= 19
        return 0.35
    elseif 20 <= hour <= 21
        return 0.25
    else
        return 0.15
    end
end

"Return a 24-value or n-value price vector from timestamps."
function make_price_vector(ts; sso::Bool=false)
    return [import_price(Dates.hour(t); sso=sso) for t in ts]
end

"Load one raw SolarAnalytics CSV, apply the same cleaning convention as Task 1, and return W-level power columns."
function load_raw_solaranalytics(csv_file::AbstractString; scale::Float64=1.0)
    df = CSV.read(csv_file, DataFrame)

    df.utc_timestamp = parse_zdt.(String.(df.utc_timestamp))
    df.localtime = parse_zdt.(String.(df.localtime))

    # Use localtime directly as the simulation timestamp.
    # This avoids DST ambiguity while preserving hour-of-day information for tariffs.
    df.ts_syd = df.localtime

    # Task 1 convention: 5-min energy-like fields are converted to equivalent W by multiplying by 12.
    pv_w = 12.0 .* Float64.(df.pv_generation)
    load_w = 12.0 .* Float64.(df.total_load)

    df.pv_kw = scale .* max.(pv_w, 0.0) ./ 1000.0
    df.load_kw = scale .* max.(load_w, 0.0) ./ 1000.0
    sort!(df, :ts_syd)
    return df[:, [:ts_syd, :load_kw, :pv_kw]]
end

"Force a vector/dataframe to the Task 1 full-year length."
function force_year_length!(df::DataFrame)
    n = nrow(df)

    if n >= TARGET_NPTS_5MIN
        return df[1:TARGET_NPTS_5MIN, :]
    else
        missing_n = TARGET_NPTS_5MIN - n

        last_ts = df.ts_syd[end]
        last_load = df.load_kw[end]
        last_pv = df.pv_kw[end]

        pad = DataFrame(
            ts_syd = [last_ts + Minute(5*i) for i in 1:missing_n],
            load_kw = fill(last_load, missing_n),
            pv_kw = fill(last_pv, missing_n)
        )

        return vcat(df, pad)
    end
end

"Aggregate 5-min data to hourly mean power."
function aggregate_hourly(df5::DataFrame)
    df = copy(df5)

    # Round down each 5-min timestamp to the start of the hour.
    # Use plain DateTime instead of ZonedDateTime to avoid daylight-saving ambiguity.
    df.hour_ts = DateTime.(
        Dates.year.(df.ts_syd),
        Dates.month.(df.ts_syd),
        Dates.day.(df.ts_syd),
        Dates.hour.(df.ts_syd)
    )

    gdf = groupby(df, :hour_ts)
    out = combine(gdf,
        :load_kw => mean => :load_kw,
        :pv_kw => mean => :pv_kw
    )
    rename!(out, :hour_ts => :ts_syd)
    return out
end

"Read one allocated Task 1 load and return full-year 5-min demand/PV in kW."
function read_allocated_profile(task_root::AbstractString, load_id::AbstractString)
    alloc_file = joinpath(task_root, "data", "load_allocation.csv")
    alloc = CSV.read(alloc_file, DataFrame)
    rowidx = findfirst(==(load_id), String.(alloc.load_id))
    rowidx === nothing && error("Cannot find load_id=$load_id in load_allocation.csv")
    row = alloc[rowidx, :]
    raw_file = joinpath(task_root, "data", String(row.profile_file))
    scale = Float64(row.scale)
    df = load_raw_solaranalytics(raw_file; scale=scale)
    return force_year_length!(df)
end

"Rule-based HEMS simulation. Inputs are kW arrays with fixed timestep dt_hours."
function simulate_hems_rule_based(pd_kw::Vector{Float64}, pv_avail_kw::Vector{Float64};
        ts=nothing,
        dt_hours::Float64=1.0,
        battery_capacity_kwh::Float64=10.0,
        battery_power_kw::Float64=5.0,
        eta::Float64=0.90,
        initial_soc_kwh::Float64=5.0,
        min_soc_kwh::Float64=0.0,
        export_limit_kw::Float64=Inf,
        sso::Bool=false,
        allow_grid_charging_sso::Bool=true,
        feed_in_tariff::Float64=0.08)

    n = length(pd_kw)
    length(pv_avail_kw) == n || error("pd_kw and pv_avail_kw must have the same length")

    if ts === nothing
        import_prices = [import_price(mod(t-1, 24); sso=sso) for t in 1:n]
        hours = [mod(t-1, 24) for t in 1:n]
    else
        import_prices = make_price_vector(ts; sso=sso)
        hours = [Dates.hour(t) for t in ts]
    end

    soc = zeros(n + 1)
    soc[1] = clamp(initial_soc_kwh, min_soc_kwh, battery_capacity_kwh)

    pv_to_load = zeros(n)
    pv_curtailed = zeros(n)
    pb_charge = zeros(n)
    pb_discharge = zeros(n)
    pg_import = zeros(n)
    pg_export = zeros(n)

    for t in 1:n
        pd = max(pd_kw[t], 0.0)
        pv = max(pv_avail_kw[t], 0.0)
        e = soc[t]

        used_pv = min(pv, pd)
        pv_to_load[t] = used_pv
        surplus = pv - used_pv
        deficit = pd - used_pv

        if surplus > 1e-9
            # PV surplus: charge battery first, then export, then curtail.
            max_charge_by_soc = max((battery_capacity_kwh - e) / (eta * dt_hours), 0.0)
            charge = min(surplus, battery_power_kw, max_charge_by_soc)
            pb_charge[t] = charge
            e += eta * charge * dt_hours
            surplus -= charge

            export_power = min(surplus, export_limit_kw)
            pg_export[t] = export_power
            pv_curtailed[t] = max(surplus - export_power, 0.0)

        else
            # PV deficit: discharge only during high-price peak hours.
            is_peak = 14 <= hours[t] <= 19
            if deficit > 1e-9 && is_peak
                max_discharge_by_soc = max((e - min_soc_kwh) * eta / dt_hours, 0.0)
                discharge = min(deficit, battery_power_kw, max_discharge_by_soc)
                pb_discharge[t] = discharge
                e -= discharge * dt_hours / eta
                deficit -= discharge
            end

            pg_import[t] = max(deficit, 0.0)
        end

        # Optional SSO extension: charge the battery from the grid during zero-price hours.
        # This follows the lecture example: free electricity from 11:00 to 14:00 can be used
        # for grid charging, subject to battery power and SOC limits. It is placed outside the
        # surplus/deficit branch so that SSO charging can still occur when PV surplus is small
        # and the battery has remaining inverter capacity.
        if allow_grid_charging_sso && sso && (11 <= hours[t] <= 13)
            is_not_exporting = pg_export[t] < 1e-9
            is_not_discharging = pb_discharge[t] < 1e-9

            if is_not_exporting && is_not_discharging
                remaining_power_capacity = max(battery_power_kw - pb_charge[t], 0.0)
                max_charge_by_soc = max((battery_capacity_kwh - e) / (eta * dt_hours), 0.0)

                grid_charge = min(remaining_power_capacity, max_charge_by_soc)

                pb_charge[t] += grid_charge
                pg_import[t] += grid_charge
                e += eta * grid_charge * dt_hours
            end
        end

        soc[t+1] = clamp(e, min_soc_kwh, battery_capacity_kwh)
    end

    cost = sum(pg_import .* import_prices .* dt_hours) - sum(pg_export .* feed_in_tariff .* dt_hours)
    grid_net_kw = pg_import .- pg_export
    batt_net_kw = pb_discharge .- pb_charge

    return DataFrame(
        step = 1:n,
        ts_syd = ts === nothing ? string.(1:n) : string.(ts),
        demand_kw = pd_kw,
        pv_available_kw = pv_avail_kw,
        pv_to_load_kw = pv_to_load,
        battery_charge_kw = pb_charge,
        battery_discharge_kw = pb_discharge,
        battery_net_kw = batt_net_kw,
        grid_import_kw = pg_import,
        grid_export_kw = pg_export,
        grid_net_kw = grid_net_kw,
        pv_curtailed_kw = pv_curtailed,
        soc_start_kwh = soc[1:n],
        soc_end_kwh = soc[2:end],
        import_price = import_prices,
        export_tariff = fill(feed_in_tariff, n),
        total_cost = fill(cost, n)
    )
end
