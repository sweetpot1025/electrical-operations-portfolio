using OpenDSSDirect
using CSV
using DataFrames
using Plots
using Statistics

const dss = OpenDSSDirect
const a   = cis(2π/3)

function phase_phasors_pu()
    nodes = dss.Bus.Nodes()
    vma   = dss.Bus.puVmagAngle()
    ph    = Dict{Int,ComplexF64}()
    for i in 1:length(nodes)
        node    = Int(nodes[i])
        mag     = Float64(vma[2i - 1])
        ang_deg = Float64(vma[2i])
        if node in (1, 2, 3) && mag > 0.0
            ph[node] = mag * cis(deg2rad(ang_deg))
        end
    end
    return ph
end

function compute_pvur_vuf(Va::ComplexF64, Vb::ComplexF64, Vc::ComplexF64)
    mags  = [abs(Va), abs(Vb), abs(Vc)]
    Vavg  = mean(mags)
    pvur  = maximum(abs.(mags .- Vavg)) / Vavg * 100
    V1    = (Va + a * Vb + a^2 * Vc) / 3
    V2    = (Va + a^2 * Vb + a * Vc) / 3
    return pvur, abs(V2) / abs(V1) * 100
end

function run_case(case_name::String)
    task_root        = normpath(joinpath(@__DIR__, ".."))
    dss_file         = joinpath(task_root, "dss", "network_task3_$(case_name).dss")
    ref_profile_file = joinpath(task_root, "results", "profiles", "L1_profile.csv")
    out_dir          = joinpath(task_root, "results", "task3_cases", case_name)
    mkpath(out_dir)

    println("Compiling: ", dss_file)
    dss.Text.Command("compile $dss_file")
    bus_names = dss.Circuit.AllBusNames()
    ref_df    = CSV.read(ref_profile_file, DataFrame)
    nsteps    = nrow(ref_df)

    # ── Set simulation mode ONCE before the loop (efficiency fix) ─────────────
    dss.Text.Command("set mode=yearly")
    dss.Text.Command("set stepsize=5m")
    dss.Text.Command("set number=1")

    results = DataFrame(
        step         = Int[],
        ts_syd       = String[],
        hour_from_year = Float64[],
        min_v        = Float64[],
        max_v        = Float64[],
        min_bus      = String[],
        max_bus      = String[],
        total_p_kw   = Float64[],
        total_q_kvar = Float64[],
        max_pvur_pct = Float64[],
        max_pvur_bus = String[],
        max_vuf_pct  = Float64[],
        max_vuf_bus  = String[],
        converged    = Bool[]
    )

    for k in 1:nsteps
        total_seconds = (k - 1) * 300
        hour_val      = total_seconds ÷ 3600
        sec_val       = total_seconds % 3600

        # Only set time position per step (mode/stepsize/number are fixed above)
        dss.Text.Command("set hour=$(hour_val)")
        dss.Text.Command("set sec=$(sec_val)")
        dss.Text.Command("solve")
        conv = dss.Solution.Converged()

        min_v = Inf; max_v = -Inf; min_bus = ""; max_bus = ""
        max_pvur = -1.0; max_pvur_bus = ""; max_vuf = -1.0; max_vuf_bus = ""

        for bus in bus_names
            dss.Circuit.SetActiveBus(bus)
            mags  = dss.Bus.puVmagAngle()[1:2:end]
            nodes = dss.Bus.Nodes()
            for (node, m) in zip(nodes, mags)
                if node in (1, 2, 3)
                    v = Float64(m)
                    if v < min_v; min_v = v; min_bus = bus; end
                    if v > max_v; max_v = v; max_bus = bus; end
                end
            end
            ph = phase_phasors_pu()
            if all(haskey(ph, p) for p in (1, 2, 3))
                pvur, vuf = compute_pvur_vuf(ph[1], ph[2], ph[3])
                if pvur > max_pvur; max_pvur = pvur; max_pvur_bus = bus; end
                if vuf > max_vuf;   max_vuf  = vuf;  max_vuf_bus  = bus; end
            end
        end

        total_s = dss.Circuit.TotalPower()
        if total_s isa Complex
            total_p_kw   = -Float64(real(total_s))
            total_q_kvar = -Float64(imag(total_s))
        else
            total_p_kw   = -Float64(total_s[1])
            total_q_kvar = -Float64(total_s[2])
        end

        push!(results, (k, string(ref_df.ts_syd[k]), (k-1)*5/60,
                         min_v, max_v, min_bus, max_bus,
                         total_p_kw, total_q_kvar,
                         max_pvur, max_pvur_bus, max_vuf, max_vuf_bus, conv))

        if k % 5000 == 0 || k == nsteps
            println("Completed $case_name step $k / $nsteps")
        end
    end

    CSV.write(joinpath(out_dir, "year_timeseries_results.csv"), results)

    # ── Summary statistics ────────────────────────────────────────────────────
    idx_min_v = argmin(results.min_v)
    idx_max_v = argmax(results.max_v)
    idx_max_p = argmax(results.total_p_kw)
    idx_min_p = argmin(results.total_p_kw)
    idx_pvur  = argmax(results.max_pvur_pct)
    idx_vuf   = argmax(results.max_vuf_pct)

    dt_h = 5.0 / 60.0
    annual_import_kwh       = sum(max.( results.total_p_kw, 0.0)) * dt_h
    annual_export_kwh       = sum(max.(-results.total_p_kw, 0.0)) * dt_h
    reverse_power_flow_steps = count(<(0.0), results.total_p_kw)
    voltage_violation_steps  = count((results.min_v .< 0.9) .| (results.max_v .> 1.1))

    summary = DataFrame(metric = String[], value = String[])
    for (m, v) in [
        ("case_name",                 case_name),
        ("nsteps",                    string(nsteps)),
        ("all_steps_converged",       string(all(results.converged))),
        ("voltage_pass_0.9_to_1.1",   string(minimum(results.min_v) >= 0.9 &&
                                              maximum(results.max_v) <= 1.1)),
        ("voltage_violation_steps",   string(voltage_violation_steps)),
        ("minimum_voltage_pu",        string(results.min_v[idx_min_v])),
        ("minimum_voltage_time",      results.ts_syd[idx_min_v]),
        ("minimum_voltage_bus",       results.min_bus[idx_min_v]),
        ("maximum_voltage_pu",        string(results.max_v[idx_max_v])),
        ("maximum_voltage_time",      results.ts_syd[idx_max_v]),
        ("maximum_voltage_bus",       results.max_bus[idx_max_v]),
        ("minimum_total_P_kw",        string(results.total_p_kw[idx_min_p])),
        ("minimum_total_P_time",      results.ts_syd[idx_min_p]),
        ("maximum_total_P_kw",        string(results.total_p_kw[idx_max_p])),
        ("maximum_total_P_time",      results.ts_syd[idx_max_p]),
        ("annual_feeder_import_kWh",  string(annual_import_kwh)),
        ("annual_feeder_export_kWh",  string(annual_export_kwh)),
        ("reverse_power_flow_steps",  string(reverse_power_flow_steps)),
        ("reverse_power_flow_hours",  string(reverse_power_flow_steps * dt_h)),
        ("maximum_PVUR_pct",          string(results.max_pvur_pct[idx_pvur])),
        ("maximum_PVUR_time",         results.ts_syd[idx_pvur]),
        ("maximum_PVUR_bus",          results.max_pvur_bus[idx_pvur]),
        ("maximum_VUF_pct",           string(results.max_vuf_pct[idx_vuf])),
        ("maximum_VUF_time",          results.ts_syd[idx_vuf]),
        ("maximum_VUF_bus",           results.max_vuf_bus[idx_vuf])]
        push!(summary, (m, v))
    end
    CSV.write(joinpath(out_dir, "year_summary.csv"), summary)

    # ── Plots ─────────────────────────────────────────────────────────────────
    h = results.hour_from_year

    p1 = plot(h, results.min_v, label="Min voltage",
              xlabel="Hour from start of year", ylabel="Voltage [p.u.]",
              title="$(case_name) voltage range")
    plot!(p1, h, results.max_v, label="Max voltage")
    hline!(p1, [0.9, 1.1], label="Limits", linestyle=:dash, color=:red)
    savefig(p1, joinpath(out_dir, "year_voltage_profile.png"))

    p2 = plot(h, results.total_p_kw, label="Total active power",
              xlabel="Hour from start of year", ylabel="Power [kW]",
              title="$(case_name) feeder active power")
    savefig(p2, joinpath(out_dir, "year_total_power.png"))

    p3 = plot(h, results.max_pvur_pct, label="Max PVUR",
              xlabel="Hour from start of year", ylabel="PVUR [%]",
              title="$(case_name) maximum PVUR", lw=1.5)
    savefig(p3, joinpath(out_dir, "year_max_pvur.png"))

    p4 = plot(h, results.max_vuf_pct, label="Max VUF",
              xlabel="Hour from start of year", ylabel="VUF [%]",
              title="$(case_name) maximum VUF", lw=1.5)
    savefig(p4, joinpath(out_dir, "year_max_vuf.png"))

    println("Saved Task 3 results for $(case_name) in ", out_dir)
end

function main()
    if length(ARGS) == 0
        println("Usage: julia run_task3_case_year.jl <case_name>")
        println("  e.g. julia run_task3_case_year.jl case3_pv_batt_10kWh_opt")
        return
    end
    run_case(ARGS[1])
end

main()
