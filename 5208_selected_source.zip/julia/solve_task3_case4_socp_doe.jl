"""
solve_task3_case4_socp_doe.jl
═══════════════════════════════════════════════════════════════════════════════
Computes per-node Dynamic Operating Envelopes (DOEs) for the 10 HEMS loads
using the Branch Flow Model (BFM) SOCP relaxation, as required by Task 3 Case 4.

Method
──────
• Three single-phase SOCPs are solved independently (one per phase A/B/C).
• For each of 168 hourly timesteps (7-day representative period), the OPF
  maximises the total export from HEMS nodes subject to:
    – voltage magnitude: 0.9 ≤ |V| ≤ 1.1 p.u.
    – branch current:    I ≤ 479 A (NeptuneWire NormAmps)
• The resulting 168 × 10 DOE table is saved to
  results/task3_case4_doe/case4_socp_doe_table.csv
• The same table is replicated for the full year by cycling the 7-day pattern
  (see apply_task3_case4_doe.jl).

Solver dependency
─────────────────
Uses Clarabel.jl (free, conic solver).  Install once with:
    using Pkg; Pkg.add("Clarabel")

Network parameters
──────────────────
Derived analytically from network_step1.dss:
  Conductor : Neptune (DIAM=16.3 mm, RAC=0.224 Ω/km, NormAmps=479 A)
  Geometry  : (-110, -45, +45, +110) cm at height 580 cm
              → X ≈ 0.316 Ω/km (Carson's equation)
  Base      : S=500 kVA/3=166.7 kW, V=230 V (LN), Z=0.3174 Ω
"""

using JuMP
using Clarabel
using CSV
using DataFrames
using Statistics
using Dates

include("hems_optimisation.jl")   # provides read_allocated_profile, TARGET_NPTS_5MIN

# ─────────────────────────────────────────────────────────────────────────────
# Network constants
# ─────────────────────────────────────────────────────────────────────────────
const R_PER_KM  = 0.224    # Ω/km  (Neptune wire)
const X_PER_KM  = 0.316    # Ω/km  (from Carson's equation, see report)
const I_NORM_A  = 479.0    # A     (NormAmps)

# Single-phase per-unit base
const S1_BASE_W  = 500_000.0 / 3.0        # W
const V1_BASE_V  = 230.0                   # V
const I1_BASE_A  = S1_BASE_W / V1_BASE_V  # A  ≈ 724.64
const Z1_BASE_OH = V1_BASE_V / I1_BASE_A  # Ω  ≈ 0.3174

# Voltage and current limits (per-unit squared)
const V2_PU_MIN  = 0.9^2       # 0.81
const V2_PU_MAX  = 1.1^2       # 1.21
const I2_PU_MAX  = (I_NORM_A / I1_BASE_A)^2   # ≈ 0.4369

# DOE week length
const DOE_DAYS   = 7
const DOE_HOURS  = DOE_DAYS * 24    # 168

# HEMS loads (10 nodes with PV + battery)
const HEMS_LOADS = ["L10","L13","L16","L17","L22","L23","L24","L25","L26","L27"]

# Branch list: (from_bus, to_bus, length_km)
const BRANCH_LIST = [
    ("tbus","b1",  0.08),
    ("b1",  "b2",  0.08),
    ("b2",  "b3",  0.07),
    ("b3",  "b4",  0.07),
    ("b4",  "b5",  0.05),
    ("b5",  "b6",  0.04),
    ("b2",  "b2a", 0.06),
    ("b4",  "b4a", 0.06),
    ("b6",  "b6a", 0.05),
]

const NON_SLACK_BUSES = ["b1","b2","b3","b4","b5","b6","b2a","b4a","b6a"]

# Load ↔ (bus, phase) — from load_allocation.csv
const LOAD_BUS_PHASE = Dict{String,Tuple{String,Int}}(
    "L1"  => ("b1",  1), "L2"  => ("b1",  2), "L3"  => ("b1",  3),
    "L4"  => ("b2",  1), "L5"  => ("b2",  2), "L6"  => ("b2",  3),
    "L7"  => ("b3",  1), "L8"  => ("b3",  2), "L9"  => ("b3",  3),
    "L10" => ("b4",  1), "L11" => ("b4",  2), "L12" => ("b4",  3),
    "L13" => ("b5",  1), "L14" => ("b5",  2), "L15" => ("b5",  3),
    "L16" => ("b6",  2), "L17" => ("b6",  1), "L18" => ("b6",  3),
    "L19" => ("b2a", 1), "L20" => ("b2a", 2), "L21" => ("b2a", 3),
    "L22" => ("b4a", 2), "L23" => ("b4a", 1), "L24" => ("b4a", 3),
    "L25" => ("b6a", 2), "L26" => ("b6a", 1), "L27" => ("b6a", 3),
    "L28" => ("b4",  1), "L29" => ("b4",  2), "L30" => ("b4",  3),
    "L31" => ("b5",  2), "L32" => ("b5",  1), "L33" => ("b5",  3),
    "L34" => ("b4a", 1), "L35" => ("b4a", 2), "L36" => ("b4a", 3),
)

# ─────────────────────────────────────────────────────────────────────────────
# Pre-compute branch impedances and network topology
# ─────────────────────────────────────────────────────────────────────────────
struct BranchParam
    r_pu :: Float64
    x_pu :: Float64
end

function build_network()
    branch_keys   = Tuple{String,String}[]
    branch_params = Dict{Tuple{String,String}, BranchParam}()
    parent_of     = Dict{String,String}()
    children_of   = Dict{String,Vector{String}}(b => String[] for b in [NON_SLACK_BUSES; ["tbus"]])

    for (from, to, len) in BRANCH_LIST
        bk = (from, to)
        push!(branch_keys, bk)
        branch_params[bk] = BranchParam(
            len * R_PER_KM / Z1_BASE_OH,
            len * X_PER_KM / Z1_BASE_OH
        )
        parent_of[to] = from
        push!(children_of[from], to)
    end
    return branch_keys, branch_params, parent_of, children_of
end

const BRANCH_KEYS, BRANCH_PARAMS, PARENT_OF, CHILDREN_OF = build_network()

# ─────────────────────────────────────────────────────────────────────────────
# Single-phase SOCP for one timestep
# Returns Dict{load_id => max_export_kW} for HEMS loads on the given phase.
# ─────────────────────────────────────────────────────────────────────────────
function solve_socp_phase(
        phase::Int,
        bg_demand_kw::Dict{Tuple{String,Int},Float64},  # (bus,ph) => total background demand kW
        bg_pv_kw::Dict{Tuple{String,Int},Float64},      # (bus,ph) => total background PV kW
        hems_demand_kw::Dict{String,Float64},            # load_id => demand kW
        hems_pv_kw::Dict{String,Float64}                 # load_id => PV kW
        ) :: Dict{String,Float64}

    hems_phase = [l for l in HEMS_LOADS if LOAD_BUS_PHASE[l][2] == phase]

    S1_BASE_kW = S1_BASE_W / 1000.0          # 166.667 kW
    tan_phi    = sqrt(1 - 0.98^2) / 0.98     # ≈ 0.2041  (for pf=0.98 loads)

    model = Model(Clarabel.Optimizer)
    set_optimizer_attribute(model, "verbose",  false)
    

    # ── Variables ─────────────────────────────────────────────────────────────
    @variable(model, V2_PU_MIN <= v[NON_SLACK_BUSES] <= V2_PU_MAX)
    @variable(model, 0.0 <= l[BRANCH_KEYS] <= I2_PU_MAX)
    @variable(model, P[BRANCH_KEYS])
    @variable(model, Q[BRANCH_KEYS])
    @variable(model, e_pu[hems_phase] >= 0)   # HEMS export [p.u.]

    # ── SOCP (BFM) relaxation ─────────────────────────────────────────────────
    # l_{ij} × v_i ≥ P_{ij}² + Q_{ij}²
    # Written as rotated SOC: [l, v_i, P, Q] ∈ RotatedSecondOrderCone()
    for bk in BRANCH_KEYS
        from_bus, _ = bk
        v_from = from_bus == "tbus" ? 1.0 : v[from_bus]
        @constraint(model, [l[bk], v_from, P[bk], Q[bk]] in RotatedSecondOrderCone())
    end

    # ── Distflow voltage recursion ─────────────────────────────────────────────
    # v_j = v_i − 2(r·P + x·Q) + (r²+x²)·l
    for bk in BRANCH_KEYS
        from_bus, to_bus = bk
        zp     = BRANCH_PARAMS[bk]
        v_from = from_bus == "tbus" ? 1.0 : v[from_bus]
        @constraint(model,
            v[to_bus] == v_from
                - 2.0*(zp.r_pu * P[bk] + zp.x_pu * Q[bk])
                + (zp.r_pu^2 + zp.x_pu^2) * l[bk]
        )
    end

    # ── Power balance at each non-slack bus ───────────────────────────────────
    for bus in NON_SLACK_BUSES
        in_bk  = (PARENT_OF[bus], bus)
        out_bks = [(bus, ch) for ch in CHILDREN_OF[bus]]
        zp_in  = BRANCH_PARAMS[in_bk]

        # Background net load at this (bus, phase): demand − PV  [p.u.]
        key      = (bus, phase)
        p_bg_pu  = (get(bg_demand_kw, key, 0.0) - get(bg_pv_kw, key, 0.0)) / S1_BASE_kW
        q_bg_pu  = get(bg_demand_kw, key, 0.0) / S1_BASE_kW * tan_phi

        # HEMS net load: demand − PV − export  [p.u.]
        p_hems_pu = 0.0
        q_hems_pu = 0.0
        for lid in hems_phase
            if LOAD_BUS_PHASE[lid][1] == bus
                d_pu  = get(hems_demand_kw, lid, 0.0) / S1_BASE_kW
                pv_pu = get(hems_pv_kw,    lid, 0.0) / S1_BASE_kW
                p_hems_pu += d_pu - pv_pu - e_pu[lid]
                q_hems_pu += d_pu * tan_phi   # exports at unity PF
            end
        end

        p_j = p_bg_pu + p_hems_pu   # total net consumption [p.u.]
        q_j = q_bg_pu + q_hems_pu

        # Active balance: P_in − r·l_in = ΣP_out + p_j
        P_out_sum = isempty(out_bks) ? 0.0 : sum(P[o] for o in out_bks)
        @constraint(model,
            P[in_bk] - zp_in.r_pu * l[in_bk] - P_out_sum == p_j
        )

        # Reactive balance: Q_in − x·l_in = ΣQ_out + q_j
        Q_out_sum = isempty(out_bks) ? 0.0 : sum(Q[o] for o in out_bks)
        @constraint(model,
            Q[in_bk] - zp_in.x_pu * l[in_bk] - Q_out_sum == q_j
        )
    end

    # ── Objective: maximise total HEMS export ─────────────────────────────────
    if isempty(hems_phase)
        return Dict{String,Float64}()
    end
    @objective(model, Max, sum(e_pu))
    optimize!(model)

    status = termination_status(model)
    if status ∈ (MOI.OPTIMAL, MOI.ALMOST_OPTIMAL, MOI.LOCALLY_SOLVED)
        return Dict(lid => max(value(e_pu[lid]) * S1_BASE_kW, 0.0) for lid in hems_phase)
    else
        @warn "SOCP phase=$phase: solver status=$status — returning zero DOE for this step."
        return Dict(lid => 0.0 for lid in hems_phase)
    end
end

# ─────────────────────────────────────────────────────────────────────────────
# Load hourly profiles for the representative 7-day window
# ─────────────────────────────────────────────────────────────────────────────
function load_hourly_week(task_root::AbstractString; start_5min_step::Int = 1)
    n_5min = DOE_DAYS * 24 * 12   # 2016 5-min steps
    n_h    = DOE_HOURS            # 168 hourly values

    alloc     = CSV.read(joinpath(task_root, "data", "load_allocation.csv"), DataFrame)
    case3_dir = joinpath(task_root, "results", "task3_cases",
                         "case3_pv_batt_10kWh_opt", "profiles")
    t1_dir    = joinpath(task_root, "results", "profiles")

    # background net-load profiles [168 hourly means per load]
    bg_h  = Dict{String,Vector{Float64}}()
    # raw demand and PV for HEMS loads [168 hourly means]
    d_h   = Dict{String,Vector{Float64}}()
    pv_h  = Dict{String,Vector{Float64}}()

    for row in eachrow(alloc)
        lid = String(row.load_id)

        # Case 3 net-load profile (background signal)
        c3_file = joinpath(case3_dir, "$(lid)_profile.csv")
        if isfile(c3_file)
            c3 = CSV.read(c3_file, DataFrame)
            net5 = Float64.(c3.grid_net_kw[start_5min_step : start_5min_step + n_5min - 1])
        else
            # Fall back to Task-1 native demand if case3 profile missing
            t1 = CSV.read(joinpath(t1_dir, "$(lid)_profile.csv"), DataFrame)
            net5 = Float64.(t1.p_kw[start_5min_step : start_5min_step + n_5min - 1])
        end
        bg_h[lid] = [mean(net5[(h-1)*12+1 : h*12]) for h in 1:n_h]

        if lid in HEMS_LOADS
            # Native demand from Task-1 profiles
            t1 = CSV.read(joinpath(t1_dir, "$(lid)_profile.csv"), DataFrame)
            d5 = Float64.(t1.p_kw[start_5min_step : start_5min_step + n_5min - 1])
            d_h[lid] = [mean(d5[(h-1)*12+1 : h*12]) for h in 1:n_h]

            # PV from raw SolarAnalytics data via load_allocation
            raw_df = read_allocated_profile(task_root, lid)
            pv5    = Float64.(raw_df.pv_kw[start_5min_step : start_5min_step + n_5min - 1])
            pv_h[lid] = [mean(pv5[(h-1)*12+1 : h*12]) for h in 1:n_h]
        end
    end

    return bg_h, d_h, pv_h
end

# ─────────────────────────────────────────────────────────────────────────────
# Aggregate per-load profiles into per-(bus, phase) background totals
# ─────────────────────────────────────────────────────────────────────────────
function aggregate_bus_phase(
        bg_h::Dict{String,Vector{Float64}},
        hour_idx::Int,
        exclude_loads::Vector{String})

    bg_demand_kw = Dict{Tuple{String,Int},Float64}()
    bg_pv_kw     = Dict{Tuple{String,Int},Float64}()

    for (lid, net_vec) in bg_h
        lid in exclude_loads && continue
        bus, ph = LOAD_BUS_PHASE[lid]
        key = (bus, ph)
        net = net_vec[hour_idx]
        if net >= 0.0
            bg_demand_kw[key] = get(bg_demand_kw, key, 0.0) + net
        else
            bg_pv_kw[key] = get(bg_pv_kw, key, 0.0) + abs(net)
        end
    end
    return bg_demand_kw, bg_pv_kw
end

# ─────────────────────────────────────────────────────────────────────────────
# Main: solve DOE for all 168 hours and write output
# ─────────────────────────────────────────────────────────────────────────────
function main()
    task_root = normpath(joinpath(@__DIR__, ".."))
    out_dir   = joinpath(task_root, "results", "task3_case4_doe")
    mkpath(out_dir)

    println("Loading hourly profiles for representative 7-day window...")
    bg_h, d_h, pv_h = load_hourly_week(task_root; start_5min_step = 1)

    # Initialise DOE table: one row per hour, one column per HEMS load
    doe_table = DataFrame(hour_in_week = 1:DOE_HOURS)
    for lid in HEMS_LOADS
        doe_table[!, lid] = zeros(DOE_HOURS)
    end

    println("Solving SOCP-OPF for $DOE_HOURS hourly timesteps (3 phases each)...")

    for h in 1:DOE_HOURS
        # Background aggregated to (bus, phase) — HEMS loads handled separately
        bg_demand, bg_pv = aggregate_bus_phase(bg_h, h, HEMS_LOADS)

        hems_demand = Dict(lid => d_h[lid][h]  for lid in HEMS_LOADS)
        hems_pv     = Dict(lid => pv_h[lid][h] for lid in HEMS_LOADS)

        for ph in 1:3
            result = solve_socp_phase(ph, bg_demand, bg_pv, hems_demand, hems_pv)
            for (lid, doe_kw) in result
                doe_table[h, lid] = doe_kw
            end
        end

        if h % 24 == 0 || h == DOE_HOURS
            day = h ÷ 24
            println("  Completed day $day / $DOE_DAYS  (hour $h / $DOE_HOURS)")
        end
    end

    out_file = joinpath(out_dir, "case4_socp_doe_table.csv")
    CSV.write(out_file, doe_table)

    println("\nSaved DOE table ($(DOE_HOURS) hours × $(length(HEMS_LOADS)) loads):")
    println("  ", out_file)

    # Print a short summary
    println("\nDOE summary (min/mean/max export limit per HEMS load [kW]):")
    println(rpad("Load", 8), rpad("Min",  8), rpad("Mean", 8), rpad("Max", 8))
    for lid in HEMS_LOADS
        v = doe_table[!, lid]
        println(rpad(lid, 8),
                rpad(round(minimum(v), digits=2), 8),
                rpad(round(mean(v),    digits=2), 8),
                rpad(round(maximum(v), digits=2), 8))
    end
end

main()
