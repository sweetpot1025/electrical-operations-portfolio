ELEC5211 - Power System Dynamics and Control

Contents: steady-state power flow, fault-on dynamics, fault clearing, CCT search, SMIB laboratory script and saved numeric results.
Environment: MATLAB and MATPOWER.
Network scenario: Bus 7 three-phase fault; branch 6-7 opened on clearing.
CCT analysis: undamped generators, 180-degree relative rotor-angle criterion and a 10-second simulation window.
