ELEC5211 course-group source and saved numeric results
Part of Haotian Guo's portfolio; group coursework, with separate SMIB laboratory material.
Requires MATLAB and MATPOWER, obtained separately under their own licenses. MATPOWER itself is not redistributed here. The local materials contained a MATPOWER 8.1 installation; the final report describes the MATPOWER method without prescribing a version.
The selected source implements a Bus 7 fault and opens branch 6-7 as the available-topology approximation. Keep this assumption when interpreting CCT and post-fault results.
These are archived sources and saved results. No engineering simulation was rerun during portfolio preparation.
smib_lab.m preserves the user-provided smib.txt contents and changes only the filename extension.
