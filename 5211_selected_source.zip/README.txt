ELEC5211 电力系统稳态与动态稳定性

SMIB/：单机无穷大系统功角与扰动脚本
multi-machine/：三机九节点 Task 1-7 脚本、MAT 数值结果与原始成果图
reports/：SMIB 实验和多机系统项目报告

使用 MATLAB；配置 MATPOWER 后运行 project5211_task1_basecase.m，再运行 Task 5、6、7 脚本。Task 1-4 包含在基础脚本中。故障位于 Bus 7，故障后切除 6-7 支路。
