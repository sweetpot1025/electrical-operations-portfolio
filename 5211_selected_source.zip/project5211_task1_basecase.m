clear; clc; close all;

disp('==============================');
disp('SCRIPT STARTED SUCCESSFULLY');
disp('==============================');

%% ELEC5211 Project Task 1 - Base Case and Voltage Set-point Sensitivity

%% 1. Load MATPOWER 9-bus case
mpc = loadcase('case9');

%% 2. Set project load data
% Project loads:
% Load A = 125 MW + j50 MVar
% Load B = 90 MW + j30 MVar
% Load C = 100 MW + j30 MVar
%
% MATPOWER case9 has loads at buses 5, 7 and 9.
% Here we use:
% Bus 5: Load B = 90 + j30
% Bus 7: Load C = 100 + j30
% Bus 9: Load A = 125 + j50

mpc.bus(mpc.bus(:,1)==5, 3) = 90;
mpc.bus(mpc.bus(:,1)==5, 4) = 30;

mpc.bus(mpc.bus(:,1)==7, 3) = 100;
mpc.bus(mpc.bus(:,1)==7, 4) = 30;

mpc.bus(mpc.bus(:,1)==9, 3) = 125;
mpc.bus(mpc.bus(:,1)==9, 4) = 50;

%% 3. MATPOWER solver option
mpopt = mpoption('verbose', 0, 'out.all', 0);

%% 4. Define voltage set-point cases
% Case 1: project base case
% Case 2: higher generator voltage set-points
% Case 3: lower generator voltage set-points

VG_cases = [
    1.04  1.025 1.025;
    1.06  1.04  1.04;
    1.02  1.01  1.01
];

case_names = {'Base Case', 'Higher VG Case', 'Lower VG Case'};

bus_voltage_all = zeros(9, 3);
gen_Q_all = zeros(3, 3);

results_all = cell(3,1);

%% 5. Run power flow for each case
for k = 1:3

    mpc_case = mpc;

    % Set generator voltage set-points
    mpc_case.gen(1, 6) = VG_cases(k, 1);
    mpc_case.gen(2, 6) = VG_cases(k, 2);
    mpc_case.gen(3, 6) = VG_cases(k, 3);

    results_case = runpf(mpc_case, mpopt);
    results_all{k} = results_case;

    fprintf('\n==============================\n');
    fprintf('%s\n', case_names{k});
    fprintf('==============================\n');

    if results_case.success == 1
        disp('Power flow converged successfully.');
    else
        disp('Power flow did NOT converge.');
    end

    bus_voltage_all(:, k) = results_case.bus(:, 8);
    gen_Q_all(:, k) = results_case.gen(:, 3);

    %% Display bus voltages
    disp(' ');
    disp('Bus Voltage Results:');
    T_bus = array2table(results_case.bus(:, [1 8 9]), ...
        'VariableNames', {'Bus', 'Voltage_Magnitude_pu', 'Voltage_Angle_deg'});
    disp(T_bus);

    %% Display generator output
    disp(' ');
    disp('Generator Output Results:');
    T_gen = array2table(results_case.gen(:, [1 2 3 6]), ...
        'VariableNames', {'Bus', 'Pg_MW', 'Qg_MVar', 'Voltage_Setpoint_pu'});
    disp(T_gen);

    %% Display system summary
    total_gen_P = sum(results_case.gen(:,2));
    total_gen_Q = sum(results_case.gen(:,3));
    total_load_P = sum(results_case.bus(:,3));
    total_load_Q = sum(results_case.bus(:,4));
    total_loss_P = total_gen_P - total_load_P;

    disp(' ');
    disp('System Summary:');
    fprintf('Total generation P = %.4f MW\n', total_gen_P);
    fprintf('Total load P       = %.4f MW\n', total_load_P);
    fprintf('Total active loss  = %.4f MW\n', total_loss_P);
    fprintf('Total generation Q = %.4f MVar\n', total_gen_Q);
    fprintf('Total load Q       = %.4f MVar\n', total_load_Q);
end

%% 6. Figure 1: Base case bus voltage profile
figure;
plot(1:9, bus_voltage_all(:,1), '-o', 'LineWidth', 1.5);
grid on;
xlabel('Bus number');
ylabel('Voltage magnitude (p.u.)');
title('Base Case Bus Voltage Profile');

saveas(gcf, 'Figure_1_Base_Case_Bus_Voltage_Profile.png');

disp(' ');
disp('Figure 1 saved: Figure_1_Base_Case_Bus_Voltage_Profile.png');

%% 7. Figure 2: voltage set-point comparison
figure;
plot(1:9, bus_voltage_all(:,1), '-o', 'LineWidth', 1.5); hold on;
plot(1:9, bus_voltage_all(:,2), '-s', 'LineWidth', 1.5);
plot(1:9, bus_voltage_all(:,3), '-^', 'LineWidth', 1.5);
grid on;
xlabel('Bus number');
ylabel('Voltage magnitude (p.u.)');
title('Effect of Generator Voltage Set-points on Bus Voltages');
legend(case_names, 'Location', 'best');

saveas(gcf, 'Figure_2_Generator_Voltage_Setpoint_Bus_Voltage_Comparison.png');

disp('Figure 2 saved: Figure_2_Generator_Voltage_Setpoint_Bus_Voltage_Comparison.png');

%% 8. Figure 3: generator reactive power comparison
figure;
bar(gen_Q_all);
grid on;
xlabel('Generator index');
ylabel('Reactive power output Q_G (MVar)');
title('Effect of Generator Voltage Set-points on Generator Reactive Power Output');
legend(case_names, 'Location', 'best');

saveas(gcf, 'Figure_3_Generator_Reactive_Power_Comparison.png');

disp('Figure 3 saved: Figure_3_Generator_Reactive_Power_Comparison.png');

%% 9. Save all MATLAB results
save('project5211_task1_voltage_setpoint_results.mat', ...
    'mpc', 'results_all', 'VG_cases', 'case_names', ...
    'bus_voltage_all', 'gen_Q_all');

disp(' ');
disp('==============================');
disp('SCRIPT FINISHED SUCCESSFULLY');
disp('==============================');
%% Task 1 Sensitivity: Reference Bus Angle Change

disp(' ');
disp('==============================');
disp('TASK 1 SENSITIVITY: REFERENCE BUS ANGLE');
disp('==============================');

% Reference bus angle cases in degrees
% Case 1: base reference angle = 0 deg
% Case 2: reference angle = +10 deg
% Case 3: reference angle = -10 deg

ref_angle_cases = [0, 10, -10];
angle_case_names = {'Ref Angle 0 deg', 'Ref Angle +10 deg', 'Ref Angle -10 deg'};

bus_angle_all = zeros(9, 3);
bus_voltage_anglecase_all = zeros(9, 3);
gen_P_angle_all = zeros(3, 3);
gen_Q_angle_all = zeros(3, 3);
branch_P_angle_all = zeros(9, 3);
branch_Q_angle_all = zeros(9, 3);

results_angle_all = cell(3,1);

for k = 1:3

    mpc_angle = mpc;

    % Use base-case generator voltage set-points
    mpc_angle.gen(1, 6) = 1.04;
    mpc_angle.gen(2, 6) = 1.025;
    mpc_angle.gen(3, 6) = 1.025;

    % Set reference bus angle
    % In MATPOWER bus matrix:
    % column 1 = bus number
    % column 2 = bus type, type 3 means reference/slack bus
    % column 9 = voltage angle in degrees
    ref_bus_idx = find(mpc_angle.bus(:,2) == 3);
    mpc_angle.bus(ref_bus_idx, 9) = ref_angle_cases(k);

    % Run power flow
    results_angle = runpf(mpc_angle, mpopt);
    results_angle_all{k} = results_angle;

    fprintf('\n==============================\n');
    fprintf('%s\n', angle_case_names{k});
    fprintf('==============================\n');

    if results_angle.success == 1
        disp('Power flow converged successfully.');
    else
        disp('Power flow did NOT converge.');
    end

    % Store results
    bus_voltage_anglecase_all(:, k) = results_angle.bus(:, 8);
    bus_angle_all(:, k) = results_angle.bus(:, 9);
    gen_P_angle_all(:, k) = results_angle.gen(:, 2);
    gen_Q_angle_all(:, k) = results_angle.gen(:, 3);
    branch_P_angle_all(:, k) = results_angle.branch(:, 14);
    branch_Q_angle_all(:, k) = results_angle.branch(:, 15);

    %% Display bus voltage phasors
    disp(' ');
    disp('Bus Voltage Phasor Results:');
    T_angle_bus = array2table(results_angle.bus(:, [1 8 9]), ...
        'VariableNames', {'Bus', 'Voltage_Magnitude_pu', 'Voltage_Angle_deg'});
    disp(T_angle_bus);

    %% Display generator outputs
    disp(' ');
    disp('Generator Output Results:');
    T_angle_gen = array2table(results_angle.gen(:, [1 2 3 6]), ...
        'VariableNames', {'Bus', 'Pg_MW', 'Qg_MVar', 'Voltage_Setpoint_pu'});
    disp(T_angle_gen);

    %% Display branch active and reactive power flows
    disp(' ');
    disp('Branch Flow Results:');
    T_angle_branch = array2table(results_angle.branch(:, [1 2 14 15 16 17]), ...
        'VariableNames', {'FromBus', 'ToBus', 'Pf_MW', 'Qf_MVar', 'Pt_MW', 'Qt_MVar'});
    disp(T_angle_branch);
end

%% Figure 4: Bus voltage angle comparison
figure;
plot(1:9, bus_angle_all(:,1), '-o', 'LineWidth', 1.5); hold on;
plot(1:9, bus_angle_all(:,2), '-s', 'LineWidth', 1.5);
plot(1:9, bus_angle_all(:,3), '-^', 'LineWidth', 1.5);
grid on;
xlabel('Bus number');
ylabel('Voltage angle (degree)');
title('Effect of Reference Bus Angle on Bus Voltage Angles');
legend(angle_case_names, 'Location', 'best');

saveas(gcf, 'Figure_4_Reference_Bus_Angle_Comparison.png');

disp(' ');
disp('Figure 4 saved: Figure_4_Reference_Bus_Angle_Comparison.png');

%% Figure 5: Bus voltage magnitude comparison under different reference angles
figure;
plot(1:9, bus_voltage_anglecase_all(:,1), '-o', 'LineWidth', 1.5); hold on;
plot(1:9, bus_voltage_anglecase_all(:,2), '-s', 'LineWidth', 1.5);
plot(1:9, bus_voltage_anglecase_all(:,3), '-^', 'LineWidth', 1.5);
grid on;
xlabel('Bus number');
ylabel('Voltage magnitude (p.u.)');
title('Effect of Reference Bus Angle on Bus Voltage Magnitudes');
legend(angle_case_names, 'Location', 'best');

saveas(gcf, 'Figure_5_Reference_Bus_Angle_Voltage_Magnitude_Comparison.png');

disp('Figure 5 saved: Figure_5_Reference_Bus_Angle_Voltage_Magnitude_Comparison.png');

%% Save reference angle sensitivity results
save('project5211_task1_reference_angle_results.mat', ...
    'ref_angle_cases', 'angle_case_names', 'results_angle_all', ...
    'bus_angle_all', 'bus_voltage_anglecase_all', ...
    'gen_P_angle_all', 'gen_Q_angle_all', ...
    'branch_P_angle_all', 'branch_Q_angle_all');

disp(' ');
disp('REFERENCE BUS ANGLE SENSITIVITY FINISHED SUCCESSFULLY');
%% Task 2: Effect of System Loading on Network Voltage Level

disp(' ');
disp('==============================');
disp('TASK 2: LOAD SCALING ANALYSIS');
disp('==============================');

% Load scaling factors
load_scale_cases = [0.8, 1.0, 1.2, 1.4];
load_case_names = {'80% Load', '100% Load', '120% Load', '140% Load'};

bus_voltage_load_all = zeros(9, length(load_scale_cases));
bus_angle_load_all = zeros(9, length(load_scale_cases));
total_loss_load_all = zeros(1, length(load_scale_cases));
total_gen_P_load_all = zeros(1, length(load_scale_cases));
total_load_P_all = zeros(1, length(load_scale_cases));
total_load_Q_all = zeros(1, length(load_scale_cases));

results_load_all = cell(length(load_scale_cases), 1);

% Store original project load values
base_Pd = mpc.bus(:, 3);
base_Qd = mpc.bus(:, 4);

for k = 1:length(load_scale_cases)

    scale = load_scale_cases(k);
    mpc_load = mpc;

    % Use base-case generator voltage set-points
    mpc_load.gen(1, 6) = 1.04;
    mpc_load.gen(2, 6) = 1.025;
    mpc_load.gen(3, 6) = 1.025;

    % Scale active and reactive loads
    mpc_load.bus(:, 3) = base_Pd * scale;
    mpc_load.bus(:, 4) = base_Qd * scale;

    % Run power flow
    results_load = runpf(mpc_load, mpopt);
    results_load_all{k} = results_load;

    fprintf('\n==============================\n');
    fprintf('%s\n', load_case_names{k});
    fprintf('==============================\n');

    if results_load.success == 1
        disp('Power flow converged successfully.');
    else
        disp('Power flow did NOT converge.');
    end

    % Store results
    bus_voltage_load_all(:, k) = results_load.bus(:, 8);
    bus_angle_load_all(:, k) = results_load.bus(:, 9);

    total_gen_P = sum(results_load.gen(:, 2));
    total_load_P = sum(results_load.bus(:, 3));
    total_load_Q = sum(results_load.bus(:, 4));
    total_loss_P = total_gen_P - total_load_P;

    total_gen_P_load_all(k) = total_gen_P;
    total_load_P_all(k) = total_load_P;
    total_load_Q_all(k) = total_load_Q;
    total_loss_load_all(k) = total_loss_P;

    % Display bus voltage results
    disp(' ');
    disp('Bus Voltage Results:');
    T_load_bus = array2table(results_load.bus(:, [1 8 9]), ...
        'VariableNames', {'Bus', 'Voltage_Magnitude_pu', 'Voltage_Angle_deg'});
    disp(T_load_bus);

    % Display system summary
    disp(' ');
    disp('System Summary:');
    fprintf('Total load P       = %.4f MW\n', total_load_P);
    fprintf('Total load Q       = %.4f MVar\n', total_load_Q);
    fprintf('Total generation P = %.4f MW\n', total_gen_P);
    fprintf('Total active loss  = %.4f MW\n', total_loss_P);
end

%% Figure 6: Load scaling effect on bus voltage magnitudes
figure;
plot(1:9, bus_voltage_load_all(:,1), '-o', 'LineWidth', 1.5); hold on;
plot(1:9, bus_voltage_load_all(:,2), '-s', 'LineWidth', 1.5);
plot(1:9, bus_voltage_load_all(:,3), '-^', 'LineWidth', 1.5);
plot(1:9, bus_voltage_load_all(:,4), '-d', 'LineWidth', 1.5);
grid on;
xlabel('Bus number');
ylabel('Voltage magnitude (p.u.)');
title('Effect of Load Scaling on Bus Voltage Magnitudes');
legend(load_case_names, 'Location', 'best');

saveas(gcf, 'Figure_6_Load_Scaling_Bus_Voltage_Comparison.png');
disp('Figure 6 saved: Figure_6_Load_Scaling_Bus_Voltage_Comparison.png');

%% Figure 7: Load scaling effect on total active power loss
figure;
plot(load_scale_cases * 100, total_loss_load_all, '-o', 'LineWidth', 1.5);
grid on;
xlabel('Load level (%)');
ylabel('Total active power loss (MW)');
title('Effect of Load Scaling on Total Active Power Loss');

saveas(gcf, 'Figure_7_Load_Scaling_Total_Active_Power_Loss.png');
disp('Figure 7 saved: Figure_7_Load_Scaling_Total_Active_Power_Loss.png');

%% Save Task 2 results
save('project5211_task2_load_scaling_results.mat', ...
    'load_scale_cases', 'load_case_names', 'results_load_all', ...
    'bus_voltage_load_all', 'bus_angle_load_all', ...
    'total_loss_load_all', 'total_gen_P_load_all', ...
    'total_load_P_all', 'total_load_Q_all');

disp(' ');
disp('TASK 2 LOAD SCALING ANALYSIS FINISHED SUCCESSFULLY');
%% Replacement Figure 7: Minimum bus voltage versus load level

min_bus_voltage_load_all = min(bus_voltage_load_all, [], 1);

figure;
plot(load_scale_cases * 100, min_bus_voltage_load_all, '-o', 'LineWidth', 1.5);
grid on;
xlabel('Load level (%)');
ylabel('Minimum bus voltage magnitude (p.u.)');
title('Effect of Load Scaling on Minimum Bus Voltage');

saveas(gcf, 'Figure_7_Load_Scaling_Minimum_Bus_Voltage.png');
disp('Figure 7 saved: Figure_7_Load_Scaling_Minimum_Bus_Voltage.png');
%% Task 3: Reactive Power Compensation Analysis

disp(' ');
disp('==============================');
disp('TASK 3: REACTIVE POWER COMPENSATION ANALYSIS');
disp('==============================');

% Reactive compensation at Bus 9
% Positive Bs in MATPOWER represents shunt reactive power injection at V = 1.0 p.u.
% Negative value represents reactor-like reactive power absorption.
Qcomp_cases = [-50, 0, 50, 100];   % MVar
Qcomp_case_names = {'Reactor -50 MVar', 'No Compensation', 'Capacitor +50 MVar', 'Capacitor +100 MVar'};

bus_voltage_comp_all = zeros(9, length(Qcomp_cases));
bus_angle_comp_all = zeros(9, length(Qcomp_cases));
min_bus_voltage_comp_all = zeros(1, length(Qcomp_cases));
gen_Q_comp_all = zeros(3, length(Qcomp_cases));

results_comp_all = cell(length(Qcomp_cases), 1);

for k = 1:length(Qcomp_cases)

    mpc_comp = mpc;

    % Use base-case generator voltage set-points
    mpc_comp.gen(1, 6) = 1.04;
    mpc_comp.gen(2, 6) = 1.025;
    mpc_comp.gen(3, 6) = 1.025;

    % Clear original shunt compensation
    mpc_comp.bus(:, 5) = 0;    % Gs
    mpc_comp.bus(:, 6) = 0;    % Bs

    % Add reactive compensation at Bus 9
    % MATPOWER bus column 6 = Bs, shunt susceptance in MVar at V = 1.0 p.u.
    bus9_idx = find(mpc_comp.bus(:,1) == 9);
    mpc_comp.bus(bus9_idx, 6) = Qcomp_cases(k);

    % Run power flow
    results_comp = runpf(mpc_comp, mpopt);
    results_comp_all{k} = results_comp;

    fprintf('\n==============================\n');
    fprintf('%s\n', Qcomp_case_names{k});
    fprintf('==============================\n');

    if results_comp.success == 1
        disp('Power flow converged successfully.');
    else
        disp('Power flow did NOT converge.');
    end

    % Store results
    bus_voltage_comp_all(:, k) = results_comp.bus(:, 8);
    bus_angle_comp_all(:, k) = results_comp.bus(:, 9);
    min_bus_voltage_comp_all(k) = min(results_comp.bus(:, 8));
    gen_Q_comp_all(:, k) = results_comp.gen(:, 3);

    % Display bus voltage results
    disp(' ');
    disp('Bus Voltage Results:');
    T_comp_bus = array2table(results_comp.bus(:, [1 8 9]), ...
        'VariableNames', {'Bus', 'Voltage_Magnitude_pu', 'Voltage_Angle_deg'});
    disp(T_comp_bus);

    % Display generator reactive power outputs
    disp(' ');
    disp('Generator Reactive Power Results:');
    T_comp_gen = array2table(results_comp.gen(:, [1 2 3 6]), ...
        'VariableNames', {'Bus', 'Pg_MW', 'Qg_MVar', 'Voltage_Setpoint_pu'});
    disp(T_comp_gen);

    fprintf('Minimum bus voltage = %.4f p.u.\n', min_bus_voltage_comp_all(k));
end

%% Figure 8: Reactive compensation effect on bus voltage profile
figure;
plot(1:9, bus_voltage_comp_all(:,1), '-o', 'LineWidth', 1.5); hold on;
plot(1:9, bus_voltage_comp_all(:,2), '-s', 'LineWidth', 1.5);
plot(1:9, bus_voltage_comp_all(:,3), '-^', 'LineWidth', 1.5);
plot(1:9, bus_voltage_comp_all(:,4), '-d', 'LineWidth', 1.5);
grid on;
xlabel('Bus number');
ylabel('Voltage magnitude (p.u.)');
title('Effect of Reactive Compensation at Bus 9 on Bus Voltages');
legend(Qcomp_case_names, 'Location', 'best');

saveas(gcf, 'Figure_8_Reactive_Compensation_Bus_Voltage_Comparison.png');
disp('Figure 8 saved: Figure_8_Reactive_Compensation_Bus_Voltage_Comparison.png');

%% Figure 9: Reactive compensation effect on minimum bus voltage
figure;
plot(Qcomp_cases, min_bus_voltage_comp_all, '-o', 'LineWidth', 1.5);
grid on;
xlabel('Reactive compensation at Bus 9 (MVar)');
ylabel('Minimum bus voltage magnitude (p.u.)');
title('Effect of Reactive Compensation on Minimum Bus Voltage');

saveas(gcf, 'Figure_9_Reactive_Compensation_Minimum_Bus_Voltage.png');
disp('Figure 9 saved: Figure_9_Reactive_Compensation_Minimum_Bus_Voltage.png');

%% Save Task 3 results
save('project5211_task3_reactive_compensation_results.mat', ...
    'Qcomp_cases', 'Qcomp_case_names', 'results_comp_all', ...
    'bus_voltage_comp_all', 'bus_angle_comp_all', ...
    'min_bus_voltage_comp_all', 'gen_Q_comp_all');

disp(' ');
disp('TASK 3 REACTIVE COMPENSATION ANALYSIS FINISHED SUCCESSFULLY');
%% Task 4: Steady-State Dynamic Model Initialization and Equilibrium Check

disp(' ');
disp('==============================================================');
disp('TASK 4: DYNAMIC MODEL INITIALIZATION AND EQUILIBRIUM CHECK');
disp('==============================================================');

%% 1. Rebuild base-case power flow model
% This part makes Task 4 independent from previous variables.
% It uses MATPOWER case9 as the base network and applies the project load data.

mpc_dyn = loadcase('case9');

% Project load data:
% Load A = 125 MW + j50 MVar
% Load B = 90 MW + j30 MVar
% Load C = 100 MW + j30 MVar
%
% In MATPOWER case9, loads are located at buses 5, 7 and 9.
% Here:
% Bus 5: Load B
% Bus 7: Load C
% Bus 9: Load A

mpc_dyn.bus(mpc_dyn.bus(:,1)==5, 3) = 90;
mpc_dyn.bus(mpc_dyn.bus(:,1)==5, 4) = 30;

mpc_dyn.bus(mpc_dyn.bus(:,1)==7, 3) = 100;
mpc_dyn.bus(mpc_dyn.bus(:,1)==7, 4) = 30;

mpc_dyn.bus(mpc_dyn.bus(:,1)==9, 3) = 125;
mpc_dyn.bus(mpc_dyn.bus(:,1)==9, 4) = 50;

% Generator voltage set-points from project brief
mpc_dyn.gen(1, 6) = 1.04;
mpc_dyn.gen(2, 6) = 1.025;
mpc_dyn.gen(3, 6) = 1.025;

% Quiet power flow option
mpopt_dyn = mpoption('verbose', 0, 'out.all', 0);

% Run base-case power flow
results_dyn_base = runpf(mpc_dyn, mpopt_dyn);

if results_dyn_base.success == 1
    disp('Base-case power flow converged successfully.');
else
    error('Base-case power flow did NOT converge. Please check input data.');
end

%% 2. System base and generator dynamic parameters
% Generator parameters are from the project generator data.
% x_d' values are in p.u. on 100 MVA base.
% Stored energy values are in MW*s.
% Since system base is 100 MVA, H = Stored Energy / Sbase.

Sbase = results_dyn_base.baseMVA;   % normally 100 MVA

Xd_prime = [0.0608; 0.1198; 0.1813];   % x_d' in p.u. on 100 MVA base
Stored_Energy = [2364; 640; 301];      % MW*s
H = Stored_Energy / Sbase;             % inertia constant on 100 MVA system base
Tj = 2 * H;                            % inertia time constant used in swing equation

% For equilibrium check, damping does not affect because omega = 1 p.u.
D = [0; 0; 0];

%% 3. Extract generator terminal voltage and complex power
gen_bus = results_dyn_base.gen(:, 1);
Pg_MW = results_dyn_base.gen(:, 2);
Qg_MVar = results_dyn_base.gen(:, 3);

Pg_pu = Pg_MW / Sbase;
Qg_pu = Qg_MVar / Sbase;

nGen = length(gen_bus);

Vt_mag = zeros(nGen, 1);
Vt_ang_deg = zeros(nGen, 1);
Vt = zeros(nGen, 1);

Sgen_pu = zeros(nGen, 1);
Igen = zeros(nGen, 1);
Eprime = zeros(nGen, 1);
Eprime_mag = zeros(nGen, 1);
delta_rad = zeros(nGen, 1);
delta_deg = zeros(nGen, 1);

Pm_pu = zeros(nGen, 1);
Pe_pu = zeros(nGen, 1);
omega_init = ones(nGen, 1);
equilibrium_mismatch = zeros(nGen, 1);

%% 4. Dynamic initialization calculation
for i = 1:nGen

    % Find the corresponding generator bus in the bus table
    bus_idx = find(results_dyn_base.bus(:, 1) == gen_bus(i));

    % Terminal voltage phasor Vt = |Vt| angle theta
    Vt_mag(i) = results_dyn_base.bus(bus_idx, 8);
    Vt_ang_deg(i) = results_dyn_base.bus(bus_idx, 9);
    Vt(i) = Vt_mag(i) * exp(1j * deg2rad(Vt_ang_deg(i)));

    % Generator complex power injection
    Sgen_pu(i) = Pg_pu(i) + 1j * Qg_pu(i);

    % S = V * conj(I), therefore I = conj(S / V)
    Igen(i) = conj(Sgen_pu(i) / Vt(i));

    % Classical generator internal transient voltage
    % E' = Vt + j x_d' I
    Eprime(i) = Vt(i) + 1j * Xd_prime(i) * Igen(i);

    % Internal voltage magnitude and rotor angle
    Eprime_mag(i) = abs(Eprime(i));
    delta_rad(i) = angle(Eprime(i));
    delta_deg(i) = rad2deg(delta_rad(i));

    % At steady state, mechanical power equals electrical power
    Pm_pu(i) = Pg_pu(i);

    % Electrical power can be checked from Re(E' * conj(I))
    Pe_pu(i) = real(Eprime(i) * conj(Igen(i)));

    % Equilibrium mismatch in swing equation:
    % Pm - Pe - D(omega - 1)
    equilibrium_mismatch(i) = Pm_pu(i) - Pe_pu(i) - D(i) * (omega_init(i) - 1);
end

%% 5. Display dynamic initialization table
T_dyn_init = table( ...
    gen_bus, ...
    Pg_pu, ...
    Qg_pu, ...
    Vt_mag, ...
    Vt_ang_deg, ...
    Xd_prime, ...
    Stored_Energy, ...
    H, ...
    Tj, ...
    Eprime_mag, ...
    delta_deg, ...
    omega_init, ...
    Pm_pu, ...
    Pe_pu, ...
    equilibrium_mismatch, ...
    'VariableNames', { ...
    'Gen_Bus', ...
    'Pg_pu', ...
    'Qg_pu', ...
    'Vt_mag_pu', ...
    'Vt_angle_deg', ...
    'Xd_prime_pu', ...
    'Stored_Energy_MWs', ...
    'H_system_base', ...
    'Tj_2H', ...
    'Eprime_mag_pu', ...
    'Rotor_angle_delta_deg', ...
    'Omega_initial_pu', ...
    'Pm_pu', ...
    'Pe_pu', ...
    'Pm_minus_Pe'});

disp(' ');
disp('===== Dynamic Initialization and Equilibrium Check =====');
disp(T_dyn_init);

%% 6. Equilibrium check
max_mismatch = max(abs(equilibrium_mismatch));

fprintf('\nMaximum absolute equilibrium mismatch |Pm - Pe| = %.10f p.u.\n', max_mismatch);

if max_mismatch < 1e-6
    disp('Equilibrium check passed: Pm equals Pe for all generators.');
else
    disp('Equilibrium check warning: mismatch is not close to zero.');
end

%% 7. Figure 10: Initial rotor angles
figure;
bar(delta_deg);
grid on;
xlabel('Generator index');
ylabel('Initial rotor angle \delta (degree)');
title('Initial Rotor Angles from Dynamic Initialization');

saveas(gcf, 'Figure_10_Initial_Rotor_Angles.png');
disp('Figure 10 saved: Figure_10_Initial_Rotor_Angles.png');

%% 8. Save Task 4 results
save('project5211_task4_dynamic_initialization_results.mat', ...
    'T_dyn_init', ...
    'results_dyn_base', ...
    'mpc_dyn', ...
    'Sbase', ...
    'gen_bus', ...
    'Pg_pu', ...
    'Qg_pu', ...
    'Vt_mag', ...
    'Vt_ang_deg', ...
    'Vt', ...
    'Xd_prime', ...
    'Stored_Energy', ...
    'H', ...
    'Tj', ...
    'D', ...
    'Sgen_pu', ...
    'Igen', ...
    'Eprime', ...
    'Eprime_mag', ...
    'delta_rad', ...
    'delta_deg', ...
    'omega_init', ...
    'Pm_pu', ...
    'Pe_pu', ...
    'equilibrium_mismatch');

disp(' ');
disp('TASK 4 DYNAMIC INITIALIZATION FINISHED SUCCESSFULLY');
disp('==============================================================');