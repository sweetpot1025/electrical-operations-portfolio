clear; clc; close all;

disp('==============================================================');
disp('TASK 5: THREE-PHASE FAULT-ON DYNAMIC SIMULATION');
disp('==============================================================');

%% 1. Load MATPOWER 9-bus system and apply project data
mpc = loadcase('case9');

% Project load data:
% Load A = 125 MW + j50 MVar
% Load B = 90 MW + j30 MVar
% Load C = 100 MW + j30 MVar
%
% MATPOWER case9 has loads at buses 5, 7 and 9.
% Here:
% Bus 5: Load B
% Bus 7: Load C
% Bus 9: Load A

mpc.bus(mpc.bus(:,1)==5, 3) = 90;
mpc.bus(mpc.bus(:,1)==5, 4) = 30;

mpc.bus(mpc.bus(:,1)==7, 3) = 100;
mpc.bus(mpc.bus(:,1)==7, 4) = 30;

mpc.bus(mpc.bus(:,1)==9, 3) = 125;
mpc.bus(mpc.bus(:,1)==9, 4) = 50;

% Generator voltage set-points from project brief
mpc.gen(1, 6) = 1.04;
mpc.gen(2, 6) = 1.025;
mpc.gen(3, 6) = 1.025;

mpopt = mpoption('verbose', 0, 'out.all', 0);
results_base = runpf(mpc, mpopt);

if results_base.success == 1
    disp('Base-case power flow converged successfully.');
else
    error('Base-case power flow did NOT converge.');
end

%% 2. System and generator dynamic parameters
Sbase = results_base.baseMVA;     % 100 MVA
f0 = 50;                          % Hz
omega0 = 2*pi*f0;                 % rad/s

% Generator parameters from project generator data
Xd_prime = [0.0608; 0.1198; 0.1813];     % x_d' p.u. on 100 MVA base
Stored_Energy = [2364; 640; 301];        % MW*s
H = Stored_Energy / Sbase;               % inertia constant on 100 MVA base
Tj = 2 * H;                              % inertia time constant

% Task 5: first simulate fault-on dynamics without damping
D = [0; 0; 0];

%% 3. Dynamic initialization from base-case power flow
gen_bus = results_base.gen(:, 1);
Pg_MW = results_base.gen(:, 2);
Qg_MVar = results_base.gen(:, 3);

Pg_pu = Pg_MW / Sbase;
Qg_pu = Qg_MVar / Sbase;

nGen = length(gen_bus);
nb = size(results_base.bus, 1);

Vt = zeros(nGen, 1);
Igen = zeros(nGen, 1);
Eprime = zeros(nGen, 1);
Eprime_mag = zeros(nGen, 1);
delta0 = zeros(nGen, 1);

for i = 1:nGen
    bus_idx = find(results_base.bus(:,1) == gen_bus(i));

    Vmag = results_base.bus(bus_idx, 8);
    Vang = results_base.bus(bus_idx, 9);

    Vt(i) = Vmag * exp(1j * deg2rad(Vang));

    Sgen = Pg_pu(i) + 1j * Qg_pu(i);

    % S = V * conj(I), so I = conj(S/V)
    Igen(i) = conj(Sgen / Vt(i));

    % E' = Vt + j x_d' I
    Eprime(i) = Vt(i) + 1j * Xd_prime(i) * Igen(i);

    Eprime_mag(i) = abs(Eprime(i));
    delta0(i) = angle(Eprime(i));
end

omega_init = ones(nGen, 1);
Pm = Pg_pu;

fprintf('\nInitial rotor angles in degree:\n');
disp(rad2deg(delta0));

fprintf('Initial mechanical powers Pm in p.u.:\n');
disp(Pm);

%% 4. Build fault-on reduced network
% Fault setting:
% Current MATPOWER case9 does not include line 5-7.
% Therefore, a solid three-phase fault at Bus 7 is used as a practical
% approximation of a fault near Bus 7.

fault_bus = 7;
fault_admittance = 1e6;   % very large shunt admittance to approximate solid 3-phase fault

[Yred_fault, Ynn_fault, Yni_fault, net_idx, int_idx] = ...
    build_reduced_network(results_base, Xd_prime, gen_bus, fault_bus, fault_admittance);

%% 5. Simulate fault-on period
% Task 6 later clears the fault in 4 cycles at 50 Hz.
% 4 cycles = 4/50 = 0.08 s.
% Here Task 5 focuses on the dynamics during the fault-on period.

t_fault_end = 4 / f0;       % 0.08 s
tspan = [0 t_fault_end];

x0 = [delta0; omega_init];

odefun_fault = @(t, x) multimachine_swing_ode(t, x, ...
    Eprime_mag, Pm, Tj, D, omega0, Yred_fault);

opts = odeset('RelTol', 1e-8, 'AbsTol', 1e-10);
[t_fault, x_fault] = ode45(odefun_fault, tspan, x0, opts);

delta_fault = x_fault(:, 1:nGen);
omega_fault = x_fault(:, nGen+1:2*nGen);

%% 6. Calculate Pe and bus voltages during fault
nt = length(t_fault);
Pe_fault = zeros(nt, nGen);
Vbus_fault_mag = zeros(nt, nb);

for k = 1:nt
    delta_k = delta_fault(k, :).';
    E_k = Eprime_mag .* exp(1j * delta_k);

    I_k = Yred_fault * E_k;
    Pe_fault(k, :) = real(E_k .* conj(I_k)).';

    % Solve network bus voltages from internal generator voltages
    Vnet_k = -Ynn_fault \ (Yni_fault * E_k);
    Vbus_fault_mag(k, :) = abs(Vnet_k).';
end

%% 7. Figure 11: Rotor angles during fault
figure;
plot(t_fault, rad2deg(delta_fault(:,1)), 'LineWidth', 1.5); hold on;
plot(t_fault, rad2deg(delta_fault(:,2)), 'LineWidth', 1.5);
plot(t_fault, rad2deg(delta_fault(:,3)), 'LineWidth', 1.5);
grid on;
xlabel('Time (s)');
ylabel('Rotor angle \delta (degree)');
title('Generator Rotor Angles During Three-Phase Fault');
legend('Gen 1', 'Gen 2', 'Gen 3', 'Location', 'best');

saveas(gcf, 'Figure_11_FaultOn_Rotor_Angles.png');
disp('Figure 11 saved: Figure_11_FaultOn_Rotor_Angles.png');

%% 8. Figure 12: Rotor speeds during fault
figure;
plot(t_fault, omega_fault(:,1), 'LineWidth', 1.5); hold on;
plot(t_fault, omega_fault(:,2), 'LineWidth', 1.5);
plot(t_fault, omega_fault(:,3), 'LineWidth', 1.5);
grid on;
xlabel('Time (s)');
ylabel('Rotor speed \omega (p.u.)');
title('Generator Rotor Speeds During Three-Phase Fault');
legend('Gen 1', 'Gen 2', 'Gen 3', 'Location', 'best');

saveas(gcf, 'Figure_12_FaultOn_Rotor_Speeds.png');
disp('Figure 12 saved: Figure_12_FaultOn_Rotor_Speeds.png');

%% 9. Figure 13: Bus voltages during fault
figure;
plot(t_fault, Vbus_fault_mag, 'LineWidth', 1.2);
grid on;
xlabel('Time (s)');
ylabel('Bus voltage magnitude (p.u.)');
title('Bus Voltage Magnitudes During Three-Phase Fault');
legend('Bus 1','Bus 2','Bus 3','Bus 4','Bus 5','Bus 6','Bus 7','Bus 8','Bus 9', ...
    'Location', 'eastoutside');

saveas(gcf, 'Figure_13_FaultOn_Bus_Voltages.png');
disp('Figure 13 saved: Figure_13_FaultOn_Bus_Voltages.png');

%% 10. Print key observations
fprintf('\n===== Fault-on Simulation Summary =====\n');
fprintf('Fault bus = Bus %d\n', fault_bus);
fprintf('Fault-on simulation time = %.4f s\n', t_fault_end);

fprintf('\nFinal rotor angles at t = %.4f s, in degree:\n', t_fault_end);
disp(rad2deg(delta_fault(end, :)));

fprintf('Final rotor speeds at t = %.4f s, in p.u.:\n', t_fault_end);
disp(omega_fault(end, :));

fprintf('Minimum bus voltage during fault for each bus:\n');
disp(min(Vbus_fault_mag, [], 1));

%% 11. Save Task 5 results
save('project5211_task5_fault_on_results.mat', ...
    'results_base', 'mpc', ...
    'Sbase', 'f0', 'omega0', ...
    'Xd_prime', 'Stored_Energy', 'H', 'Tj', 'D', ...
    'gen_bus', 'Eprime_mag', 'delta0', 'omega_init', 'Pm', ...
    'fault_bus', 'fault_admittance', ...
    'Yred_fault', 'Ynn_fault', 'Yni_fault', ...
    't_fault', 'x_fault', 'delta_fault', 'omega_fault', ...
    'Pe_fault', 'Vbus_fault_mag');

disp(' ');
disp('TASK 5 FAULT-ON DYNAMIC SIMULATION FINISHED SUCCESSFULLY');
disp('==============================================================');


%% ========================================================================
% Local functions
% ========================================================================

function [Yred, Ynn, Yni, net_idx, int_idx] = build_reduced_network(results, Xd_prime, gen_bus, fault_bus, fault_admittance)

    define_constants;

    baseMVA = results.baseMVA;
    bus = results.bus;
    branch = results.branch;
    gen = results.gen;

    nb = size(bus, 1);
    ng = length(gen_bus);

    % Build network Ybus from MATPOWER
    [Ybus, ~, ~] = makeYbus(baseMVA, bus, branch);

    % Add constant impedance load admittances
    % S_load = P + jQ, Y_load = conj(S_load) / |V|^2
    Yload = zeros(nb, 1);

    for k = 1:nb
        Pd = bus(k, PD) / baseMVA;
        Qd = bus(k, QD) / baseMVA;
        Vm = bus(k, VM);

        Sload = Pd + 1j * Qd;

        if abs(Sload) > 0
            Yload(k) = conj(Sload) / (Vm^2);
        else
            Yload(k) = 0;
        end
    end

    Ynet = Ybus + sparse(1:nb, 1:nb, Yload, nb, nb);

    % Add three-phase solid fault as a very large shunt admittance
    if ~isempty(fault_bus)
        fault_idx = find(bus(:, BUS_I) == fault_bus);
        Ynet(fault_idx, fault_idx) = Ynet(fault_idx, fault_idx) + fault_admittance;
    end

    % Add generator internal buses behind x_d'
    N = nb + ng;
    Yaug = sparse(N, N);
    Yaug(1:nb, 1:nb) = Ynet;

    for i = 1:ng
        terminal_bus = gen_bus(i);
        terminal_idx = find(bus(:, BUS_I) == terminal_bus);
        internal_idx = nb + i;

        y_gen = 1 / (1j * Xd_prime(i));

        Yaug(terminal_idx, terminal_idx) = Yaug(terminal_idx, terminal_idx) + y_gen;
        Yaug(internal_idx, internal_idx) = Yaug(internal_idx, internal_idx) + y_gen;

        Yaug(terminal_idx, internal_idx) = Yaug(terminal_idx, internal_idx) - y_gen;
        Yaug(internal_idx, terminal_idx) = Yaug(internal_idx, terminal_idx) - y_gen;
    end

    net_idx = 1:nb;
    int_idx = nb+1:N;

    Ynn = Yaug(net_idx, net_idx);
    Yni = Yaug(net_idx, int_idx);
    Yin = Yaug(int_idx, net_idx);
    Yii = Yaug(int_idx, int_idx);

    % Kron reduction to generator internal buses
    Yred = Yii - Yin * (Ynn \ Yni);
end


function dx = multimachine_swing_ode(~, x, Eprime_mag, Pm, Tj, D, omega0, Yred)

    ng = length(Pm);

    delta = x(1:ng);
    omega = x(ng+1:2*ng);

    E = Eprime_mag .* exp(1j * delta);
    I = Yred * E;
    Pe = real(E .* conj(I));

    d_delta = omega0 * (omega - 1);
    d_omega = (Pm - Pe - D .* (omega - 1)) ./ Tj;

    dx = [d_delta; d_omega];
end