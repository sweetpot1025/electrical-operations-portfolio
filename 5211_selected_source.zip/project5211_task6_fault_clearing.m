clear; clc; close all;

disp('==============================================================');
disp('TASK 6: FAULT CLEARING AND POST-FAULT DYNAMIC SIMULATION');
disp('==============================================================');

%% 1. Load MATPOWER 9-bus system and apply project data
mpc = loadcase('case9');

% Project load data:
% Load A = 125 MW + j50 MVar
% Load B = 90 MW + j30 MVar
% Load C = 100 MW + j30 MVar
%
% MATPOWER case9 has loads at buses 5, 7 and 9.
% Here:
% Bus 5: Load B
% Bus 7: Load C
% Bus 9: Load A

mpc.bus(mpc.bus(:,1)==5, 3) = 90;
mpc.bus(mpc.bus(:,1)==5, 4) = 30;

mpc.bus(mpc.bus(:,1)==7, 3) = 100;
mpc.bus(mpc.bus(:,1)==7, 4) = 30;

mpc.bus(mpc.bus(:,1)==9, 3) = 125;
mpc.bus(mpc.bus(:,1)==9, 4) = 50;

% Generator voltage set-points from project brief
mpc.gen(1, 6) = 1.04;
mpc.gen(2, 6) = 1.025;
mpc.gen(3, 6) = 1.025;

mpopt = mpoption('verbose', 0, 'out.all', 0);
results_base = runpf(mpc, mpopt);

if results_base.success == 1
    disp('Base-case power flow converged successfully.');
else
    error('Base-case power flow did NOT converge.');
end

%% 2. System and generator parameters
Sbase = results_base.baseMVA;     % 100 MVA
f0 = 50;                          % Hz
omega0 = 2*pi*f0;                 % rad/s

% Generator parameters from project generator data
Xd_prime = [0.0608; 0.1198; 0.1813];     % x_d' p.u. on 100 MVA base
Stored_Energy = [2364; 640; 301];        % MW*s
H = Stored_Energy / Sbase;               % inertia constant on 100 MVA base
Tj = 2 * H;                              % inertia time constant

gen_bus = results_base.gen(:, 1);
nGen = length(gen_bus);
nb = size(results_base.bus, 1);

%% 3. Dynamic initialization
Pg_MW = results_base.gen(:, 2);
Qg_MVar = results_base.gen(:, 3);

Pg_pu = Pg_MW / Sbase;
Qg_pu = Qg_MVar / Sbase;

Vt = zeros(nGen, 1);
Igen = zeros(nGen, 1);
Eprime = zeros(nGen, 1);
Eprime_mag = zeros(nGen, 1);
delta0 = zeros(nGen, 1);

for i = 1:nGen
    bus_idx = find(results_base.bus(:,1) == gen_bus(i));

    Vmag = results_base.bus(bus_idx, 8);
    Vang = results_base.bus(bus_idx, 9);

    Vt(i) = Vmag * exp(1j * deg2rad(Vang));

    Sgen = Pg_pu(i) + 1j * Qg_pu(i);

    % S = V * conj(I), so I = conj(S/V)
    Igen(i) = conj(Sgen / Vt(i));

    % E' = Vt + j x_d' I
    Eprime(i) = Vt(i) + 1j * Xd_prime(i) * Igen(i);

    Eprime_mag(i) = abs(Eprime(i));
    delta0(i) = angle(Eprime(i));
end

omega_init = ones(nGen, 1);
Pm = Pg_pu;

disp('Initial rotor angles in degree:');
disp(rad2deg(delta0));

disp('Initial mechanical powers Pm in p.u.:');
disp(Pm);

%% 4. Fault and clearing settings
fault_bus = 7;
fault_admittance = 1e6;       % approximate solid three-phase fault

% 4 cycles at 50 Hz
t_clear = 4 / f0;             % 0.08 s
t_end = 10;                   % total simulation time

% MATPOWER case9 does not have line 5-7.
% Therefore line 6-7 is opened to approximate clearing a faulted line near Bus 7.
line_to_open = [6 7];

fprintf('\nFault bus = Bus %d\n', fault_bus);
fprintf('Fault clearing time = %.4f s\n', t_clear);
fprintf('Opened line after clearing = Bus %d - Bus %d\n', line_to_open(1), line_to_open(2));

%% 5. Build fault-on and post-fault reduced networks
[Yred_fault, Ynn_fault, Yni_fault] = ...
    build_reduced_network_task6(results_base, Xd_prime, gen_bus, fault_bus, fault_admittance, []);

[Yred_post, Ynn_post, Yni_post] = ...
    build_reduced_network_task6(results_base, Xd_prime, gen_bus, [], 0, line_to_open);

%% 6. Run simulations for D = 0 and D = 10
D0 = [0; 0; 0];
D10 = [10; 10; 10];

sim_D0 = run_fault_clearing_simulation(delta0, omega_init, Eprime_mag, Pm, ...
    Tj, D0, omega0, Yred_fault, Yred_post, Ynn_fault, Yni_fault, ...
    Ynn_post, Yni_post, t_clear, t_end);

sim_D10 = run_fault_clearing_simulation(delta0, omega_init, Eprime_mag, Pm, ...
    Tj, D10, omega0, Yred_fault, Yred_post, Ynn_fault, Yni_fault, ...
    Ynn_post, Yni_post, t_clear, t_end);

%% 7. Figures for D = 0

% Figure 14: Rotor angles, D = 0
figure;
plot(sim_D0.t, rad2deg(sim_D0.delta(:,1)), 'LineWidth', 1.5); hold on;
plot(sim_D0.t, rad2deg(sim_D0.delta(:,2)), 'LineWidth', 1.5);
plot(sim_D0.t, rad2deg(sim_D0.delta(:,3)), 'LineWidth', 1.5);
xline(t_clear, '--', 'Fault cleared');
grid on;
xlabel('Time (s)');
ylabel('Rotor angle \delta (degree)');
title('Rotor Angles After Fault Clearing, D = 0');
legend('Gen 1', 'Gen 2', 'Gen 3', 'Location', 'best');
saveas(gcf, 'Figure_14_PostFault_Rotor_Angles_D0.png');
disp('Figure 14 saved: Figure_14_PostFault_Rotor_Angles_D0.png');

% Figure 15: Rotor speeds, D = 0
figure;
plot(sim_D0.t, sim_D0.omega(:,1), 'LineWidth', 1.5); hold on;
plot(sim_D0.t, sim_D0.omega(:,2), 'LineWidth', 1.5);
plot(sim_D0.t, sim_D0.omega(:,3), 'LineWidth', 1.5);
xline(t_clear, '--', 'Fault cleared');
grid on;
xlabel('Time (s)');
ylabel('Rotor speed \omega (p.u.)');
title('Rotor Speeds After Fault Clearing, D = 0');
legend('Gen 1', 'Gen 2', 'Gen 3', 'Location', 'best');
saveas(gcf, 'Figure_15_PostFault_Rotor_Speeds_D0.png');
disp('Figure 15 saved: Figure_15_PostFault_Rotor_Speeds_D0.png');

% Figure 16: Bus voltages, D = 0
figure;
plot(sim_D0.t, sim_D0.Vbus_mag, 'LineWidth', 1.1);
xline(t_clear, '--', 'Fault cleared');
grid on;
xlabel('Time (s)');
ylabel('Bus voltage magnitude (p.u.)');
title('Bus Voltage Magnitudes After Fault Clearing, D = 0');
legend('Bus 1','Bus 2','Bus 3','Bus 4','Bus 5','Bus 6','Bus 7','Bus 8','Bus 9', ...
    'Location', 'eastoutside');
saveas(gcf, 'Figure_16_PostFault_Bus_Voltages_D0.png');
disp('Figure 16 saved: Figure_16_PostFault_Bus_Voltages_D0.png');

% Figure 17: Relative rotor angles, D = 0
rel_delta_D0 = rad2deg([sim_D0.delta(:,2)-sim_D0.delta(:,1), sim_D0.delta(:,3)-sim_D0.delta(:,1)]);

figure;
plot(sim_D0.t, rel_delta_D0(:,1), 'LineWidth', 1.5); hold on;
plot(sim_D0.t, rel_delta_D0(:,2), 'LineWidth', 1.5);
xline(t_clear, '--', 'Fault cleared');
grid on;
xlabel('Time (s)');
ylabel('Relative rotor angle (degree)');
title('Relative Rotor Angles Using Gen 1 as Reference, D = 0');
legend('\delta_2-\delta_1', '\delta_3-\delta_1', 'Location', 'best');
saveas(gcf, 'Figure_17_Relative_Rotor_Angles_D0.png');
disp('Figure 17 saved: Figure_17_Relative_Rotor_Angles_D0.png');

%% 8. Figures for D = 10

% Figure 18: Rotor angles, D = 10
figure;
plot(sim_D10.t, rad2deg(sim_D10.delta(:,1)), 'LineWidth', 1.5); hold on;
plot(sim_D10.t, rad2deg(sim_D10.delta(:,2)), 'LineWidth', 1.5);
plot(sim_D10.t, rad2deg(sim_D10.delta(:,3)), 'LineWidth', 1.5);
xline(t_clear, '--', 'Fault cleared');
grid on;
xlabel('Time (s)');
ylabel('Rotor angle \delta (degree)');
title('Rotor Angles After Fault Clearing, D = 10');
legend('Gen 1', 'Gen 2', 'Gen 3', 'Location', 'best');
saveas(gcf, 'Figure_18_PostFault_Rotor_Angles_D10.png');
disp('Figure 18 saved: Figure_18_PostFault_Rotor_Angles_D10.png');

% Figure 19: Rotor speeds, D = 10
figure;
plot(sim_D10.t, sim_D10.omega(:,1), 'LineWidth', 1.5); hold on;
plot(sim_D10.t, sim_D10.omega(:,2), 'LineWidth', 1.5);
plot(sim_D10.t, sim_D10.omega(:,3), 'LineWidth', 1.5);
xline(t_clear, '--', 'Fault cleared');
grid on;
xlabel('Time (s)');
ylabel('Rotor speed \omega (p.u.)');
title('Rotor Speeds After Fault Clearing, D = 10');
legend('Gen 1', 'Gen 2', 'Gen 3', 'Location', 'best');
saveas(gcf, 'Figure_19_PostFault_Rotor_Speeds_D10.png');
disp('Figure 19 saved: Figure_19_PostFault_Rotor_Speeds_D10.png');

% Figure 20: Bus voltages, D = 10
figure;
plot(sim_D10.t, sim_D10.Vbus_mag, 'LineWidth', 1.1);
xline(t_clear, '--', 'Fault cleared');
grid on;
xlabel('Time (s)');
ylabel('Bus voltage magnitude (p.u.)');
title('Bus Voltage Magnitudes After Fault Clearing, D = 10');
legend('Bus 1','Bus 2','Bus 3','Bus 4','Bus 5','Bus 6','Bus 7','Bus 8','Bus 9', ...
    'Location', 'eastoutside');
saveas(gcf, 'Figure_20_PostFault_Bus_Voltages_D10.png');
disp('Figure 20 saved: Figure_20_PostFault_Bus_Voltages_D10.png');

% Figure 21: Relative rotor angles, D = 10
rel_delta_D10 = rad2deg([sim_D10.delta(:,2)-sim_D10.delta(:,1), sim_D10.delta(:,3)-sim_D10.delta(:,1)]);

figure;
plot(sim_D10.t, rel_delta_D10(:,1), 'LineWidth', 1.5); hold on;
plot(sim_D10.t, rel_delta_D10(:,2), 'LineWidth', 1.5);
xline(t_clear, '--', 'Fault cleared');
grid on;
xlabel('Time (s)');
ylabel('Relative rotor angle (degree)');
title('Relative Rotor Angles Using Gen 1 as Reference, D = 10');
legend('\delta_2-\delta_1', '\delta_3-\delta_1', 'Location', 'best');
saveas(gcf, 'Figure_21_Relative_Rotor_Angles_D10.png');
disp('Figure 21 saved: Figure_21_Relative_Rotor_Angles_D10.png');

%% 9. Print stability-related summary
fprintf('\n===== Stability Summary =====\n');

fprintf('\nD = 0:\n');
fprintf('Final relative angle delta2-delta1 = %.4f deg\n', rel_delta_D0(end,1));
fprintf('Final relative angle delta3-delta1 = %.4f deg\n', rel_delta_D0(end,2));
fprintf('Maximum |delta2-delta1| = %.4f deg\n', max(abs(rel_delta_D0(:,1))));
fprintf('Maximum |delta3-delta1| = %.4f deg\n', max(abs(rel_delta_D0(:,2))));

fprintf('\nD = 10:\n');
fprintf('Final relative angle delta2-delta1 = %.4f deg\n', rel_delta_D10(end,1));
fprintf('Final relative angle delta3-delta1 = %.4f deg\n', rel_delta_D10(end,2));
fprintf('Maximum |delta2-delta1| = %.4f deg\n', max(abs(rel_delta_D10(:,1))));
fprintf('Maximum |delta3-delta1| = %.4f deg\n', max(abs(rel_delta_D10(:,2))));

%% 10. Save Task 6 results
save('project5211_task6_fault_clearing_results.mat', ...
    'results_base', 'mpc', 'Sbase', 'f0', 'omega0', ...
    'Xd_prime', 'Stored_Energy', 'H', 'Tj', ...
    'gen_bus', 'Eprime_mag', 'delta0', 'omega_init', 'Pm', ...
    'fault_bus', 'fault_admittance', 'line_to_open', ...
    't_clear', 't_end', ...
    'Yred_fault', 'Yred_post', ...
    'sim_D0', 'sim_D10', ...
    'rel_delta_D0', 'rel_delta_D10');

disp(' ');
disp('TASK 6 FAULT CLEARING SIMULATION FINISHED SUCCESSFULLY');
disp('==============================================================');


%% ========================================================================
% Local functions
% ========================================================================

function sim = run_fault_clearing_simulation(delta0, omega_init, Eprime_mag, Pm, ...
    Tj, D, omega0, Yred_fault, Yred_post, Ynn_fault, Yni_fault, ...
    Ynn_post, Yni_post, t_clear, t_end)

    nGen = length(Pm);
    x0 = [delta0; omega_init];

    opts = odeset('RelTol', 1e-8, 'AbsTol', 1e-10);

    % Fault-on simulation
    odefun_fault = @(t, x) multimachine_swing_ode_task6(t, x, ...
        Eprime_mag, Pm, Tj, D, omega0, Yred_fault);

    [t1, x1] = ode45(odefun_fault, [0 t_clear], x0, opts);

    % Post-fault simulation
    x_clear = x1(end, :).';

    odefun_post = @(t, x) multimachine_swing_ode_task6(t, x, ...
        Eprime_mag, Pm, Tj, D, omega0, Yred_post);

    [t2, x2] = ode45(odefun_post, [t_clear t_end], x_clear, opts);

    % Combine time and state, avoid duplicated clearing point
    t = [t1; t2(2:end)];
    x = [x1; x2(2:end,:)];

    delta = x(:, 1:nGen);
    omega = x(:, nGen+1:2*nGen);

    % Calculate bus voltages
    nt = length(t);
    nb = size(Ynn_post, 1);
    Vbus_mag = zeros(nt, nb);

    for k = 1:nt
        delta_k = delta(k, :).';
        E_k = Eprime_mag .* exp(1j * delta_k);

        if t(k) <= t_clear + 1e-10
            Vnet_k = -Ynn_fault \ (Yni_fault * E_k);
        else
            Vnet_k = -Ynn_post \ (Yni_post * E_k);
        end

        Vbus_mag(k, :) = abs(Vnet_k).';
    end

    sim.t = t;
    sim.x = x;
    sim.delta = delta;
    sim.omega = omega;
    sim.Vbus_mag = Vbus_mag;
end


function dx = multimachine_swing_ode_task6(~, x, Eprime_mag, Pm, Tj, D, omega0, Yred)

    ng = length(Pm);

    delta = x(1:ng);
    omega = x(ng+1:2*ng);

    E = Eprime_mag .* exp(1j * delta);
    I = Yred * E;
    Pe = real(E .* conj(I));

    d_delta = omega0 * (omega - 1);
    d_omega = (Pm - Pe - D .* (omega - 1)) ./ Tj;

    dx = [d_delta; d_omega];
end


function [Yred, Ynn, Yni] = build_reduced_network_task6(results, Xd_prime, gen_bus, fault_bus, fault_admittance, line_to_open)

    define_constants;

    baseMVA = results.baseMVA;
    bus = results.bus;
    branch = results.branch;

    nb = size(bus, 1);
    ng = length(gen_bus);

    % Open selected line if specified
    if ~isempty(line_to_open)
        fbus = line_to_open(1);
        tbus = line_to_open(2);

        line_idx = find( ...
            (branch(:, F_BUS) == fbus & branch(:, T_BUS) == tbus) | ...
            (branch(:, F_BUS) == tbus & branch(:, T_BUS) == fbus));

        if isempty(line_idx)
            warning('Selected line to open was not found in branch data.');
        else
            branch(line_idx, BR_STATUS) = 0;
        end
    end

    % Build Ybus
    [Ybus, ~, ~] = makeYbus(baseMVA, bus, branch);

    % Add constant impedance load admittances
    Yload = zeros(nb, 1);

    for k = 1:nb
        Pd = bus(k, PD) / baseMVA;
        Qd = bus(k, QD) / baseMVA;
        Vm = bus(k, VM);

        Sload = Pd + 1j * Qd;

        if abs(Sload) > 0
            Yload(k) = conj(Sload) / (Vm^2);
        else
            Yload(k) = 0;
        end
    end

    Ynet = Ybus + sparse(1:nb, 1:nb, Yload, nb, nb);

    % Add solid three-phase fault as large shunt admittance
    if ~isempty(fault_bus)
        fault_idx = find(bus(:, BUS_I) == fault_bus);
        Ynet(fault_idx, fault_idx) = Ynet(fault_idx, fault_idx) + fault_admittance;
    end

    % Add internal generator buses behind x_d'
    N = nb + ng;
    Yaug = sparse(N, N);
    Yaug(1:nb, 1:nb) = Ynet;

    for i = 1:ng
        terminal_bus = gen_bus(i);
        terminal_idx = find(bus(:, BUS_I) == terminal_bus);
        internal_idx = nb + i;

        y_gen = 1 / (1j * Xd_prime(i));

        Yaug(terminal_idx, terminal_idx) = Yaug(terminal_idx, terminal_idx) + y_gen;
        Yaug(internal_idx, internal_idx) = Yaug(internal_idx, internal_idx) + y_gen;

        Yaug(terminal_idx, internal_idx) = Yaug(terminal_idx, internal_idx) - y_gen;
        Yaug(internal_idx, terminal_idx) = Yaug(internal_idx, terminal_idx) - y_gen;
    end

    net_idx = 1:nb;
    int_idx = nb+1:N;

    Ynn = Yaug(net_idx, net_idx);
    Yni = Yaug(net_idx, int_idx);
    Yin = Yaug(int_idx, net_idx);
    Yii = Yaug(int_idx, int_idx);

    % Kron reduction
    Yred = Yii - Yin * (Ynn \ Yni);
end