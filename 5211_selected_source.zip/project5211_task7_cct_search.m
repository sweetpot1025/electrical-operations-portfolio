clear; clc; close all;

disp('==============================================================');
disp('TASK 7: CRITICAL CLEARING TIME SEARCH, D = 0');
disp('==============================================================');

%% 1. Load MATPOWER 9-bus system and apply project data
mpc = loadcase('case9');

% Project load data
mpc.bus(mpc.bus(:,1)==5, 3) = 90;
mpc.bus(mpc.bus(:,1)==5, 4) = 30;

mpc.bus(mpc.bus(:,1)==7, 3) = 100;
mpc.bus(mpc.bus(:,1)==7, 4) = 30;

mpc.bus(mpc.bus(:,1)==9, 3) = 125;
mpc.bus(mpc.bus(:,1)==9, 4) = 50;

% Generator voltage set-points
mpc.gen(1, 6) = 1.04;
mpc.gen(2, 6) = 1.025;
mpc.gen(3, 6) = 1.025;

mpopt = mpoption('verbose', 0, 'out.all', 0);
results_base = runpf(mpc, mpopt);

if results_base.success == 1
    disp('Base-case power flow converged successfully.');
else
    error('Base-case power flow did NOT converge.');
end

%% 2. System and generator parameters
Sbase = results_base.baseMVA;
f0 = 50;
omega0 = 2*pi*f0;

Xd_prime = [0.0608; 0.1198; 0.1813];
Stored_Energy = [2364; 640; 301];
H = Stored_Energy / Sbase;
Tj = 2 * H;

D = [0; 0; 0];

gen_bus = results_base.gen(:, 1);
nGen = length(gen_bus);

%% 3. Dynamic initialization
Pg_MW = results_base.gen(:, 2);
Qg_MVar = results_base.gen(:, 3);

Pg_pu = Pg_MW / Sbase;
Qg_pu = Qg_MVar / Sbase;

Vt = zeros(nGen, 1);
Igen = zeros(nGen, 1);
Eprime = zeros(nGen, 1);
Eprime_mag = zeros(nGen, 1);
delta0 = zeros(nGen, 1);

for i = 1:nGen
    bus_idx = find(results_base.bus(:,1) == gen_bus(i));

    Vmag = results_base.bus(bus_idx, 8);
    Vang = results_base.bus(bus_idx, 9);

    Vt(i) = Vmag * exp(1j * deg2rad(Vang));

    Sgen = Pg_pu(i) + 1j * Qg_pu(i);
    Igen(i) = conj(Sgen / Vt(i));

    Eprime(i) = Vt(i) + 1j * Xd_prime(i) * Igen(i);

    Eprime_mag(i) = abs(Eprime(i));
    delta0(i) = angle(Eprime(i));
end

omega_init = ones(nGen, 1);
Pm = Pg_pu;

%% 4. Fault and post-fault network settings
fault_bus = 7;
fault_admittance = 1e6;

% MATPOWER case9 does not contain line 5-7.
% Therefore, line 6-7 is opened as an approximation of clearing the faulted line near Bus 7.
line_to_open = [6 7];

[Yred_fault] = build_reduced_network_task7(results_base, Xd_prime, gen_bus, fault_bus, fault_admittance, []);
[Yred_post]  = build_reduced_network_task7(results_base, Xd_prime, gen_bus, [], 0, line_to_open);

%% 5. Coarse search for CCT
t_end = 10;
angle_limit_deg = 180;
angle_limit_rad = deg2rad(angle_limit_deg);

% You can increase upper limit if all cases are stable.
clearing_times = 0.02:0.02:0.80;

stable_flag = false(size(clearing_times));
max_relative_angle = zeros(size(clearing_times));

for k = 1:length(clearing_times)

    t_clear = clearing_times(k);

    sim_k = simulate_clearing_time_task7(delta0, omega_init, Eprime_mag, Pm, ...
        Tj, D, omega0, Yred_fault, Yred_post, t_clear, t_end, angle_limit_rad);

    stable_flag(k) = sim_k.is_stable;
    max_relative_angle(k) = sim_k.max_relative_angle_deg;

    fprintf('t_clear = %.4f s, stable = %d, max relative angle = %.2f deg\n', ...
        t_clear, stable_flag(k), max_relative_angle(k));
end

%% 6. Find stability boundary
first_unstable_idx = find(stable_flag == false, 1, 'first');

if isempty(first_unstable_idx)
    warning('All tested clearing times are stable. Increase the upper limit of clearing_times.');
    cct_low = clearing_times(end);
    cct_high = NaN;
    cct_est = cct_low;
else
    if first_unstable_idx == 1
        warning('Even the smallest tested clearing time is unstable. Reduce the lower limit.');
        cct_low = NaN;
        cct_high = clearing_times(1);
        cct_est = NaN;
    else
        cct_low = clearing_times(first_unstable_idx - 1);
        cct_high = clearing_times(first_unstable_idx);

        %% 7. Bisection refinement
        for iter = 1:15
            t_mid = (cct_low + cct_high) / 2;

            sim_mid = simulate_clearing_time_task7(delta0, omega_init, Eprime_mag, Pm, ...
                Tj, D, omega0, Yred_fault, Yred_post, t_mid, t_end, angle_limit_rad);

            if sim_mid.is_stable
                cct_low = t_mid;
            else
                cct_high = t_mid;
            end
        end

        cct_est = cct_low;
    end
end

fprintf('\n===== Critical Clearing Time Result =====\n');
fprintf('Estimated CCT lower bound = %.6f s\n', cct_low);
fprintf('Estimated first unstable clearing time = %.6f s\n', cct_high);
fprintf('Estimated CCT = %.6f s\n', cct_est);
fprintf('Estimated CCT in cycles at 50 Hz = %.4f cycles\n', cct_est * f0);

%% 8. Figure 22: Stability result versus clearing time
figure;
stem(clearing_times, stable_flag, 'filled', 'LineWidth', 1.5);
grid on;
xlabel('Clearing time (s)');
ylabel('Stability result');
title('Stability Result versus Clearing Time, D = 0');
yticks([0 1]);
yticklabels({'Unstable','Stable'});

if ~isnan(cct_est)
    xline(cct_est, '--r', sprintf('CCT = %.4f s', cct_est));
end

saveas(gcf, 'Figure_22_CCT_Stability_Result_vs_Clearing_Time.png');
disp('Figure 22 saved: Figure_22_CCT_Stability_Result_vs_Clearing_Time.png');

%% 9. Figure 23: Relative rotor angles near CCT
if ~isnan(cct_est)

    sim_stable = simulate_clearing_time_task7(delta0, omega_init, Eprime_mag, Pm, ...
        Tj, D, omega0, Yred_fault, Yred_post, cct_est, t_end, angle_limit_rad);

    if ~isnan(cct_high)
        sim_unstable = simulate_clearing_time_task7(delta0, omega_init, Eprime_mag, Pm, ...
            Tj, D, omega0, Yred_fault, Yred_post, cct_high, t_end, angle_limit_rad);
    end

    figure;

    subplot(2,1,1);
    plot(sim_stable.t, sim_stable.rel_delta_deg(:,1), 'LineWidth', 1.5); hold on;
    plot(sim_stable.t, sim_stable.rel_delta_deg(:,2), 'LineWidth', 1.5);
    xline(cct_est, '--', 'Fault cleared');
    grid on;
    xlabel('Time (s)');
    ylabel('Relative angle (degree)');
    title(sprintf('Stable Case Near CCT, t_{clear}=%.4f s', cct_est));
    legend('\delta_2-\delta_1', '\delta_3-\delta_1', 'Location', 'best');

    subplot(2,1,2);
    if ~isnan(cct_high)
        plot(sim_unstable.t, sim_unstable.rel_delta_deg(:,1), 'LineWidth', 1.5); hold on;
        plot(sim_unstable.t, sim_unstable.rel_delta_deg(:,2), 'LineWidth', 1.5);
        xline(cct_high, '--', 'Fault cleared');
        grid on;
        xlabel('Time (s)');
        ylabel('Relative angle (degree)');
        title(sprintf('Unstable Case Just Above CCT, t_{clear}=%.4f s', cct_high));
        legend('\delta_2-\delta_1', '\delta_3-\delta_1', 'Location', 'best');
    else
        text(0.1, 0.5, 'No unstable case found in tested range.');
        axis off;
    end

    saveas(gcf, 'Figure_23_Relative_Rotor_Angles_Near_CCT.png');
    disp('Figure 23 saved: Figure_23_Relative_Rotor_Angles_Near_CCT.png');
end

%% 10. Save results
save('project5211_task7_cct_search_results.mat', ...
    'clearing_times', 'stable_flag', 'max_relative_angle', ...
    'cct_low', 'cct_high', 'cct_est', ...
    'fault_bus', 'line_to_open', 'D', 't_end', ...
    'angle_limit_deg', 'Yred_fault', 'Yred_post');

disp(' ');
disp('TASK 7 CCT SEARCH FINISHED SUCCESSFULLY');
disp('==============================================================');


%% ========================================================================
% Local functions
% ========================================================================

function sim = simulate_clearing_time_task7(delta0, omega_init, Eprime_mag, Pm, ...
    Tj, D, omega0, Yred_fault, Yred_post, t_clear, t_end, angle_limit_rad)

    nGen = length(Pm);
    x0 = [delta0; omega_init];

    opts = odeset('RelTol', 1e-7, 'AbsTol', 1e-9, ...
        'Events', @(t,x) loss_of_sync_event_task7(t, x, nGen, angle_limit_rad));

    % Fault-on stage
    odefun_fault = @(t, x) multimachine_swing_ode_task7(t, x, ...
        Eprime_mag, Pm, Tj, D, omega0, Yred_fault);

    [t1, x1] = ode45(odefun_fault, [0 t_clear], x0, opts);

    if t1(end) < t_clear - 1e-8
        t = t1;
        x = x1;
    else
        % Post-fault stage
        x_clear = x1(end, :).';

        odefun_post = @(t, x) multimachine_swing_ode_task7(t, x, ...
            Eprime_mag, Pm, Tj, D, omega0, Yred_post);

        [t2, x2] = ode45(odefun_post, [t_clear t_end], x_clear, opts);

        t = [t1; t2(2:end)];
        x = [x1; x2(2:end,:)];
    end

    delta = x(:, 1:nGen);
    omega = x(:, nGen+1:2*nGen);

    rel_delta_deg = rad2deg([delta(:,2)-delta(:,1), delta(:,3)-delta(:,1)]);
    max_relative_angle_deg = max(max(abs(rel_delta_deg)));

    is_stable = (t(end) >= t_end - 1e-6) && (max_relative_angle_deg < rad2deg(angle_limit_rad));

    sim.t = t;
    sim.x = x;
    sim.delta = delta;
    sim.omega = omega;
    sim.rel_delta_deg = rel_delta_deg;
    sim.max_relative_angle_deg = max_relative_angle_deg;
    sim.is_stable = is_stable;
end


function [value, isterminal, direction] = loss_of_sync_event_task7(~, x, nGen, angle_limit_rad)

    delta = x(1:nGen);
    rel_delta = delta(2:end) - delta(1);

    value = angle_limit_rad - max(abs(rel_delta));
    isterminal = 1;
    direction = -1;
end


function dx = multimachine_swing_ode_task7(~, x, Eprime_mag, Pm, Tj, D, omega0, Yred)

    ng = length(Pm);

    delta = x(1:ng);
    omega = x(ng+1:2*ng);

    E = Eprime_mag .* exp(1j * delta);
    I = Yred * E;
    Pe = real(E .* conj(I));

    d_delta = omega0 * (omega - 1);
    d_omega = (Pm - Pe - D .* (omega - 1)) ./ Tj;

    dx = [d_delta; d_omega];
end


function [Yred] = build_reduced_network_task7(results, Xd_prime, gen_bus, fault_bus, fault_admittance, line_to_open)

    define_constants;

    baseMVA = results.baseMVA;
    bus = results.bus;
    branch = results.branch;

    nb = size(bus, 1);
    ng = length(gen_bus);

    % Open selected line if specified
    if ~isempty(line_to_open)
        fbus = line_to_open(1);
        tbus = line_to_open(2);

        line_idx = find( ...
            (branch(:, F_BUS) == fbus & branch(:, T_BUS) == tbus) | ...
            (branch(:, F_BUS) == tbus & branch(:, T_BUS) == fbus));

        if isempty(line_idx)
            warning('Selected line to open was not found in branch data.');
        else
            branch(line_idx, BR_STATUS) = 0;
        end
    end

    [Ybus, ~, ~] = makeYbus(baseMVA, bus, branch);

    % Add constant impedance load admittance
    Yload = zeros(nb, 1);

    for k = 1:nb
        Pd = bus(k, PD) / baseMVA;
        Qd = bus(k, QD) / baseMVA;
        Vm = bus(k, VM);

        Sload = Pd + 1j * Qd;

        if abs(Sload) > 0
            Yload(k) = conj(Sload) / (Vm^2);
        else
            Yload(k) = 0;
        end
    end

    Ynet = Ybus + sparse(1:nb, 1:nb, Yload, nb, nb);

    % Add solid three-phase fault as large shunt admittance
    if ~isempty(fault_bus)
        fault_idx = find(bus(:, BUS_I) == fault_bus);
        Ynet(fault_idx, fault_idx) = Ynet(fault_idx, fault_idx) + fault_admittance;
    end

    % Add internal generator buses behind x_d'
    N = nb + ng;
    Yaug = sparse(N, N);
    Yaug(1:nb, 1:nb) = Ynet;

    for i = 1:ng
        terminal_bus = gen_bus(i);
        terminal_idx = find(bus(:, BUS_I) == terminal_bus);
        internal_idx = nb + i;

        y_gen = 1 / (1j * Xd_prime(i));

        Yaug(terminal_idx, terminal_idx) = Yaug(terminal_idx, terminal_idx) + y_gen;
        Yaug(internal_idx, internal_idx) = Yaug(internal_idx, internal_idx) + y_gen;

        Yaug(terminal_idx, internal_idx) = Yaug(terminal_idx, internal_idx) - y_gen;
        Yaug(internal_idx, terminal_idx) = Yaug(internal_idx, terminal_idx) - y_gen;
    end

    net_idx = 1:nb;
    int_idx = nb+1:N;

    Ynn = Yaug(net_idx, net_idx);
    Yni = Yaug(net_idx, int_idx);
    Yin = Yaug(int_idx, net_idx);
    Yii = Yaug(int_idx, int_idx);

    Yred = Yii - Yin * (Ynn \ Yni);
end