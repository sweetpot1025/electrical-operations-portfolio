clear; clc; close all;

%% =========================
%  ELEC5211 SMIB Lab
%  Classical model with E' = constant
%  Task 3 + Task 4
% ==========================

%% 1) Given parameters from lab
Xg  = 0.25;      % Generator transient reactance Xg'
XL  = 0.5;       % Transmission line reactance
Xth = 0.25;      % Thevenin equivalent reactance
Vinf = 1.0;      % Infinite bus voltage (p.u.)

H = 0.05;        % Inertia constant
D = 0.1;         % Damping coefficient
f = 50;          % System frequency (Hz)
wb = 2*pi*f;     % Base angular speed (rad/s)

P0 = 1.0;        % Nominal active power output (p.u.)
pf = 0.85;       % Power factor at infinite bus side

%% 2) Equivalent reactance
Xsum = Xg + XL + Xth;   % Total reactance seen by E'
fprintf('Total reactance Xsum = %.4f p.u.\n', Xsum);

%% 3) Compute Q0 from power factor
phi = acos(pf);         % radians
Q0 = P0 * tan(phi);     % p.u.
fprintf('Q0 = %.4f p.u.\n', Q0);

%% 4) Compute E' from steady-state operating point
% Using S = P + jQ = V * conj(I), with V = 1∠0
% So I = conj(S/V) = P - jQ
I0 = P0 - 1i*Q0;

% Internal transient emf behind Xsum
E0_complex = Vinf + 1i * Xsum * I0;

Eprime = abs(E0_complex);
delta0 = angle(E0_complex);   % radians

fprintf('|E''| = %.4f p.u.\n', Eprime);
fprintf('delta0 = %.4f rad = %.4f deg\n', delta0, rad2deg(delta0));

%% 5) Task 3: Power-angle curve and maximum power
Pmax = Eprime * Vinf / Xsum;
fprintf('Pmax = %.4f p.u.\n', Pmax);

delta_deg_curve = linspace(0, 180, 1000);
delta_rad_curve = deg2rad(delta_deg_curve);

Pe_curve = (Eprime * Vinf / Xsum) .* sin(delta_rad_curve);

figure;
plot(delta_deg_curve, Pe_curve, 'LineWidth', 2); hold on;
yline(P0, '--', 'P_0', 'LineWidth', 1.5);
yline(Pmax, '--', 'P_{max}', 'LineWidth', 1.5);
xline(rad2deg(delta0), '--', '\delta_0', 'LineWidth', 1.5);
xlabel('\delta (deg)');
ylabel('Electrical power P_e (p.u.)');
title('Power-angle curve of the SMIB system');
grid on;

%% 6) Task 3: New equilibrium if Pm = 1.1 p.u.
Pm_step = 1.1 * P0;

if Pm_step < Pmax
    delta_new = asin(Pm_step / Pmax);
    fprintf('New equilibrium for Pm = 1.1: delta_new = %.4f rad = %.4f deg\n', ...
        delta_new, rad2deg(delta_new));
else
    fprintf('Pm = 1.1 exceeds Pmax, no equilibrium exists.\n');
end

%% 7) Task 4: Dynamic simulation with a step increase in Pm at t = 1 s
params.H = H;
params.D = D;
params.wb = wb;
params.Eprime = Eprime;
params.Vinf = Vinf;
params.Xsum = Xsum;
params.P0 = P0;
params.Pm_step = Pm_step;
params.t_step = 1.0;

% State vector x = [delta; omega]
% omega is rotor speed in p.u.
x0 = [delta0; 1.0];

tspan = [0 10];
opts = odeset('RelTol',1e-8,'AbsTol',1e-9);

[t, x] = ode45(@(t, x) smib_ode_classical(t, x, params), tspan, x0, opts);

delta = x(:,1);
omega = x(:,2);

% Reconstruct Pm and Pe for plotting
Pm = zeros(size(t));
Pe = zeros(size(t));

for k = 1:length(t)
    if t(k) < params.t_step
        Pm(k) = params.P0;
    else
        Pm(k) = params.Pm_step;
    end
    Pe(k) = params.Eprime * params.Vinf / params.Xsum * sin(delta(k));
end

%% 8) Plot Task 4 results
figure;
subplot(3,1,1);
plot(t, rad2deg(delta), 'LineWidth', 2);
xlabel('Time (s)');
ylabel('\delta (deg)');
title('Rotor angle response');
grid on;

subplot(3,1,2);
plot(t, omega, 'LineWidth', 2);
xlabel('Time (s)');
ylabel('\omega (p.u.)');
title('Rotor speed response');
grid on;

subplot(3,1,3);
plot(t, Pe, 'LineWidth', 2); hold on;
plot(t, Pm, '--', 'LineWidth', 1.8);
xlabel('Time (s)');
ylabel('Power (p.u.)');
title('Electrical and mechanical power');
legend('P_e', 'P_m');
grid on;

%% 9) Small summary printed in command window
fprintf('\n===== Summary =====\n');
fprintf('Q0      = %.4f p.u.\n', Q0);
fprintf('Eprime  = %.4f p.u.\n', Eprime);
fprintf('delta0  = %.4f deg\n', rad2deg(delta0));
fprintf('Pmax    = %.4f p.u.\n', Pmax);

if Pm_step < Pmax
    fprintf('Pm_step = %.4f p.u. < Pmax, so a new stable equilibrium exists.\n', Pm_step);
else
    fprintf('Pm_step = %.4f p.u. >= Pmax, so synchronism is expected to be lost.\n', Pm_step);
end

%% =========================
% Local function
%% =========================
function dx = smib_ode_classical(t, x, p)
    delta = x(1);
    omega = x(2);

    % Step change in mechanical power
    if t < p.t_step
        Pm = p.P0;
    else
        Pm = p.Pm_step;
    end

    % Electrical power
    Pe = p.Eprime * p.Vinf / p.Xsum * sin(delta);

    % State equations
    ddelta = p.wb * (omega - 1);
    domega = (Pm - Pe - p.D * (omega - 1)) / (2 * p.H);

    dx = [ddelta; domega];
end