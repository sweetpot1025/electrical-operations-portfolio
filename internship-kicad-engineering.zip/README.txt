Temperature and Humidity Sensor Node - KiCad Engineering Files

01_Source: KiCad project, schematic and PCB. Open Schneider_TempSensor_Pro.kicad_pro using KiCad 10.0.6.
02_Fabrication: Gerber/drill, manufacturing notes, CAM checklist and preview.
03_Assembly: BOM, CPL, assembly drawings and orientation checklist.
04_Verification: ERC/DRC reports, design checklists and engineering screenshots.
05_Prototype_Validation: prototype test plan and records workbook.
