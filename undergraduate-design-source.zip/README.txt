平煤十二矿井下一次系统设计
电气主接线图

electrical-main-connection.pdf：毕业设计论文附录图 1
electrical-main-connection.png：电气主接线图预览
