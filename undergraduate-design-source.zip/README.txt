平煤十二矿井下一次系统设计

primary-system.dwg：供配电一次系统 CAD 工程图纸
primary-system.pdf：一次系统图 PDF
