Underground Power Distribution Design

primary-system-2025-06-07.dwg: CAD drawing.
primary-system-2025-06-06.pdf: drawing in PDF format.
The design report is available separately as undergraduate-thesis.pdf.
