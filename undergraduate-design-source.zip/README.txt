平煤十二矿井下一次系统设计

electrical-main-connection.dwg：电气主接线图 CAD 工程
thesis-appendix-main-connection.pdf：论文附录图 1
thesis-appendix-main-connection.png：论文附录图预览
